Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq

Public Class PageSetupSystem


    Private Sub PageSetupSystem_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded

        '重复加载部分
        PanBack.ScrollToHome()

        If BuildType = BuildTypes.Release Then
            PanDonate.Visibility = Visibility.Collapsed
        Else
            PanDonate.Visibility = Visibility.Visible
            ItemSystemUpdateDownload.Content = "在有新版本时自动下载（更新快照版前需要先输入土豆码）"
        End If

        '非重复加载部分
        Static IsLoaded As Boolean = False
        If IsLoaded Then Return
        IsLoaded = True

        AniControlEnabled += 1
        Reload()
        SliderLoad()
        AniControlEnabled -= 1

    End Sub
    Public Sub Reload()
        SettingService.RefreshSettings(Me)
    End Sub
    Public Sub Reset()
        Try
            SettingService.ResetSettings(Me)
            Logger.Info("已初始化启动器页设置")
            Hint("已初始化启动器页设置！", HintType.Green, False)
        Catch ex As Exception
            Logger.Error(ex, "初始化启动器页设置失败", LogBehavior.Alert)
        End Try
        Reload()
    End Sub

    '滑动条
    Private Sub SliderLoad()
        SliderDownloadThread.GetHintText = Function(v) v + 1
        SliderDownloadSpeed.GetHintText =
        Function(v)
            Select Case v
                Case Is <= 14
                    Return (v + 1) * 0.1 & " M/s"
                Case Is <= 31
                    Return (v - 11) * 0.5 & " M/s"
                Case Is <= 41
                    Return (v - 21) & " M/s"
                Case Else
                    Return "无限制"
            End Select
        End Function
        SliderDebugAnim.GetHintText = Function(v) If(v > 29, "关闭", (v / 10 + 0.1) & "x")
    End Sub
    Private Sub SliderDownloadThread_PreviewChange(sender As Object, e As RouteEventArgs) Handles SliderDownloadThread.PreviewChange
        If SliderDownloadThread.Value < 100 Then Return
        If Not Settings.Get(Of Boolean)("HintDownloadThread") Then
            Settings.Set("HintDownloadThread", True)
            MyMsgBox("如果设置过多的下载线程，可能会导致下载时出现非常严重的卡顿。" & vbCrLf &
                     "一般设置 64 线程即可满足大多数下载需求，除非你知道你在干什么，否则不建议设置更多的线程数！", "警告", "我知道了", IsWarn:=True)
        End If
    End Sub

    '识别码/土豆码替代入口
    Private Sub BtnSystemIdentify_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnSystemIdentify.Click
        PageOtherAbout.CopyIdentify()
    End Sub
    Private Sub BtnSystemUnlock_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnSystemUnlock.Click
        InputPotatoCode(False)
    End Sub

    '调试模式
    Private Sub CheckDebugMode_Change() Handles CheckDebugMode.Change
        If AniControlEnabled = 0 Then Hint("部分调试信息将在刷新或启动器重启后切换显示！",, False)
    End Sub

    '自动更新
    Private Sub ComboSystemActivity_SelectionChanged(sender As Object, e As SelectionChangedEventArgs) Handles ComboSystemActivity.SelectionChanged
        If AniControlEnabled <> 0 Then Return
        If ComboSystemActivity.SelectedIndex <> 2 Then Return
        If MyMsgBox("若选择此项，即使在将来出现严重问题时，你也无法获取相关通知。" & vbCrLf &
                    "例如，如果发现某个版本游戏存在严重 Bug，你可能就会因为无法得到通知而导致无法预知的后果。" & vbCrLf & vbCrLf &
                    "一般选择 仅在有重要通知时显示公告 就可以让你尽量不受打扰了。" & vbCrLf &
                    "除非你在制作服务器整合包，或时常手动更新启动器，否则极度不推荐选择此项！", "警告", "我知道我在做什么", "取消", IsWarn:=True) = 2 Then
            If e.RemovedItems.Count > 0 Then ComboSystemActivity.SelectedItem = e.RemovedItems(0)
        End If
    End Sub
    Private Sub ComboSystemUpdate_SelectionChanged(sender As Object, e As SelectionChangedEventArgs) Handles ComboSystemUpdate.SelectionChanged
        If AniControlEnabled <> 0 Then Return
        If ComboSystemUpdate.SelectedIndex <> 3 Then Return
        If MyMsgBox("若选择此项，即使在启动器将来出现严重问题时，你也无法获取更新并获得修复。" & vbCrLf &
                    "例如，如果官方修改了登录方式，从而导致现有启动器无法登录，你可能就会因为无法更新而无法开始游戏。" & vbCrLf & vbCrLf &
                    "一般选择 仅在有重大漏洞更新时显示提示 就可以让你尽量不受打扰了。" & vbCrLf &
                    "除非你在制作服务器整合包，或时常手动更新启动器，否则极度不推荐选择此项！", "警告", "我知道我在做什么", "取消", IsWarn:=True) = 2 Then
            If e.RemovedItems.Count > 0 Then ComboSystemUpdate.SelectedItem = e.RemovedItems(0)
        End If
    End Sub
    Private Sub BtnSystemUpdate_Click(sender As Object, e As EventArgs) Handles BtnSystemUpdate.Click
        UpdateCheckByButton()
    End Sub
    ''' <summary>
    ''' 启动器是否已经是最新版？
    ''' 若返回 Nothing，则代表无更新缓存文件或出错。
    ''' </summary>
    Public Shared Function IsLauncherNewest() As Boolean?
        Try
            '确认服务器公告是否正常
            Dim ServerContent As String = If(FileUtils.TryReadAsString(PathTemp & "Cache\Notice.cfg"), "")
            If ServerContent.Split("|").Count < 3 Then Return Nothing
            '确认是否为最新
            Return ServerContent.Split("|")(If(BuildType = BuildTypes.Release, 2, 1)) <= VersionCode
        Catch ex As Exception
            Logger.Error(ex, "确认启动器更新失败")
            Return Nothing
        End Try
    End Function

#Region "导出 / 导入设置"

    Private Sub BtnSystemSettingExp_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnSystemSettingExp.Click
        'PCL-QW新增：将已保存的启动器设置导出为 JSON 文件
        Try
            Dim Data As New JObject(New JProperty("App", VersionModName), New JProperty("Version", VersionBaseName), New JProperty("ExportTime", Date.Now.ToString("yyyy-MM-dd HH:mm:ss")), New JProperty("Settings", New JObject()))
            Dim Count As Integer = 0
            For Each Entry As Settings.Setting In Settings.Entries.Values
                If Entry.Source <> Settings.Sources.Registry OrElse Entry.Encrypted Then Continue For
                If Not Settings.HasSaved(Entry.Key) Then Continue For
                Try
                    CType(Data("Settings"), JObject).Add(New JProperty(Entry.Key, New JValue(Settings.Get(Entry.Key))))
                    Count += 1
                Catch ex As Exception
                    Logger.Warn(ex, $"导出设置项失败：{Entry.Key}")
                End Try
            Next
            If Count = 0 Then
                Hint("没有需要导出的设置项。")
                Return
            End If
            Dim FileName As String = Dialogs.SaveFile("导出 PCL-QW设置", $"PCL-社区修改版-设置_{Date.Now:yyyyMMdd_HHmmss}.json", Paths.Base, {("json", "设置文件")})
            If String.IsNullOrEmpty(FileName) Then Return
            System.IO.File.WriteAllText(FileName, Data.ToString(Formatting.Indented), New System.Text.UTF8Encoding(False))
            Logger.Info($"已导出 {Count} 项设置到 {FileName}")
            MyMsgBox($"已成功导出 {Count} 项设置：{vbCrLf}{FileName}{vbCrLf}{vbCrLf}出于安全考虑，账号与登录信息不会被导出。", "导出设置", "打开所在文件夹", "确定", Button1Action:=Sub() OpenExplorer(FileName))
        Catch ex As Exception
            Logger.Error(ex, "导出设置失败", LogBehavior.Alert)
        End Try
    End Sub
    Private Sub BtnSystemSettingImp_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnSystemSettingImp.Click
        'PCL-QW新增：从 JSON 文件恢复启动器设置
        Try
            Dim FileName As String = Dialogs.SelectFile("导入 PCL-QW设置", False, Paths.Base, filter:={({"json"}, "设置文件")}).FirstOrDefault()
            If String.IsNullOrEmpty(FileName) Then Return
            Dim Root As JObject
            Try
                Root = JObject.Parse(System.IO.File.ReadAllText(FileName))
            Catch ex As Exception
                MyMsgBox("无法解析设置文件，请确认选择的文件由本启动器导出。" & vbCrLf & ex.Message, "导入设置失败", IsWarn:=True)
                Return
            End Try
            Dim SettingsData As JObject = TryCast(Root("Settings"), JObject)
            If SettingsData Is Nothing Then
                MyMsgBox("设置文件中没有可导入的内容。", "导入设置失败", IsWarn:=True)
                Return
            End If
            If MyMsgBox($"即将导入 {SettingsData.Count} 项设置，这会覆盖当前对应的设置项。{vbCrLf}导入后建议重启启动器以确保所有设置生效。{vbCrLf}{vbCrLf}是否继续？", "导入设置", "继续导入", "取消") <> 1 Then Return
            Dim OkCount As Integer = 0, SkipCount As Integer = 0
            For Each Prop As JProperty In SettingsData.Properties()
                Dim Entry As Settings.Setting = Nothing
                If Not Settings.Entries.TryGetValue(Prop.Name, Entry) OrElse Entry.Source <> Settings.Sources.Registry OrElse Entry.Encrypted Then
                    SkipCount += 1
                    Continue For
                End If
                Try
                    Settings.Set(Prop.Name, Prop.Value.ToObject(Entry.Type))
                    OkCount += 1
                Catch ex As Exception
                    SkipCount += 1
                    Logger.Warn(ex, $"导入设置项失败：{Prop.Name}")
                End Try
            Next
            Reload()
            Hint($"已导入 {OkCount} 项设置，跳过 {SkipCount} 项，部分设置需重启后生效。", HintType.Green, False)
            Logger.Info($"设置导入完成：成功 {OkCount} 项，跳过 {SkipCount} 项")
        Catch ex As Exception
            Logger.Error(ex, "导入设置失败", LogBehavior.Alert)
        End Try
    End Sub

#End Region

End Class
