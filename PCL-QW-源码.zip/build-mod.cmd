@echo off
rem ============================================================
rem  PCL 社区修改版 构建脚本（Windows / VS2022 BuildTools）
rem  构建环境要求见同目录 README-MOD.md
rem  如你的 SDK 版本或安装路径不同，请修改下面的路径
rem ============================================================
setlocal
set "REPO=%~dp0"
set "MSBuildSDKsPath=C:\Program Files\dotnet\sdk\10.0.401\Sdks"
set "DOTNET_ROOT=C:\Program Files\dotnet"
set "MSBUILD=C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\amd64\MSBuild.exe"
pushd "%REPO%"
"%MSBUILD%" "Plain Craft Launcher 2\Plain Craft Launcher 2.vbproj" -restore -nologo -m -v:m -p:Configuration=Release
set ERR=%ERRORLEVEL%
popd
echo.
if "%ERR%"=="0" (echo 构建成功：Plain Craft Launcher 2\bin\Plain Craft Launcher 2.exe) else (echo 构建失败，退出码 %ERR%)
exit /b %ERR%
