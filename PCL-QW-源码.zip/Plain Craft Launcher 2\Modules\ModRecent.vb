Imports Newtonsoft.Json.Linq
Imports System.Text

''' <summary>
''' PCL-QW新增：首页的「最近游玩」与「固定到首页」。
''' 记录保存在启动器目录下的 PCL\Recent.json，随启动器一起移动，不写入注册表。
''' Key 规则：实例 = 实例名；世界 = 实例名\世界文件夹；服务器 = 实例名|服务器IP。
''' </summary>
Public Module ModRecent

    Public Enum RecentKind
        Instance = 0
        World = 1
        Server = 2
    End Enum

    Private Raw As JObject = Nothing
    Private IsLoaded As Boolean = False
    Private ReadOnly DataLock As New Object
    Private HomeTarget As StackPanel = Nothing

    Private Class ResolvedItem
        Public Kind As RecentKind
        Public Key As String
        Public Title As String
        Public Info As String
        Public Instance As McInstance
        Public WorldFolder As String
        Public ServerIp As String
    End Class

    Private ReadOnly Property DataFile As String
        Get
            Return Paths.Base & "PCL\Recent.json"
        End Get
    End Property

    Private Function KindName(Kind As RecentKind) As String
        Select Case Kind
            Case RecentKind.World : Return "World"
            Case RecentKind.Server : Return "Server"
            Case Else : Return "Instance"
        End Select
    End Function
    Private Function KindTitle(Kind As RecentKind) As String
        Select Case Kind
            Case RecentKind.World : Return "世界"
            Case RecentKind.Server : Return "服务器"
            Case Else : Return "实例"
        End Select
    End Function

    Private Function EnsureRaw() As JObject
        If Not IsLoaded Then
            Try
                Dim Text = FileUtils.TryReadAsString(DataFile)
                If Not String.IsNullOrWhiteSpace(Text) Then Raw = JObject.Parse(Text)
            Catch ex As Exception
                Logger.Warn(ex, "读取首页记录失败，已重置")
            End Try
            If Raw Is Nothing Then Raw = New JObject()
            IsLoaded = True
        End If
        Return Raw
    End Function

    Private Sub SaveRaw()
        Try
            DirectoryUtils.Create(Paths.Base & "PCL\")
            System.IO.File.WriteAllText(DataFile, Raw.ToString(Formatting.Indented), New UTF8Encoding(False))
        Catch ex As Exception
            Logger.Warn(ex, "保存首页记录失败")
        End Try
    End Sub

    ''' <summary>
    ''' 取得 Parts 指定的数组，缺失或类型不符时创建并写回。
    ''' 除最后一层为数组外，中间层均为对象。
    ''' </summary>
    Private Function GetArray(Parts As String()) As JArray
        Dim Parent As JObject = EnsureRaw()
        For i As Integer = 0 To Parts.Length - 2
            Dim Child = Parent(Parts(i))
            If Child Is Nothing OrElse TypeOf Child IsNot JObject Then
                Child = New JObject()
                Parent(Parts(i)) = Child
            End If
            Parent = CType(Child, JObject)
        Next
        Dim Leaf = Parent(Parts.Last)
        If Leaf Is Nothing OrElse TypeOf Leaf IsNot JArray Then
            Leaf = New JArray()
            Parent(Parts.Last) = Leaf
        End If
        Return CType(Leaf, JArray)
    End Function

#Region "记录与固定"

    ''' <summary>
    ''' 记录一次使用。
    ''' </summary>
    Public Sub RecordUse(Kind As RecentKind, Key As String)
        If String.IsNullOrEmpty(Key) Then Return
        Try
            SyncLock DataLock
                Dim List = GetArray({"Recent", KindName(Kind)})
                Dim Now As String = Date.Now.ToString("yyyy-MM-dd HH:mm:ss")
                Dim Entry = List.FirstOrDefault(Function(x) x IsNot Nothing AndAlso x("key") IsNot Nothing AndAlso x("key").ToString = Key)
                If Entry Is Nothing Then
                    List.Add(New JObject From {{"key", Key}, {"time", Now}})
                Else
                    Entry("time") = Now
                End If
                Dim Sorted = List.OrderByDescending(Function(x) If(x?("time")?.ToString, "")).ToList()
                List.RemoveAll()
                For Each Item In Sorted.Take(30)
                    List.Add(Item)
                Next
                SaveRaw()
            End SyncLock
        Catch ex As Exception
            Logger.Warn(ex, "记录最近游玩失败")
        End Try
    End Sub

    ''' <summary>
    ''' 在游戏成功启动后调用，记录本次启动涉及的实例、世界与服务器。
    ''' </summary>
    Public Sub RecordCurrentLaunch()
        Try
            Dim Inst = McInstanceSelected
            If Inst Is Nothing Then Return
            RecordUse(RecentKind.Instance, Inst.Name)
            Dim Opt = CurrentLaunchOptions
            If Opt Is Nothing Then Return
            If Not String.IsNullOrEmpty(Opt.WorldName) Then RecordUse(RecentKind.World, Inst.Name & "\" & Opt.WorldName)
            Dim Server As String = If(String.IsNullOrEmpty(Opt.ServerIp), Settings.Get(Of String)("VersionServerEnter", Inst), Opt.ServerIp)
            If Not String.IsNullOrEmpty(Server) Then RecordUse(RecentKind.Server, Inst.Name & "|" & Server)
        Catch ex As Exception
            Logger.Warn(ex, "记录启动信息失败")
        End Try
    End Sub

    ''' <summary>
    ''' 该条目是否已固定到首页。
    ''' </summary>
    Public Function IsPinned(Kind As RecentKind, Key As String) As Boolean
        Try
            SyncLock DataLock
                Return GetArray({"Pinned", KindName(Kind)}).Any(Function(x) x IsNot Nothing AndAlso x.ToString = Key)
            End SyncLock
        Catch ex As Exception
            Return False
        End Try
    End Function

    ''' <summary>
    ''' 固定 / 取消固定，并刷新首页。
    ''' </summary>
    Public Sub TogglePin(Kind As RecentKind, Key As String)
        Try
            SyncLock DataLock
                Dim List = GetArray({"Pinned", KindName(Kind)})
                Dim Hit = List.FirstOrDefault(Function(x) x IsNot Nothing AndAlso x.ToString = Key)
                If Hit Is Nothing Then
                    List.Add(Key)
                    Hint("已固定到首页", HintType.Green, False)
                Else
                    List.Remove(Hit)
                    Hint("已从首页取消固定", HintType.Blue, False)
                End If
                SaveRaw()
            End SyncLock
            RefreshHomepage(Nothing)
        Catch ex As Exception
            Logger.Warn(ex, "更新固定状态失败")
        End Try
    End Sub

#End Region

#Region "首页展示"

    Private Function FindInstance(Name As String) As McInstance
        Try
            For Each Card In McInstanceList
                For Each Inst In Card.Value
                    If Inst.Name = Name Then Return Inst
                Next
            Next
        Catch ex As Exception
            Logger.Warn(ex, "查找实例失败")
        End Try
        Return Nothing
    End Function

    Private Function Resolve(Kind As RecentKind, Key As String) As ResolvedItem
        Try
            Select Case Kind
                Case RecentKind.Instance
                    Dim Inst = FindInstance(Key)
                    If Inst Is Nothing Then Return Nothing
                    Dim Info As String = "实例 · " & Inst.Version.VanillaName
                    If Inst.Version.HasFabric Then Info &= " Fabric"
                    If Inst.Version.HasForge Then Info &= " Forge"
                    If Inst.Version.HasNeoForge Then Info &= " NeoForge"
                    Return New ResolvedItem With {.Kind = Kind, .Key = Key, .Title = Inst.Name, .Info = Info, .Instance = Inst}
                Case RecentKind.World
                    Dim Pos As Integer = Key.LastIndexOf("\"c)
                    If Pos <= 0 OrElse Pos >= Key.Length - 1 Then Return Nothing
                    Dim Inst = FindInstance(Key.Substring(0, Pos))
                    If Inst Is Nothing Then Return Nothing
                    Dim Folder As String = Key.Substring(Pos + 1)
                    Dim WorldPath As String = Inst.PathIndie & "saves\" & Folder
                    Dim Title As String = Folder
                    Dim Info As String = "世界 · " & Inst.Name
                    Try
                        Dim Root = NbtUtils.ReadFile(WorldPath & "\level.dat")
                        Dim Data = NbtUtils.GetChild(Root, "Data")
                        Dim NameTag = NbtUtils.GetChild(Data, "LevelName")
                        If NameTag IsNot Nothing AndAlso Not String.IsNullOrEmpty(NameTag.Value?.ToString) Then Title = NameTag.Value.ToString
                        Dim LastPlayed = NbtUtils.GetChild(Data, "LastPlayed")
                        If LastPlayed IsNot Nothing Then
                            Info &= " · " & DateTimeOffset.FromUnixTimeSeconds(CLng(LastPlayed.Value) \ 1000L).LocalDateTime.ToString("MM-dd HH:mm")
                        End If
                    Catch ex As Exception
                        Logger.Warn(ex, $"读取世界信息失败：{WorldPath}")
                    End Try
                    Return New ResolvedItem With {.Kind = Kind, .Key = Key, .Title = Title, .Info = Info, .Instance = Inst, .WorldFolder = Folder}
                Case Else 'Server
                    Dim Pos As Integer = Key.IndexOf("|"c)
                    If Pos <= 0 OrElse Pos >= Key.Length - 1 Then Return Nothing
                    Dim Inst = FindInstance(Key.Substring(0, Pos))
                    If Inst Is Nothing Then Return Nothing
                    Dim Ip As String = Key.Substring(Pos + 1)
                    Dim Title As String = Ip
                    Try
                        For Each Server In NbtUtils.ReadServers(Inst.PathIndie & "servers.dat")
                            If Server.Ip = Ip Then Title = Server.Name : Exit For
                        Next
                    Catch ex As Exception
                        Logger.Warn(ex, "读取服务器名称失败")
                    End Try
                    Return New ResolvedItem With {.Kind = Kind, .Key = Key, .Title = Title, .Info = "服务器 · " & Inst.Name & " · " & Ip, .Instance = Inst, .ServerIp = Ip}
            End Select
        Catch ex As Exception
            Logger.Warn(ex, "解析首页条目失败：" & Key)
        End Try
        Return Nothing
    End Function

    ''' <summary>
    ''' 刷新首页的固定与最近游玩卡片。Target 为空时沿用上次的目标面板。
    ''' </summary>
    Public Sub RefreshHomepage(Target As StackPanel)
        If Target IsNot Nothing Then HomeTarget = Target
        Dim Panel = HomeTarget
        If Panel Is Nothing Then Return
        RunInThread(
        Sub()
            Try
                '确保实例列表可用
                LoaderFolderRun(McInstanceListLoader, McFolderSelected, LoaderFolderRunType.RunOnUpdated, MaxDepth:=1, ExtraPath:="versions\")
                Dim Wait As Integer = 0
                Do While McInstanceListLoader.State = LoadState.Loading AndAlso Wait < 50
                    Thread.Sleep(100)
                    Wait += 1
                Loop
                Dim PinnedKeys As New List(Of (Kind As RecentKind, Key As String))
                Dim RecentKeys As New List(Of (Kind As RecentKind, Key As String))
                SyncLock DataLock
                    For Each Kind In {RecentKind.Instance, RecentKind.World, RecentKind.Server}
                        For Each Item In GetArray({"Pinned", KindName(Kind)})
                            If Item IsNot Nothing Then PinnedKeys.Add((Kind, Item.ToString))
                        Next
                        For Each Item In GetArray({"Recent", KindName(Kind)})
                            If Item IsNot Nothing AndAlso Item("key") IsNot Nothing Then RecentKeys.Add((Kind, Item("key").ToString))
                        Next
                    Next
                End SyncLock
                Dim Pinned = PinnedKeys.Select(Function(k) Resolve(k.Kind, k.Key)).Where(Function(x) x IsNot Nothing).ToList()
                Dim Recent = RecentKeys.Select(Function(k) Resolve(k.Kind, k.Key)).Where(Function(x) x IsNot Nothing).ToList()
                RunInUi(Sub() BuildCards(Panel, Pinned, Recent))
            Catch ex As Exception
                Logger.Warn(ex, "刷新首页最近游玩失败")
            End Try
        End Sub)
    End Sub

    Private Sub BuildCards(Panel As StackPanel, Pinned As List(Of ResolvedItem), Recent As List(Of ResolvedItem))
        Try
            Panel.Children.Clear()
            If Not Pinned.Any() AndAlso Not Recent.Any() Then Return
            If Pinned.Any() Then Panel.Children.Add(BuildCard("固定到首页", Pinned))
            If Recent.Any() Then Panel.Children.Add(BuildCard("最近游玩", Recent.Take(12).ToList()))
        Catch ex As Exception
            Logger.Error(ex, "构建首页卡片失败")
        End Try
    End Sub

    Private Function BuildCard(Title As String, Items As List(Of ResolvedItem)) As MyCard
        Dim Card As New MyCard With {.Title = Title, .Margin = New Thickness(0, 0, 0, 15)}
        Dim Stack As New StackPanel With {.Margin = New Thickness(25, 40, 23, 15)}
        For Each Item In Items
            Stack.Children.Add(GetItemControl(Item))
        Next
        Card.Children.Add(Stack)
        Return Card
    End Function

    Private Function GetItemControl(Item As ResolvedItem) As MyListItem
        Dim Entry As New MyListItem With {
            .Title = Item.Title,
            .Info = Item.Info,
            .Height = 42,
            .Type = MyListItem.CheckType.Clickable,
            .LogoScale = 0.95,
            .MinPaddingRight = 10
        }
        AddHandler Entry.Click, Sub() Launch(Item)
        Dim BtnLaunch As New MyIconButton With {.LogoScale = 0.95, .Logo = "M288 160 L800 512 L288 864 Z", .ToolTip = "启动 / 进入"}
        Dim BtnPin As New MyIconButton With {
            .LogoScale = 0.95,
            .Logo = If(IsPinned(Item.Kind, Item.Key), Logo.IconButtonLikeFill, Logo.IconButtonLikeLine),
            .ToolTip = If(IsPinned(Item.Kind, Item.Key), "取消固定", "固定到首页")}
        AddHandler BtnLaunch.Click, Sub() Launch(Item)
        AddHandler BtnPin.Click, Sub() TogglePin(Item.Kind, Item.Key)
        Entry.Buttons = {BtnLaunch, BtnPin}
        Return Entry
    End Function

    Private Sub Launch(Item As ResolvedItem)
        Try
            If Item.Instance Is Nothing Then
                Hint("对应的实例已不存在。", HintType.Red)
                Return
            End If
            Select Case Item.Kind
                Case RecentKind.Instance
                    McLaunchStart(New McLaunchOptions With {.Instance = Item.Instance})
                Case RecentKind.World
                    If Item.Instance.ReleaseTime <= New Date(2023, 4, 4) Then
                        Hint("当前游戏版本不支持直接进入世界（需要 1.20 或更高版本），请进入游戏后在「单人游戏」中选择。", HintType.Red)
                        Return
                    End If
                    McLaunchStart(New McLaunchOptions With {.Instance = Item.Instance, .WorldName = Item.WorldFolder})
                Case Else
                    McLaunchStart(New McLaunchOptions With {.Instance = Item.Instance, .ServerIp = Item.ServerIp})
            End Select
        Catch ex As Exception
            Logger.Error(ex, "从首页启动失败", LogBehavior.Alert)
        End Try
    End Sub

#End Region

End Module
