Public Class PageInstanceServer

    'PCL-QW新增：服务器列表页面（读取 servers.dat）

    Private Sub PageInstanceServer_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        RefreshList()
    End Sub
    Private Sub BtnFolder_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnFolder.Click
        Try
            Dim Instance = PageInstanceLeft.Instance
            OpenExplorer(If(Instance Is Nothing, McFolderSelected, Instance.PathIndie))
        Catch ex As Exception
            Logger.Error(ex, "打开游戏文件夹失败", LogBehavior.Alert)
        End Try
    End Sub
    Private Sub BtnRefresh_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnRefresh.Click
        RefreshList()
        Hint("已刷新！", HintType.Green, False)
    End Sub

    Private Sub RefreshList()
        Try
            PanList.Children.Clear()
            Dim Instance = PageInstanceLeft.Instance
            If Instance Is Nothing Then Return
            Dim Servers = NbtUtils.ReadServers(Instance.PathIndie & "servers.dat")
            LabEmpty.Visibility = If(Servers.Any(), Visibility.Collapsed, Visibility.Visible)
            For Each Server In Servers
                PanList.Children.Add(GetServerItem(Server.Name, Server.Ip))
            Next
        Catch ex As Exception
            Logger.Error(ex, "加载服务器列表失败")
        End Try
    End Sub

    Private Function GetServerItem(ServerName As String, ServerIp As String) As MyListItem
        Dim Item As New MyListItem With {
            .Title = ServerName,
            .Info = ServerIp,
            .Height = 42,
            .Type = MyListItem.CheckType.Clickable,
            .LogoScale = 0.95,
            .MinPaddingRight = 10,
            .Logo = Logo.IconButtonServer
        }
        AddHandler Item.Click, Sub() EnterServer(ServerIp)
        Dim BtnEnter As New MyIconButton With {.LogoScale = 0.95, .Logo = "M288 160 L800 512 L288 864 Z", .ToolTip = "启动游戏并进入该服务器"}
        AddHandler BtnEnter.Click, Sub() EnterServer(ServerIp)
        Dim PinKey As String = If(PageInstanceLeft.Instance Is Nothing, "", PageInstanceLeft.Instance.Name & "|" & ServerIp)
        Dim IsPinned As Boolean = PinKey <> "" AndAlso ModRecent.IsPinned(ModRecent.RecentKind.Server, PinKey)
        Dim BtnPin As New MyIconButton With {
            .LogoScale = 0.95,
            .Logo = If(IsPinned, Logo.IconButtonLikeFill, Logo.IconButtonLikeLine),
            .ToolTip = If(IsPinned, "取消固定到首页", "固定到首页")}
        AddHandler BtnPin.Click, Sub()
                                     If PinKey = "" Then Return
                                     ModRecent.TogglePin(ModRecent.RecentKind.Server, PinKey)
                                     RefreshList()
                                 End Sub
        Item.Buttons = {BtnEnter, BtnPin}
        Return Item
    End Function

    Private Sub EnterServer(ServerIp As String)
        Dim Instance = PageInstanceLeft.Instance
        If Instance Is Nothing Then Return
        McLaunchStart(New McLaunchOptions With {.Instance = Instance, .ServerIp = ServerIp})
    End Sub

End Class
