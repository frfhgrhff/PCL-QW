Public Class PageDownloadTask

    'PCL 社区修改版新增：把下载任务收进「下载」主标签页，可以看到总进度、正在下载什么、速度与失败详情

    Private Timer As System.Windows.Threading.DispatcherTimer
    Private IsBuilding As Boolean = False
    ''' <summary>
    ''' 任务名 -> 卡片
    ''' </summary>
    Private ReadOnly CardMap As New Dictionary(Of String, MyCard)
    ''' <summary>
    ''' 任务名 -> 卡片内容面板
    ''' </summary>
    Private ReadOnly PanelMap As New Dictionary(Of String, StackPanel)

    Private Sub PageDownloadTask_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        If Timer Is Nothing Then
            Timer = New System.Windows.Threading.DispatcherTimer With {.Interval = TimeSpan.FromMilliseconds(1000)}
            AddHandler Timer.Tick, Sub() Refresh()
        End If
        Timer.Start()
        Refresh()
    End Sub

    Private Sub PageDownloadTask_Unloaded(sender As Object, e As RoutedEventArgs) Handles Me.Unloaded
        Timer?.Stop()
    End Sub

    Private Sub BtnRefreshTask_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnRefreshTask.Click
        Refresh()
    End Sub

    Private Sub BtnCancelAll_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnCancelAll.Click
        Try
            Dim Targets = LoaderTaskbar.Where(Function(l) l.Show AndAlso (l.State = LoadState.Loading OrElse l.State = LoadState.Waiting)).ToList()
            If Not Targets.Any Then
                Hint("当前没有进行中的任务。", HintType.Blue)
                Return
            End If
            If MyMsgBox($"确定要取消这 {Targets.Count} 个任务吗？已经下载完成的文件不会被删除。", "取消全部任务", "取消任务", "返回", IsWarn:=True) <> 1 Then Return
            For Each Item In Targets
                Item.Cancel()
            Next
            Refresh()
        Catch ex As Exception
            Logger.Error(ex, "取消全部任务失败", LogBehavior.Alert)
        End Try
    End Sub

#Region "刷新"

    Private Sub Refresh()
        If IsBuilding Then Return
        IsBuilding = True
        Try
            Dim Tasks = LoaderTaskbar.Where(Function(l) l.Show).ToList()
            UpdateOverview(Tasks)

            '移除已结束的任务
            For Each Key In CardMap.Keys.ToList()
                If Not Tasks.Any(Function(t) t.Name = Key) Then
                    Dim Card = CardMap(Key)
                    CardMap.Remove(Key)
                    PanelMap.Remove(Key)
                    PanTasks.Children.Remove(Card)
                End If
            Next

            '新增卡片
            For Each Task In Tasks
                If Not CardMap.ContainsKey(Task.Name) Then AddCard(Task)
            Next

            '进行中的排在前面
            Dim Ordered = Tasks.OrderBy(Function(t) If(t.State = LoadState.Loading OrElse t.State = LoadState.Waiting, 0, 1)).ToList()
            For i = 0 To Ordered.Count - 1
                Dim Card = CardMap(Ordered(i).Name)
                Dim Index = PanTasks.Children.IndexOf(Card)
                If Index >= 0 AndAlso Index <> i Then
                    PanTasks.Children.Remove(Card)
                    PanTasks.Children.Insert(Math.Min(i, PanTasks.Children.Count), Card)
                End If
            Next

            '刷新内容
            For Each Task In Tasks
                UpdateCard(Task)
            Next

            LabEmpty.Visibility = If(Tasks.Any(), Visibility.Collapsed, Visibility.Visible)
        Catch ex As Exception
            Logger.Error(ex, "刷新下载任务列表失败")
        Finally
            IsBuilding = False
        End Try
    End Sub

    Private Sub UpdateOverview(Tasks As List(Of LoaderBase))
        If Not Tasks.Any() Then
            LabOverview.Text = "当前没有下载任务。"
            Return
        End If
        Dim Done As Long = 0, Total As Long = 0
        For Each Task In Tasks
            For Each File In DownloadFilesOf(Task)
                If File.FileSize > 0 Then
                    Total += File.FileSize
                    Done += Math.Min(Math.Max(File.DownloadDone, 0), File.FileSize)
                End If
            Next
        Next
        Dim Text As String = $"{Tasks.Count} 个任务"
        If Total > 0 Then Text &= $"　·　共 {StringUtils.FormatByteSize(Total)}　·　已下载 {StringUtils.FormatByteSize(Done)}（{Done / Total * 100:0.#}%）"
        Text &= $"　·　当前速度 {StringUtils.FormatByteSize(Math.Max(NetManager.Speed, 0))}/s"
        LabOverview.Text = Text
    End Sub

#End Region

#Region "卡片"

    Private Sub AddCard(Task As LoaderBase)
        Dim Card As New MyCard With {.Title = Task.Name, .Margin = New Thickness(0, 0, 0, 15)}
        Dim Panel As New StackPanel With {.Margin = New Thickness(25, 40, 23, 15)}

        Dim Lab As New TextBlock With {.Tag = "Info", .TextWrapping = TextWrapping.Wrap, .FontSize = 12, .Opacity = 0.85, .Margin = New Thickness(0, 0, 0, 6)}
        Dim Bar As New ProgressBar With {.Tag = "Bar", .Minimum = 0, .Maximum = 100, .Height = 6, .Margin = New Thickness(0, 0, 0, 6)}
        Dim Files As New StackPanel With {.Tag = "Files", .Margin = New Thickness(0, 2, 0, 0)}

        Dim Buttons As New WrapPanel With {.Margin = New Thickness(0, 10, 0, 0)}
        Dim BtnCancel As New MyButton With {.Text = "取消该任务", .MinWidth = 120, .Height = 32, .Padding = New Thickness(13, 0, 13, 0), .ColorType = MyButton.ColorState.Red}
        Dim BtnToggle As New MyButton With {.Text = "收起明细", .MinWidth = 100, .Height = 32, .Padding = New Thickness(13, 0, 13, 0), .Margin = New Thickness(12, 0, 0, 0)}
        AddHandler BtnCancel.Click, Sub() Task.Cancel()
        AddHandler BtnToggle.Click,
        Sub()
            If Files.Visibility = Visibility.Visible Then
                Files.Visibility = Visibility.Collapsed
                BtnToggle.Text = "展开明细"
            Else
                Files.Visibility = Visibility.Visible
                BtnToggle.Text = "收起明细"
            End If
        End Sub
        Buttons.Children.Add(BtnCancel)
        Buttons.Children.Add(BtnToggle)

        Panel.Children.Add(Lab)
        Panel.Children.Add(Bar)
        Panel.Children.Add(Files)
        Panel.Children.Add(Buttons)
        Card.Children.Add(Panel)

        CardMap(Task.Name) = Card
        PanelMap(Task.Name) = Panel
        PanTasks.Children.Add(Card)
    End Sub

    Private Sub UpdateCard(Task As LoaderBase)
        Dim Panel = PanelMap(Task.Name)
        If Panel Is Nothing Then Return
        Dim Lab As TextBlock = Nothing
        Dim Bar As ProgressBar = Nothing
        Dim Files As StackPanel = Nothing
        For Each Element In Panel.Children.OfType(Of FrameworkElement)()
            Select Case Element.Tag?.ToString
                Case "Info" : Lab = TryCast(Element, TextBlock)
                Case "Bar" : Bar = TryCast(Element, ProgressBar)
                Case "Files" : Files = TryCast(Element, StackPanel)
            End Select
        Next
        If Lab Is Nothing OrElse Bar Is Nothing OrElse Files Is Nothing Then Return

        Dim Info As String = $"{StateText(Task.State)}　·　{Task.Progress * 100:0.#}%"
        If Task.State = LoadState.Failed Then Info &= vbCrLf & If(Task.Error Is Nothing, "未知错误", Task.Error.GetDisplay(False))
        If Not Info.Equals(Lab.Text) Then Lab.Text = Info
        Bar.Value = Math.Max(0, Math.Min(100, Task.Progress * 100))

        Dim FileList = DownloadFilesOf(Task)
        If Not FileList.Any Then
            If Files.Children.Count <> 1 OrElse Not TypeOf Files.Children(0) Is TextBlock Then
                Files.Children.Clear()
                Files.Children.Add(New TextBlock With {
                    .Text = "该任务不包含文件下载，进度来自安装步骤本身。",
                    .FontSize = 12, .Opacity = 0.7, .TextWrapping = TextWrapping.Wrap})
            End If
            Return
        End If
        If Files.Children.Count <> FileList.Count Then
            Files.Children.Clear()
            For Each File In FileList
                Files.Children.Add(New TextBlock With {.FontSize = 12, .TextWrapping = TextWrapping.Wrap, .Margin = New Thickness(0, 1, 0, 1)})
            Next
        End If
        For i = 0 To FileList.Count - 1
            Dim File = FileList(i)
            Dim Line As String = $"· {File.LocalName}　{StateText(File.State)}"
            If File.FileSize > 0 Then
                Line &= $"　{StringUtils.FormatByteSize(Math.Max(File.DownloadDone, 0))} / {StringUtils.FormatByteSize(File.FileSize)}（{File.DownloadDone / File.FileSize * 100:0.#}%）"
            ElseIf File.IsUnknownSize Then
                Line &= $"　已下载 {StringUtils.FormatByteSize(Math.Max(File.DownloadDone, 0))}（总大小未知）"
            End If
            If File.Speed > 0 Then Line &= $"　{StringUtils.FormatByteSize(File.Speed)}/s"
            If File.Ex IsNot Nothing AndAlso File.Ex.Any Then Line &= $"　失败原因：{File.Ex.Last.Message}"
            Dim LineLab = CType(Files.Children(i), TextBlock)
            If Not Line.Equals(LineLab.Text) Then LineLab.Text = Line
        Next
    End Sub

    ''' <summary>
    ''' 取得任务内所有需要下载的文件（含子加载器）。
    ''' </summary>
    Private Function DownloadFilesOf(Task As LoaderBase) As List(Of NetFile)
        Dim Result As New List(Of NetFile)
        Try
            Dim Direct = TryCast(Task, LoaderDownload)?.Files
            If Direct IsNot Nothing Then
                Result.AddRange(Direct)
                Return Result
            End If
            For Each SubTask In SubLoadersOf(Task)
                If ReferenceEquals(SubTask, Task) Then Continue For
                Result.AddRange(DownloadFilesOf(SubTask))
            Next
        Catch ex As Exception
        End Try
        Return Result
    End Function

    Private Function SubLoadersOf(Task As LoaderBase) As List(Of LoaderBase)
        Try
            Return CType(Task, Object).GetLoaderList()
        Catch ex As Exception
            Return New List(Of LoaderBase)
        End Try
    End Function

    Private Function StateText(Value As Object) As String
        Select Case Value.ToString()
            Case "Waiting" : Return "排队中"
            Case "Loading" : Return "进行中"
            Case "Finished", "Completed" : Return "已完成"
            Case "Failed" : Return "失败"
            Case "Canceled" : Return "已取消"
            Case "WaitingToCheck", "Checking" : Return "校验中"
            Case "Downloading", "DownloadingSlow", "DownloadingSpeed" : Return "下载中"
            Case "Retry" : Return "重试中"
            Case "Temp" : Return "写入临时文件"
            Case "NotDownloaded" : Return "未下载"
            Case Else : Return Value.ToString()
        End Select
    End Function

#End Region

End Class
