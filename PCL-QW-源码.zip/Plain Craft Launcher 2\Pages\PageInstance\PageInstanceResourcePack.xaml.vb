Public Class PageInstanceResourcePack

    'PCL-QW新增：资源包管理页面（后台线程加载）

    Private IsLoading As Boolean = False

    Private Sub PageInstanceResourcePack_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        RefreshList()
    End Sub

    Private Sub BtnFolder_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnFolder.Click
        Try
            DirectoryUtils.Create(TargetFolder)
            OpenExplorer(TargetFolder)
        Catch ex As Exception
            Logger.Error(ex, "打开资源包文件夹失败", LogBehavior.Alert)
        End Try
    End Sub

    Private Sub BtnRefresh_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnRefresh.Click
        RefreshList()
    End Sub

    Private Sub BtnInstall_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnInstall.Click
        Try
            DirectoryUtils.Create(TargetFolder)
            Dim Files = Dialogs.SelectFile("选择要安装的资源包", True, TargetFolder, filter:={({"zip"}, "资源包文件")})
            If Not Files.Any Then Return
            RunInThread(
            Sub()
                Try
                    For Each File In Files
                        FileUtils.Copy(File, TargetFolder & PathUtils.GetLastPart(File))
                    Next
                    RunInUi(Sub() Hint($"已安装 {Files.Count} 个资源包！", HintType.Green))
                    RefreshList()
                Catch ex As Exception
                    Logger.Error(ex, "安装资源包失败", LogBehavior.Alert)
                End Try
            End Sub)
        Catch ex As Exception
            Logger.Error(ex, "安装资源包失败", LogBehavior.Alert)
        End Try
    End Sub

    Private ReadOnly Property TargetFolder As String
        Get
            Dim Instance = PageInstanceLeft.Instance
            Return If(Instance Is Nothing, McFolderSelected, Instance.PathIndie) & "resourcepacks\"
        End Get
    End Property

    Private Sub RefreshList()
        If IsLoading Then Return
        IsLoading = True
        Dim Folder As String = TargetFolder
        RunInThread(
        Sub()
            Try
                Dim Entries As New List(Of (Path As String, Name As String, IsFolder As Boolean, Time As Date))
                Dim DirInfo As New System.IO.DirectoryInfo(Folder)
                If DirInfo.Exists Then
                    For Each FileItem As System.IO.FileInfo In DirInfo.EnumerateFiles()
                        Entries.Add((FileItem.FullName, FileItem.Name, False, FileItem.LastWriteTime))
                    Next
                    For Each DirItem As System.IO.DirectoryInfo In DirInfo.EnumerateDirectories()
                        Entries.Add((DirItem.FullName, DirItem.Name, True, DirItem.LastWriteTime))
                    Next
                End If
                Entries = Entries.OrderBy(Function(t) t.Name).ToList()
                RunInUi(
                Sub()
                    Try
                        PanList.Children.Clear()
                        LabEmpty.Visibility = If(Entries.Any(), Visibility.Collapsed, Visibility.Visible)
                        For Each Entry In Entries
                            PanList.Children.Add(GetEntryItem(Entry.Path, Entry.Name, Entry.IsFolder, Entry.Time))
                        Next
                    Finally
                        IsLoading = False
                    End Try
                End Sub)
            Catch ex As Exception
                Logger.Error(ex, "加载资源包列表失败")
                IsLoading = False
            End Try
        End Sub)
    End Sub

    Private Function GetEntryItem(EntryPath As String, EntryName As String, IsFolder As Boolean, Time As Date) As MyListItem
        Dim DisplayName As String = If(IsFolder, EntryName, PathUtils.GetFileNameWithoutExtension(EntryName))
        Dim Item As New MyListItem With {
            .Title = DisplayName,
            .Info = $"{(If(IsFolder, "文件夹", "文件"))} · 修改于 {Time:yyyy-MM-dd HH:mm}",
            .Height = 42,
            .Type = MyListItem.CheckType.Clickable,
            .LogoScale = 0.95,
            .MinPaddingRight = 10
        }
        AddHandler Item.Click, Sub() OpenExplorer(EntryPath)
        Dim BtnFolder As New MyIconButton With {.LogoScale = 0.95, .Logo = Logo.IconButtonOpen, .ToolTip = "在文件夹中打开"}
        Dim BtnDelete As New MyIconButton With {.LogoScale = 1, .Logo = Logo.IconButtonDelete, .ToolTip = "删除（可在回收站找回）"}
        AddHandler BtnFolder.Click, Sub() OpenExplorer(EntryPath)
        AddHandler BtnDelete.Click, Sub() DeleteEntry(EntryPath, DisplayName)
        Item.Buttons = {BtnFolder, BtnDelete}
        Return Item
    End Function

    Private Sub DeleteEntry(EntryPath As String, DisplayName As String)
        If MyMsgBox($"确定要删除资源包 {DisplayName} 吗？{vbCrLf}它将被移入系统回收站，可在回收站中找回。", "删除资源包", "删除", "取消", IsWarn:=True) <> 1 Then Return
        Try
            FileUtils.Delete(EntryPath, True)
            Hint($"已删除资源包 {DisplayName}！", HintType.Green)
            RefreshList()
        Catch ex As Exception
            Logger.Error(ex, "删除资源包失败", LogBehavior.Alert)
        End Try
    End Sub

End Class
