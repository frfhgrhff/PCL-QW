Public Class PageServerMain

    'PCL-QW新增：顶部「服务器」页，集中管理各实例内的本地服务器

    Private Servers As New List(Of ServerInfo)
    Private SelectedFolder As String = Nothing
    Private Console As ServerConsoleUI
    Private IsLoading As Boolean = False

    Private Sub PageServerMain_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        RefreshInstances()
        RefreshList()
    End Sub

#Region "实例选择与创建"

    Private Sub RefreshInstances()
        RunInThread(
        Sub()
            Try
                LoaderFolderRun(McInstanceListLoader, McFolderSelected, LoaderFolderRunType.RunOnUpdated, MaxDepth:=1, ExtraPath:="versions\")
                Dim Wait As Integer = 0
                Do While McInstanceListLoader.State = LoadState.Loading AndAlso Wait < 100
                    Thread.Sleep(100)
                    Wait += 1
                Loop
                Dim Items As New List(Of (Name As String, Instance As McInstance))
                For Each Card In McInstanceList
                    For Each Instance In Card.Value
                        Items.Add((Instance.Name, Instance))
                    Next
                Next
                Items = Items.OrderBy(Function(t) t.Name).ToList()
                RunInUi(
                Sub()
                    Dim Last = ComboInstance.Text
                    ComboInstance.Items.Clear()
                    For Each Item In Items
                        ComboInstance.Items.Add(New MyComboBoxItem With {.Content = Item.Name, .Tag = Item.Instance})
                    Next
                    If Items.Any Then
                        Dim HitName As String = Nothing
                        If Last <> "" AndAlso Items.Any(Function(t) t.Name = Last) Then HitName = Last
                        If HitName Is Nothing Then HitName = Items(0).Name
                        ComboInstance.SelectedIndex = Items.FindIndex(Function(t) t.Name = HitName)
                        BuildCreateUi(CType(ComboInstance.SelectedItem, MyComboBoxItem).Tag)
                    Else
                        PanCreate.Children.Clear()
                        Dim Lab As New TextBlock With {.Text = "没有找到任何实例，请先在「下载」页安装一个游戏版本。", .TextWrapping = TextWrapping.Wrap}
                        PanCreate.Children.Add(Lab)
                    End If
                End Sub)
            Catch ex As Exception
                Logger.Error(ex, "加载实例列表失败")
            End Try
        End Sub)
    End Sub

    Private Sub ComboInstance_SelectionChanged(sender As Object, e As SelectionChangedEventArgs) Handles ComboInstance.SelectionChanged
        If ComboInstance.SelectedItem Is Nothing Then Return
        BuildCreateUi(CType(ComboInstance.SelectedItem, MyComboBoxItem).Tag)
    End Sub

    Private Sub BuildCreateUi(Instance As McInstance)
        PanCreate.Children.Clear()
        If Instance Is Nothing Then Return
        If HasServer(ModServer.ServerFolder(Instance)) Then
            Dim Lab As New TextBlock With {
                .Text = $"实例「{Instance.Name}」已经有一个服务器了，可以在上方列表中管理它。",
                .TextWrapping = TextWrapping.Wrap, .Opacity = 0.8, .Margin = New Thickness(0, 4, 0, 0)
            }
            PanCreate.Children.Add(Lab)
            Return
        End If
        Dim Create As New ServerCreateUI(Instance)
        AddHandler Create.Installed, AddressOf RefreshList
        PanCreate.Children.Add(Create)
    End Sub

#End Region

#Region "服务器列表"

    Private Sub BtnRefreshList_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnRefreshList.Click
        RefreshList()
    End Sub

    Private Sub RefreshList()
        If IsLoading Then Return
        IsLoading = True
        RunInThread(
        Sub()
            Dim List As List(Of ServerInfo)
            Try
                LoaderFolderRun(McInstanceListLoader, McFolderSelected, LoaderFolderRunType.RunOnUpdated, MaxDepth:=1, ExtraPath:="versions\")
                Dim Wait As Integer = 0
                Do While McInstanceListLoader.State = LoadState.Loading AndAlso Wait < 100
                    Thread.Sleep(100)
                    Wait += 1
                Loop
                List = EnumerateServers()
            Catch ex As Exception
                Logger.Warn(ex, "加载服务器列表失败")
                List = New List(Of ServerInfo)
            End Try
            RunInUi(
            Sub()
                Try
                    Servers = List
                    PanList.Children.Clear()
                    LabEmpty.Visibility = If(List.Any(), Visibility.Collapsed, Visibility.Visible)
                    For Each Item In List
                        PanList.Children.Add(GetItem(Item))
                    Next
                    '刷新控制台
                    If SelectedFolder IsNot Nothing Then
                        Dim Hit = List.FirstOrDefault(Function(s) s.Folder = SelectedFolder)
                        If Hit Is Nothing Then
                            SelectedFolder = Nothing
                            Console = Nothing
                            PanConsole.Children.Clear()
                        ElseIf Console Is Nothing Then
                            ShowConsole(Hit)
                        End If
                    End If
                Finally
                    IsLoading = False
                End Try
            End Sub)
        End Sub)
    End Sub

    Private Function GetItem(Item As ServerInfo) As MyListItem
        Dim LoaderText = Item.Loader.ToString()
        Dim Entry As New MyListItem With {
            .Title = Item.Name,
            .Info = $"{Item.Version}（{LoaderText}）　·　{Item.JarName}　·　{(If(Item.Running, "运行中", "未运行"))}",
            .Height = 42,
            .Type = MyListItem.CheckType.Clickable,
            .LogoScale = 0.95,
            .MinPaddingRight = 10,
            .Logo = Logo.IconButtonServer
        }
        AddHandler Entry.Click, Sub() ShowConsole(Item)
        Dim BtnRun As New MyIconButton With {.LogoScale = 0.95, .Logo = "M288 160 L800 512 L288 864 Z", .ToolTip = If(Item.Running, "停止服务器", "启动服务器")}
        Dim BtnFolder As New MyIconButton With {.LogoScale = 0.95, .Logo = Logo.IconButtonOpen, .ToolTip = "打开服务器文件夹"}
        AddHandler BtnRun.Click,
        Sub()
            Try
                If Item.Running Then
                    Dim Server = GetRunning(Item.Folder)
                    RunInThread(Sub() StopServer(Server))
                Else
                    Dim Instance = FindInstanceByName(Item.Name)
                    If Instance Is Nothing Then
                        Hint("找不到该服务器所属的实例。", HintType.Red)
                        Return
                    End If
                    RunInThread(
                    Sub()
                        Try
                            Dim Result = StartServer(Item.Folder, Instance)
                            RunInUi(Sub()
                                        If Result IsNot Nothing Then ShowConsole(Item)
                                        RefreshList()
                                    End Sub)
                        Catch ex As Exception
                            Logger.Error(ex, "启动服务器失败", LogBehavior.Alert)
                        End Try
                    End Sub)
                End If
            Catch ex As Exception
                Logger.Error(ex, "操作服务器失败", LogBehavior.Alert)
            End Try
        End Sub
        AddHandler BtnFolder.Click, Sub() OpenExplorer(Item.Folder)
        Entry.Buttons = {BtnRun, BtnFolder}
        Return Entry
    End Function

    Private Function FindInstanceByName(Name As String) As McInstance
        Try
            For Each Card In McInstanceList
                For Each Instance In Card.Value
                    If Instance.Name = Name Then Return Instance
                Next
            Next
        Catch ex As Exception
        End Try
        Return Nothing
    End Function

    Private Sub ShowConsole(Item As ServerInfo)
        SelectedFolder = Item.Folder
        PanConsole.Children.Clear()
        Dim Instance = FindInstanceByName(Item.Name)
        If Instance Is Nothing Then
            Dim Lab As New TextBlock With {.Text = "找不到该服务器所属的实例，无法在此管理。", .TextWrapping = TextWrapping.Wrap}
            PanConsole.Children.Add(Lab)
            Return
        End If
        Console = New ServerConsoleUI(Item.Folder, Instance)
        AddHandler Console.StatusChanged, AddressOf RefreshList
        PanConsole.Children.Add(Console)
    End Sub

#End Region

End Class
