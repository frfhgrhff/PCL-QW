Public Class PageInstanceLink

    'PCL-QW新增：实例页的联机快捷入口（后端为陶瓦联机）

    Private Timer As System.Windows.Threading.DispatcherTimer
    Private LastStatus As ModTerracotta.LinkStatus?

    Private Sub PageInstanceLink_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        If Timer Is Nothing Then
            Timer = New System.Windows.Threading.DispatcherTimer With {.Interval = TimeSpan.FromMilliseconds(1000)}
            AddHandler Timer.Tick, AddressOf Poll
        End If
        Timer.Start()
        Poll(sender, e)
    End Sub

    Private Sub PageInstanceLink_Unloaded(sender As Object, e As RoutedEventArgs) Handles Me.Unloaded
        Timer?.Stop()
    End Sub

    Private Sub Poll(sender As Object, e As Object)
        RunInThread(
        Sub()
            Dim Status = ModTerracotta.QueryStatus()
            RunInUi(
            Sub()
                If Not IsLoaded Then Return
                LastStatus = Status
                If Status Is Nothing Then
                    If Not ModTerracotta.IsInstalled() Then
                        LabStatus.Text = "尚未安装陶瓦联机，请在「联机」页完成一次安装。"
                    Else
                        LabStatus.Text = "陶瓦联机未运行，请在「联机」页创建或加入房间。"
                    End If
                    LabRoom.Visibility = Visibility.Collapsed
                    BtnEnter.IsEnabled = False
                    BtnCopy.IsEnabled = False
                    Return
                End If
                Select Case Status.Value.Phase
                    Case ModTerracotta.LinkPhase.Waiting
                        LabStatus.Text = "已就绪，当前不在任何房间中。"
                        LabRoom.Visibility = Visibility.Collapsed
                        BtnEnter.IsEnabled = False
                        BtnCopy.IsEnabled = False
                    Case ModTerracotta.LinkPhase.HostScanning
                        LabStatus.Text = "房主：正在扫描本地的 Minecraft 服务器……请先启动服务器或在游戏内对局域网开放世界。"
                        BtnEnter.IsEnabled = False
                    Case ModTerracotta.LinkPhase.HostStarting
                        LabStatus.Text = "房主：正在建立联机网络……"
                        BtnEnter.IsEnabled = True
                    Case ModTerracotta.LinkPhase.HostReady
                        LabStatus.Text = "房间已创建！把房间码发给朋友即可加入。"
                        ShowRoom(Status.Value.RoomCode)
                        BtnEnter.IsEnabled = True
                    Case ModTerracotta.LinkPhase.GuestConnecting
                        LabStatus.Text = "正在连接房主……"
                        BtnEnter.IsEnabled = False
                    Case ModTerracotta.LinkPhase.GuestStarting
                        LabStatus.Text = "正在建立联机网络……"
                        BtnEnter.IsEnabled = False
                    Case ModTerracotta.LinkPhase.GuestReady
                        LabStatus.Text = $"已连接到房主，服务器地址：{Status.Value.Address}"
                        ShowRoom(Status.Value.Address)
                        BtnEnter.IsEnabled = True
                    Case ModTerracotta.LinkPhase.Errored
                        LabStatus.Text = "联机出错：" & Status.Value.ErrorText
                        BtnEnter.IsEnabled = False
                    Case Else
                        LabStatus.Text = "陶瓦联机正在启动……"
                        BtnEnter.IsEnabled = False
                End Select
            End Sub)
        End Sub)
    End Sub

    Private Sub ShowRoom(Text As String)
        If String.IsNullOrEmpty(Text) Then
            LabRoom.Visibility = Visibility.Collapsed
            BtnCopy.IsEnabled = False
            Return
        End If
        LabRoom.Text = "房间码 / 地址：" & Text
        LabRoom.Visibility = Visibility.Visible
        BtnCopy.IsEnabled = True
    End Sub

    Private Sub BtnCopy_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnCopy.Click
        Dim Text = If(LastStatus?.RoomCode, LastStatus?.Address)
        If String.IsNullOrEmpty(Text) Then
            Hint("当前没有可复制的房间码。", HintType.Red)
            Return
        End If
        ClipboardSet(Text, False)
    End Sub

    Private Sub BtnOpenLink_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnOpenLink.Click
        FrmMain.PageChange(FormMain.PageType.Link, FormMain.PageSubType.LinkMain)
    End Sub

    ''' <summary>
    ''' 用当前实例启动游戏：作为访客直接进入房间服务器，作为房主则直接进入游戏开服。
    ''' </summary>
    Private Sub BtnEnter_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnEnter.Click
        Try
            Dim Instance = PageInstanceLeft.Instance
            If Instance Is Nothing Then
                Hint("尚未选择实例。", HintType.Red)
                Return
            End If
            Dim Status = LastStatus
            If Status Is Nothing Then
                Hint("陶瓦联机未就绪。", HintType.Red)
                Return
            End If
            If Status.Value.Phase = ModTerracotta.LinkPhase.GuestReady AndAlso Not String.IsNullOrEmpty(Status.Value.Address) Then
                McLaunchStart(New McLaunchOptions With {.Instance = Instance, .ServerIp = Status.Value.Address})
            Else
                McLaunchStart(New McLaunchOptions With {.Instance = Instance})
            End If
        Catch ex As Exception
            Logger.Error(ex, "联机启动失败", LogBehavior.Alert)
        End Try
    End Sub

End Class
