Imports System.IO
Imports System.IO.Compression
Imports System.Text

''' <summary>
''' 最小化的 NBT 读取工具（PCL-QW新增）。
''' 用于读取 servers.dat 等简单的 NBT 文件；不支持写入。
''' </summary>
Public Module NbtUtils

    ''' <summary>
    ''' 一个 NBT 标签。Value 的实际类型取决于 Type：
    ''' 1=Byte，2=Short，3=Integer，4=Long，5=Single，6=Double，7=Byte()，8=String，
    ''' 9=List(Of Object)，10=Dictionary(Of String, NbtTag)，11=List(Of Integer)，12=List(Of Long)。
    ''' </summary>
    Public Class NbtTag
        Public Type As Byte
        Public Value As Object
    End Class

    ''' <summary>
    ''' 读取一个 NBT 文件（支持未压缩与 gzip 压缩），返回根标签。
    ''' </summary>
    Public Function ReadFile(FilePath As String) As NbtTag
        Using Stream As New FileStream(FilePath, FileMode.Open, FileAccess.Read)
            Dim Head(1) As Byte
            Dim ReadCount = Stream.Read(Head, 0, 2)
            Stream.Seek(0, SeekOrigin.Begin)
            If ReadCount = 2 AndAlso Head(0) = &H1F AndAlso Head(1) = &H8B Then
                Using Gz As New GZipStream(Stream, CompressionMode.Decompress)
                    Return ReadTag(Gz)
                End Using
            Else
                Return ReadTag(Stream)
            End If
        End Using
    End Function

    Private Function ReadTag(S As Stream) As NbtTag
        Dim Type As Byte = ReadByte(S)
        If Type = 0 Then Return Nothing
        ReadString(S) '标签名，根标签的名字会被忽略
        Return New NbtTag With {.Type = Type, .Value = ReadPayload(S, Type)}
    End Function

    Private Function ReadPayload(S As Stream, Type As Byte) As Object
        Select Case Type
            Case 1
                Return ReadByte(S)
            Case 2
                Return ReadShort(S)
            Case 3
                Return ReadInt(S)
            Case 4
                Return ReadLong(S)
            Case 5
                Return ReadSingle(S)
            Case 6
                Return ReadDouble(S)
            Case 7
                Dim Length = ReadInt(S)
                Dim Data(Length - 1) As Byte
                ReadFull(S, Data)
                Return Data
            Case 8
                Return ReadString(S)
            Case 9
                Dim ItemType = ReadByte(S)
                Dim Length = ReadInt(S)
                Dim List As New List(Of Object)
                For i = 1 To Length
                    List.Add(ReadPayload(S, ItemType))
                Next
                Return List
            Case 10
                Dim Compound As New Dictionary(Of String, NbtTag)
                Do
                    Dim ChildType = ReadByte(S)
                    If ChildType = 0 Then Exit Do
                    Dim Name = ReadString(S)
                    Compound(Name) = New NbtTag With {.Type = ChildType, .Value = ReadPayload(S, ChildType)}
                Loop
                Return Compound
            Case 11
                Dim Length = ReadInt(S)
                Dim List As New List(Of Integer)
                For i = 1 To Length
                    List.Add(ReadInt(S))
                Next
                Return List
            Case 12
                Dim Length = ReadInt(S)
                Dim List As New List(Of Long)
                For i = 1 To Length
                    List.Add(ReadLong(S))
                Next
                Return List
            Case Else
                Throw New Exception($"不支持的 NBT 标签类型：{Type}")
        End Select
    End Function

#Region "基础读取（大端序）"

    Private Sub ReadFull(S As Stream, Buffer As Byte())
        Dim Offset As Integer = 0
        Do While Offset < Buffer.Length
            Dim Count = S.Read(Buffer, Offset, Buffer.Length - Offset)
            If Count <= 0 Then Throw New EndOfStreamException("NBT 数据意外结束")
            Offset += Count
        Loop
    End Sub
    Private Function ReadByte(S As Stream) As Byte
        Dim B = S.ReadByte()
        If B < 0 Then Throw New EndOfStreamException("NBT 数据意外结束")
        Return CByte(B)
    End Function
    Private Function ReadShort(S As Stream) As Short
        Dim B(1) As Byte
        ReadFull(S, B)
        Dim V As Integer = (CInt(B(0)) << 8) Or CInt(B(1))
        If V >= 32768 Then V -= 65536
        Return CShort(V)
    End Function
    Private Function ReadInt(S As Stream) As Integer
        Dim B(3) As Byte
        ReadFull(S, B)
        Dim V As Long = (CLng(B(0)) << 24) Or (CLng(B(1)) << 16) Or (CLng(B(2)) << 8) Or CLng(B(3))
        If V >= 2147483648L Then V -= 4294967296L
        Return CInt(V)
    End Function
    Private Function ReadLong(S As Stream) As Long
        Dim B(7) As Byte
        ReadFull(S, B)
        Array.Reverse(B)
        Return BitConverter.ToInt64(B, 0)
    End Function
    Private Function ReadSingle(S As Stream) As Single
        Dim B(3) As Byte
        ReadFull(S, B)
        Array.Reverse(B)
        Return BitConverter.ToSingle(B, 0)
    End Function
    Private Function ReadDouble(S As Stream) As Double
        Dim B(7) As Byte
        ReadFull(S, B)
        Array.Reverse(B)
        Return BitConverter.ToDouble(B, 0)
    End Function
    Private Function ReadString(S As Stream) As String
        Dim B(1) As Byte
        ReadFull(S, B)
        Dim Length As Integer = (CInt(B(0)) << 8) Or CInt(B(1)) '无符号长度
        If Length = 0 Then Return ""
        Dim Data(Length - 1) As Byte
        ReadFull(S, Data)
        Return Encoding.UTF8.GetString(Data)
    End Function

#End Region

#Region "写入（PCL-QW新增）"

    ''' <summary>
    ''' 将 NBT 标签以 gzip 压缩写入文件（level.dat 等）。
    ''' </summary>
    Public Sub WriteFileGz(FilePath As String, Root As NbtTag, Optional RootName As String = "")
        Using Fs As New FileStream(FilePath, FileMode.Create, FileAccess.Write)
            Using Gz As New GZipStream(Fs, CompressionMode.Compress)
                WriteTag(Gz, RootName, Root)
            End Using
        End Using
    End Sub

    Private Sub WriteTag(S As Stream, Name As String, Tag As NbtTag)
        S.WriteByte(Tag.Type)
        WriteString(S, Name)
        WritePayload(S, Tag.Type, Tag.Value)
    End Sub

    Private Sub WritePayload(S As Stream, Type As Byte, Value As Object)
        Select Case Type
            Case 1
                S.WriteByte(CByte(Value))
            Case 2
                WriteShort(S, CShort(Value))
            Case 3
                WriteInt(S, CInt(Value))
            Case 4
                WriteLong(S, CLng(Value))
            Case 5
                WriteSingle(S, CSng(Value))
            Case 6
                WriteDouble(S, CDbl(Value))
            Case 7
                Dim Data = CType(Value, Byte())
                WriteInt(S, Data.Length)
                S.Write(Data, 0, Data.Length)
            Case 8
                WriteString(S, Value.ToString)
            Case 9
                Dim List = CType(Value, List(Of Object))
                If List.Count = 0 Then
                    WriteByte(S, 0) '与 Minecraft 一致：空列表的元素类型写 TAG_End
                    WriteInt(S, 0)
                Else
                    Dim ElemType As Byte = GetValueType(List(0))
                    WriteByte(S, ElemType)
                    WriteInt(S, List.Count)
                    For Each Item In List
                        WritePayload(S, ElemType, Item)
                    Next
                End If
            Case 10
                Dim Compound = CType(Value, Dictionary(Of String, NbtTag))
                For Each Pair In Compound
                    WriteTag(S, Pair.Key, Pair.Value)
                Next
                S.WriteByte(0) 'TAG_End
            Case 11
                Dim IntList = CType(Value, List(Of Integer))
                WriteInt(S, IntList.Count)
                For Each v In IntList
                    WriteInt(S, v)
                Next
            Case 12
                Dim LongList = CType(Value, List(Of Long))
                WriteInt(S, LongList.Count)
                For Each v In LongList
                    WriteLong(S, v)
                Next
            Case Else
                Throw New Exception($"不支持写入的 NBT 标签类型：{Type}")
        End Select
    End Sub

    Private Function GetValueType(Value As Object) As Byte
        Select Case True
            Case TypeOf Value Is Byte : Return 1
            Case TypeOf Value Is Short : Return 2
            Case TypeOf Value Is Integer : Return 3
            Case TypeOf Value Is Long : Return 4
            Case TypeOf Value Is Single : Return 5
            Case TypeOf Value Is Double : Return 6
            Case TypeOf Value Is Byte() : Return 7
            Case TypeOf Value Is String : Return 8
            Case TypeOf Value Is List(Of Object) : Return 9
            Case TypeOf Value Is Dictionary(Of String, NbtTag) : Return 10
            Case TypeOf Value Is List(Of Integer) : Return 11
            Case TypeOf Value Is List(Of Long) : Return 12
            Case Else : Throw New Exception($"未知的 NBT 值类型：{Value.GetType.Name}")
        End Select
    End Function

    Private Sub WriteByte(S As Stream, V As Byte)
        S.WriteByte(V)
    End Sub
    Private Sub WriteShort(S As Stream, V As Short)
        Dim B(1) As Byte
        B(0) = CByte((CInt(V) >> 8) And &HFF)
        B(1) = CByte(CInt(V) And &HFF)
        S.Write(B, 0, 2)
    End Sub
    Private Sub WriteInt(S As Stream, V As Integer)
        Dim B = BitConverter.GetBytes(V)
        Array.Reverse(B)
        S.Write(B, 0, 4)
    End Sub
    Private Sub WriteLong(S As Stream, V As Long)
        Dim B = BitConverter.GetBytes(V)
        Array.Reverse(B)
        S.Write(B, 0, 8)
    End Sub
    Private Sub WriteSingle(S As Stream, V As Single)
        Dim B = BitConverter.GetBytes(V)
        Array.Reverse(B)
        S.Write(B, 0, 4)
    End Sub
    Private Sub WriteDouble(S As Stream, V As Double)
        Dim B = BitConverter.GetBytes(V)
        Array.Reverse(B)
        S.Write(B, 0, 8)
    End Sub
    Private Sub WriteString(S As Stream, V As String)
        If V Is Nothing Then V = ""
        Dim Data = Encoding.UTF8.GetBytes(V)
        S.WriteByte(CByte((Data.Length >> 8) And &HFF)) '无符号长度
        S.WriteByte(CByte(Data.Length And &HFF))
        S.Write(Data, 0, Data.Length)
    End Sub

    ''' <summary>
    ''' 获取复合标签中的子标签；不存在或类型不符时返回 Nothing。
    ''' </summary>
    Public Function GetChild(Parent As NbtTag, Name As String) As NbtTag
        If Parent Is Nothing OrElse Parent.Type <> 10 Then Return Nothing
        Dim Result As NbtTag = Nothing
        If CType(Parent.Value, Dictionary(Of String, NbtTag)).TryGetValue(Name, Result) Then Return Result Else Return Nothing
    End Function

    ''' <summary>
    ''' 设置复合标签中的子标签；键已存在时保持原有位置。
    ''' </summary>
    Public Sub SetChild(Parent As NbtTag, Name As String, Child As NbtTag)
        If Parent Is Nothing OrElse Parent.Type <> 10 Then Throw New Exception("目标标签不是复合标签，无法设置子项")
        CType(Parent.Value, Dictionary(Of String, NbtTag))(Name) = Child
    End Sub

    ''' <summary>
    ''' 创建一个新的标签。
    ''' </summary>
    Public Function NewTag(Type As Byte, Value As Object) As NbtTag
        Return New NbtTag With {.Type = Type, .Value = Value}
    End Function

#End Region

    ''' <summary>
    ''' 读取 servers.dat 中的服务器列表。返回 (名称, 地址) 列表；失败时返回空列表。
    ''' </summary>
    Public Function ReadServers(FilePath As String) As List(Of (Name As String, Ip As String))
        Dim Result As New List(Of (Name As String, Ip As String))
        Try
            If Not FileUtils.Exists(FilePath) Then Return Result
            Dim Root = ReadFile(FilePath)
            If Root Is Nothing OrElse Root.Type <> 10 Then Return Result
            Dim Compound = CType(Root.Value, Dictionary(Of String, NbtTag))
            Dim ServersTag As NbtTag = Nothing
            If Not Compound.TryGetValue("servers", ServersTag) OrElse ServersTag.Type <> 9 Then Return Result
            For Each Item In CType(ServersTag.Value, List(Of Object))
                Dim Server = CType(Item, Dictionary(Of String, NbtTag))
                Dim ServerName As String = Nothing, ServerIp As String = Nothing
                Dim Tag As NbtTag = Nothing
                If Server.TryGetValue("name", Tag) AndAlso Tag.Type = 8 Then ServerName = Tag.Value.ToString
                If Server.TryGetValue("ip", Tag) AndAlso Tag.Type = 8 Then ServerIp = Tag.Value.ToString
                If String.IsNullOrEmpty(ServerIp) Then Continue For
                Result.Add((If(String.IsNullOrEmpty(ServerName), ServerIp, ServerName), ServerIp))
            Next
        Catch ex As Exception
            Logger.Warn(ex, $"读取服务器列表失败：{FilePath}")
        End Try
        Return Result
    End Function

End Module
