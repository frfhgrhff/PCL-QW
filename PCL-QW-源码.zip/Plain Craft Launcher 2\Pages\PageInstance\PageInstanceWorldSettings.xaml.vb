Public Class PageInstanceWorldSettings

    'PCL-QW新增：启动器内世界设置（游戏模式 / 难度 / 名称 / 允许作弊 / 种子）
    '直接读写 level.dat（gzip NBT）。
    '注意：level.dat 的世界级标签为 GameType（Int）、Difficulty（Byte）、allowCommands（Byte）、
    'LevelName（String）、WorldGenSettings.seed（Long，1.16+）或 generatorSettings JSON（旧版）；
    '玩家自身的模式存于 Data.Player.playerGameType，需一并写入才能立即生效。

    ''' <summary>
    ''' 正在设置的世界文件夹路径（不含结尾的 \）。由世界页在跳转前设置。
    ''' </summary>
    Public Shared EditingWorldPath As String = Nothing

    Private Root As NbtUtils.NbtTag = Nothing
    Private DataTag As NbtUtils.NbtTag = Nothing
    Private SeedInWorldGen As Boolean = False
    Private SeedEditable As Boolean = False
    Private IsLoading As Boolean = False

    Private Sub PageInstanceWorldSettings_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        RefreshUI()
    End Sub

    Private Sub RefreshUI()
        If IsLoading Then Return
        IsLoading = True
        Dim Folder As String = EditingWorldPath
        RunInThread(
        Sub()
            Try
                If Folder Is Nothing OrElse Not DirectoryUtils.Exists(Folder & "\") Then
                    RunInUi(Sub() ShowError("找不到该世界，它可能已被删除或移动。"))
                    Return
                End If
                Dim RawRoot = NbtUtils.ReadFile(Folder & "\level.dat")
                Dim RawData = NbtUtils.GetChild(RawRoot, "Data")
                If RawData Is Nothing Then Throw New Exception("level.dat 结构异常（缺少 Data 标签）")
                '在后台线程完成全部解析，只把结果带回 UI
                Dim FolderName As String = PathUtils.GetLastPart(Folder)
                Dim VerText As String = If(NbtUtils.GetChild(NbtUtils.GetChild(RawData, "Version"), "Name")?.Value?.ToString, "未知")
                Dim LastPlayedText As String = "未知"
                Dim LastPlayedTag = NbtUtils.GetChild(RawData, "LastPlayed")
                If LastPlayedTag IsNot Nothing Then
                    Try
                        LastPlayedText = DateTimeOffset.FromUnixTimeSeconds(CLng(LastPlayedTag.Value) \ 1000L).LocalDateTime.ToString("yyyy-MM-dd HH:mm")
                    Catch ex As Exception
                        Logger.Warn(ex, "解析最后游玩时间失败")
                    End Try
                End If
                Dim NameText As String = If(NbtUtils.GetChild(RawData, "LevelName")?.Value?.ToString, "")
                '游戏模式：优先世界级 GameType，其次玩家级 playerGameType
                Dim ModeIndex As Integer = 0
                Dim GameTypeTag = NbtUtils.GetChild(RawData, "GameType")
                If GameTypeTag IsNot Nothing Then
                    ModeIndex = CInt(GameTypeTag.Value)
                Else
                    Dim PlayerTag = NbtUtils.GetChild(RawData, "Player")
                    Dim PlayerMode = NbtUtils.GetChild(PlayerTag, "playerGameType")
                    If PlayerMode IsNot Nothing Then ModeIndex = CInt(PlayerMode.Value)
                End If
                '难度：世界级 Difficulty
                Dim DifficultyTag = NbtUtils.GetChild(RawData, "Difficulty")
                Dim DifficultyIndex As Integer = If(DifficultyTag Is Nothing, 1, CInt(DifficultyTag.Value))
                '允许作弊
                Dim AllowTag = NbtUtils.GetChild(RawData, "allowCommands")
                Dim AllowValue As Boolean = AllowTag IsNot Nothing AndAlso CInt(AllowTag.Value) = 1
                '极限模式
                Dim HardcoreTag = NbtUtils.GetChild(RawData, "hardcore")
                Dim IsHardcore As Boolean = HardcoreTag IsNot Nothing AndAlso CInt(HardcoreTag.Value) = 1
                '种子
                Dim HasSeed As Boolean = False
                Dim SeedText As String = ""
                Dim InWGS As Boolean = False
                Dim SeedTag = NbtUtils.GetChild(NbtUtils.GetChild(RawData, "WorldGenSettings"), "seed")
                If SeedTag IsNot Nothing AndAlso TypeOf SeedTag.Value Is Long Then
                    HasSeed = True
                    InWGS = True
                    SeedText = CLng(SeedTag.Value).ToString
                Else
                    Dim Gen = NbtUtils.GetChild(RawData, "generatorSettings")
                    Try
                        If Gen IsNot Nothing Then
                            Dim Json = Newtonsoft.Json.Linq.JObject.Parse(Gen.Value.ToString)
                            If Json("seed") IsNot Nothing Then
                                HasSeed = True
                                SeedText = CLng(Json("seed")).ToString
                            End If
                        End If
                    Catch ex As Exception
                        Logger.Warn(ex, "解析 generatorSettings 失败")
                    End Try
                End If
                Dim HasBackup As Boolean = FileUtils.Exists(Folder & "\level.dat.bak")
                '回到 UI 线程填充
                RunInUi(
                Sub()
                    Try
                        Root = RawRoot
                        DataTag = RawData
                        CardError.Visibility = Visibility.Collapsed
                        CardSettings.Visibility = Visibility.Visible
                        LabFolder.Text = FolderName
                        LabVersion.Text = VerText
                        LabLastPlayed.Text = LastPlayedText
                        TextName.Text = NameText
                        ComboMode.SelectedIndex = Math.Max(0, Math.Min(3, ModeIndex))
                        ComboDifficulty.SelectedIndex = Math.Max(0, Math.Min(3, DifficultyIndex))
                        CheckAllow.Checked = AllowValue
                        LabHardcore.Visibility = If(IsHardcore, Visibility.Visible, Visibility.Collapsed)
                        SeedEditable = HasSeed
                        SeedInWorldGen = InWGS
                        TextSeed.IsEnabled = HasSeed
                        If HasSeed Then
                            TextSeed.Text = SeedText
                            LabSeedMode.Text = If(InWGS, "种子来源：WorldGenSettings（1.16 及以上版本）", "种子来源：generatorSettings（旧版本）")
                        Else
                            TextSeed.Text = ""
                            LabSeedMode.Text = "未在该世界中找到种子字段，种子不可修改。"
                        End If
                        BtnRestore.IsEnabled = HasBackup
                    Catch ex As Exception
                        Logger.Error(ex, "填充世界设置界面失败")
                        ShowError(ex.Message)
                    Finally
                        IsLoading = False
                    End Try
                End Sub)
            Catch ex As Exception
                Logger.Warn(ex, "读取世界设置失败")
                RunInUi(Sub() ShowError(ex.Message))
                IsLoading = False
            End Try
        End Sub)
    End Sub

    Private Sub ShowError(Msg As String)
        LabError.Text = "无法读取该世界的设置：" & vbCrLf & Msg & vbCrLf & vbCrLf & "请确认游戏已关闭，且世界未被损坏。"
        CardError.Visibility = Visibility.Visible
        CardSettings.Visibility = Visibility.Collapsed
        IsLoading = False
    End Sub

    '保存
    Private Sub BtnSave_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnSave.Click
        Try
            Dim Folder As String = EditingWorldPath
            If Folder Is Nothing OrElse DataTag Is Nothing Then Return
            Dim NewName As String = TextName.Text.Trim
            If NewName = "" Then
                Hint("世界名称不能为空！", HintType.Red)
                Return
            End If
            Dim NewSeed As Long = 0
            If SeedEditable Then
                If Not Long.TryParse(TextSeed.Text.Trim, NewSeed) Then
                    Hint("种子必须是整数（可为负数）！", HintType.Red)
                    Return
                End If
            End If
            Dim Msg As String = $"即将保存世界设置：{vbCrLf}世界名称：{NewName}{vbCrLf}游戏模式：{CType(ComboMode.SelectedItem, MyComboBoxItem).Content}{vbCrLf}难度：{CType(ComboDifficulty.SelectedItem, MyComboBoxItem).Content}{vbCrLf}允许作弊：{If(CheckAllow.Checked, "开启", "关闭")}"
            If SeedEditable Then Msg &= $"{vbCrLf}种子：{NewSeed}{vbCrLf}{vbCrLf}（已探索的区域不受影响，仅新区域使用新种子）"
            Msg &= $"{vbCrLf}{vbCrLf}保存前会自动备份为 level.dat.bak。请确保游戏已关闭。是否继续？"
            If MyMsgBox(Msg, "保存世界设置", "保存", "取消") <> 1 Then Return
            '备份
            System.IO.File.Copy(Folder & "\level.dat", Folder & "\level.dat.bak", True)
            '写入各项（使用 level.dat 的真实键名）
            NbtUtils.SetChild(DataTag, "LevelName", NbtUtils.NewTag(8, NewName))
            NbtUtils.SetChild(DataTag, "GameType", NbtUtils.NewTag(3, ComboMode.SelectedIndex))
            NbtUtils.SetChild(DataTag, "Difficulty", NbtUtils.NewTag(1, CByte(ComboDifficulty.SelectedIndex)))
            NbtUtils.SetChild(DataTag, "allowCommands", NbtUtils.NewTag(1, CByte(If(CheckAllow.Checked, 1, 0))))
            '玩家自身的模式也要同步，否则进入世界后仍是玩家存档里的模式
            Dim PlayerTag = NbtUtils.GetChild(DataTag, "Player")
            If PlayerTag IsNot Nothing Then
                NbtUtils.SetChild(PlayerTag, "playerGameType", NbtUtils.NewTag(3, ComboMode.SelectedIndex))
                '创造/旁观模式下补齐玩家能力，避免进入后无法飞行
                If ComboMode.SelectedIndex >= 1 Then
                    Dim Abilities = NbtUtils.GetChild(PlayerTag, "abilities")
                    If Abilities IsNot Nothing Then
                        Dim MayFly As Byte = CByte(If(ComboMode.SelectedIndex = 1 OrElse ComboMode.SelectedIndex = 3, 1, 0))
                        NbtUtils.SetChild(Abilities, "mayfly", NbtUtils.NewTag(1, MayFly))
                        NbtUtils.SetChild(Abilities, "invulnerable", NbtUtils.NewTag(1, MayFly))
                        If ComboMode.SelectedIndex = 1 Then
                            NbtUtils.SetChild(Abilities, "flying", NbtUtils.NewTag(1, CByte(0)))
                            NbtUtils.SetChild(Abilities, "mayBuild", NbtUtils.NewTag(1, CByte(1)))
                        End If
                    End If
                End If
            End If
            '清理早期版本误写入的小写残留键（level.dat 不使用这两个键）
            Dim Dict = CType(DataTag.Value, Dictionary(Of String, NbtUtils.NbtTag))
            Dict.Remove("playerGameType")
            Dict.Remove("difficulty")
            '种子
            If SeedEditable Then
                If SeedInWorldGen Then
                    NbtUtils.SetChild(NbtUtils.GetChild(DataTag, "WorldGenSettings"), "seed", NbtUtils.NewTag(4, NewSeed))
                Else
                    Dim Json = Newtonsoft.Json.Linq.JObject.Parse(NbtUtils.GetChild(DataTag, "generatorSettings").Value.ToString)
                    Json("seed") = NewSeed
                    NbtUtils.SetChild(DataTag, "generatorSettings", NbtUtils.NewTag(8, Json.ToString(Newtonsoft.Json.Formatting.None)))
                End If
            End If
            '写回
            NbtUtils.WriteFileGz(Folder & "\level.dat", Root)
            Hint("世界设置已保存！", HintType.Green)
            RefreshUI()
        Catch ex As Exception
            Logger.Error(ex, "保存世界设置失败（文件可能被游戏占用）", LogBehavior.Alert)
        End Try
    End Sub

    '还原
    Private Sub BtnRestore_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnRestore.Click
        Try
            Dim Folder As String = EditingWorldPath
            If Folder Is Nothing Then Return
            If Not FileUtils.Exists(Folder & "\level.dat.bak") Then
                Hint("没有可用的备份文件。", HintType.Red)
                Return
            End If
            If MyMsgBox("将用上次保存前的备份覆盖当前世界设置，是否继续？", "还原备份", "还原", "取消", IsWarn:=True) <> 1 Then Return
            System.IO.File.Copy(Folder & "\level.dat.bak", Folder & "\level.dat", True)
            Hint("已还原到备份版本！", HintType.Green)
            RefreshUI()
        Catch ex As Exception
            Logger.Error(ex, "还原世界设置备份失败", LogBehavior.Alert)
        End Try
    End Sub

    '返回
    Private Sub BtnBack_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnBack.Click, BtnBackError.Click
        FrmInstanceLeft.PageChange(FormMain.PageSubType.InstanceWorld)
    End Sub

End Class
