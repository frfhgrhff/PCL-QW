Imports System.IO

''' <summary>
''' PCL-QW新增：服务器控制台控件（供顶部「服务器」页与实例页「创建服务器」共用）。
''' 纯代码构建，宿主页面负责把它放进 MyCard 里。
''' </summary>
Public Class ServerConsoleUI
    Inherits StackPanel

    Private ReadOnly Folder As String
    Private ReadOnly Instance As McInstance
    Private Current As RunningServer

    Private LabStatus As TextBlock
    Private BtnStart As MyButton
    Private BtnStop As MyButton
    Private BtnLink As MyButton
    Private BtnFolder As MyButton
    Private BtnDelete As MyButton
    Private BtnRefresh As MyButton
    Private TxtLog As MyTextBox
    Private TxtCmd As MyTextBox
    Private BtnSend As MyButton

    ''' <summary>
    ''' 服务器状态发生变化时回调（用于让宿主页面刷新列表）。
    ''' </summary>
    Public Event StatusChanged()

    Public Sub New(Folder As String, Instance As McInstance)
        Me.Folder = Folder
        Me.Instance = Instance
        BuildUi()
        Rebind()
    End Sub

    Public ReadOnly Property ServerFolder As String
        Get
            Return Folder
        End Get
    End Property

    Private Sub BuildUi()
        Margin = New Thickness(0)

        '状态行
        LabStatus = New TextBlock With {
            .Text = "未运行",
            .TextWrapping = TextWrapping.Wrap,
            .Margin = New Thickness(0, 0, 0, 8),
            .FontSize = 12,
            .Opacity = 0.8
        }
        Children.Add(LabStatus)

        Dim Buttons As New WrapPanel With {.Margin = New Thickness(0, 0, 0, 10)}
        BtnStart = New MyButton With {.Text = "启动", .MinWidth = 100, .Padding = New Thickness(13, 0, 13, 0), .Margin = New Thickness(0, 0, 16, 0), .Height = 35}
        BtnStop = New MyButton With {.Text = "停止", .MinWidth = 100, .Padding = New Thickness(13, 0, 13, 0), .Margin = New Thickness(0, 0, 16, 0), .Height = 35}
        BtnLink = New MyButton With {.Text = "联机直通", .MinWidth = 100, .Padding = New Thickness(13, 0, 13, 0), .Margin = New Thickness(0, 0, 16, 0), .Height = 35}
        BtnFolder = New MyButton With {.Text = "打开文件夹", .MinWidth = 100, .Padding = New Thickness(13, 0, 13, 0), .Margin = New Thickness(0, 0, 16, 0), .Height = 35}
        BtnRefresh = New MyButton With {.Text = "刷新", .MinWidth = 80, .Padding = New Thickness(13, 0, 13, 0), .Margin = New Thickness(0, 0, 16, 0), .Height = 35}
        BtnDelete = New MyButton With {.Text = "删除", .MinWidth = 80, .Padding = New Thickness(13, 0, 13, 0), .Height = 35, .ColorType = MyButton.ColorState.Red}
        Buttons.Children.Add(BtnStart)
        Buttons.Children.Add(BtnStop)
        Buttons.Children.Add(BtnLink)
        Buttons.Children.Add(BtnFolder)
        Buttons.Children.Add(BtnRefresh)
        Buttons.Children.Add(BtnDelete)
        Children.Add(Buttons)

        '日志
        TxtLog = New MyTextBox With {
            .IsReadOnly = True,
            .TextWrapping = TextWrapping.NoWrap,
            .VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            .HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
            .Height = 280,
            .FontFamily = New FontFamily("Consolas, Microsoft YaHei UI"),
            .FontSize = 12,
            .Margin = New Thickness(0, 0, 0, 10)
        }
        Children.Add(TxtLog)

        '指令行
        Dim CmdLine As New Grid
        CmdLine.ColumnDefinitions.Add(New ColumnDefinition With {.Width = New GridLength(1, GridUnitType.Star)})
        CmdLine.ColumnDefinitions.Add(New ColumnDefinition With {.Width = GridLength.Auto})
        TxtCmd = New MyTextBox With {.HintText = "输入服务器指令，例如 list、say 你好、stop", .Height = 34, .VerticalContentAlignment = VerticalAlignment.Center}
        BtnSend = New MyButton With {.Text = "发送", .MinWidth = 80, .Height = 34, .Margin = New Thickness(12, 0, 0, 0)}
        Grid.SetColumn(TxtCmd, 0)
        Grid.SetColumn(BtnSend, 1)
        CmdLine.Children.Add(TxtCmd)
        CmdLine.Children.Add(BtnSend)
        Children.Add(CmdLine)

        AddHandler BtnStart.Click, AddressOf BtnStart_Click
        AddHandler BtnStop.Click, AddressOf BtnStop_Click
        AddHandler BtnLink.Click, AddressOf BtnLink_Click
        AddHandler BtnFolder.Click, AddressOf BtnFolder_Click
        AddHandler BtnRefresh.Click, Sub() Rebind()
        AddHandler BtnDelete.Click, AddressOf BtnDelete_Click
        AddHandler BtnSend.Click, AddressOf BtnSend_Click
        AddHandler TxtCmd.KeyDown,
        Sub(sender As Object, e As Windows.Input.KeyEventArgs)
            If e.Key = Windows.Input.Key.Enter Then BtnSend_Click(sender, e)
        End Sub
    End Sub

    ''' <summary>
    ''' 重新绑定当前运行中的服务器，并回填历史日志。
    ''' </summary>
    Public Sub Rebind()
        Try
            Current = GetRunning(Folder)
            TxtLog.Clear()
            If Current IsNot Nothing Then
                For Each Line In Current.Lines.ToArray()
                    AppendLine(Line, False)
                Next
                ScrollToEnd()
            End If
            UpdateStatus()
        Catch ex As Exception
            Logger.Error(ex, "刷新服务器控制台失败", LogBehavior.Alert)
        End Try
    End Sub

    Private Sub Attach(Server As RunningServer)
        AddHandler Server.OutputLine, AddressOf OnOutputLine
        AddHandler Server.Exited, AddressOf OnExited
    End Sub
    Private Sub Detach(Server As RunningServer)
        If Server Is Nothing Then Return
        Try
            RemoveHandler Server.OutputLine, AddressOf OnOutputLine
            RemoveHandler Server.Exited, AddressOf OnExited
        Catch ex As Exception
        End Try
    End Sub

    Private Sub OnOutputLine(Line As String)
        RunInUi(Sub() AppendLine(Line))
    End Sub
    Private Sub OnExited()
        RunInUi(
        Sub()
            Detach(Current)
            Current = Nothing
            TxtLog.AppendText($"[{Date.Now:HH:mm:ss}] 服务器已退出{vbCrLf}")
            ScrollToEnd()
            UpdateStatus()
        End Sub)
    End Sub

    Private Sub AppendLine(Line As String, Optional AppendNewLine As Boolean = True)
        Try
            '避免无限增长拖慢界面
            If TxtLog.LineCount > 4000 Then
                Dim Text = TxtLog.Text
                Dim Cut = Text.IndexOf(vbLf, Text.Length \ 2)
                If Cut > 0 Then TxtLog.Text = Text.Substring(Cut + 1)
            End If
            TxtLog.AppendText(Line & If(AppendNewLine, vbCrLf, ""))
            ScrollToEnd()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ScrollToEnd()
        Try
            TxtLog.ScrollToEnd()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub UpdateStatus()
        Try
            RaiseEvent StatusChanged()
            Dim Running = Current IsNot Nothing
            BtnStart.IsEnabled = Not Running AndAlso HasServer(Folder)
            BtnStop.IsEnabled = Running
            BtnLink.IsEnabled = True
            BtnDelete.IsEnabled = Not Running
            TxtCmd.IsEnabled = Running
            BtnSend.IsEnabled = Running
            If Not HasServer(Folder) Then
                LabStatus.Text = "尚未安装服务端，请先创建。"
                Return
            End If
            Dim Port = GetServerPort(Folder)
            If Running Then
                Dim Span = Date.Now - Current.StartedAt
                LabStatus.Text = $"运行中　·　端口 {Port}　·　已运行 {CInt(Span.TotalMinutes)} 分 {Span.Seconds} 秒"
            Else
                LabStatus.Text = $"未运行　·　端口 {Port}　·　{Path.GetFileName(FindServerJar(Folder))}"
            End If
        Catch ex As Exception
            Logger.Warn(ex, "更新服务器状态失败")
        End Try
    End Sub

#Region "按钮"

    Private Sub BtnStart_Click(sender As Object, e As EventArgs)
        StartInBackground()
    End Sub

    ''' <summary>
    ''' 在后台线程启动服务器：解析 Java 需求会联网，必要时还会下载 Java，都不能在 UI 线程执行。
    ''' </summary>
    Private Sub StartInBackground()
        Try
            If Current IsNot Nothing Then Return
            RunInThread(
            Sub()
                Try
                    Dim Server = StartServer(Folder, Instance)
                    If Server Is Nothing Then Return '用户在 EULA 弹窗中取消
                    RunInUi(
                    Sub()
                        Detach(Current)
                        Current = Server
                        Attach(Server)
                        Hint("服务器已启动！", HintType.Green)
                        UpdateStatus()
                    End Sub)
                Catch ex As Exception
                    Logger.Error(ex, "启动服务器失败", LogBehavior.Alert)
                    RunInUi(AddressOf UpdateStatus)
                End Try
            End Sub)
        Catch ex As Exception
            Logger.Error(ex, "启动服务器失败", LogBehavior.Alert)
        End Try
    End Sub

    Private Sub BtnStop_Click(sender As Object, e As EventArgs)
        Try
            If Current Is Nothing Then Return
            Hint("正在停止服务器，请稍候……", HintType.Blue)
            RunInThread(Sub() StopServer(Current))
        Catch ex As Exception
            Logger.Error(ex, "停止服务器失败", LogBehavior.Alert)
        End Try
    End Sub

    Private Sub BtnFolder_Click(sender As Object, e As EventArgs)
        Try
            DirectoryUtils.Create(Folder)
            OpenExplorer(Folder)
        Catch ex As Exception
            Logger.Error(ex, "打开服务器文件夹失败", LogBehavior.Alert)
        End Try
    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs)
        Try
            If MyMsgBox($"确定要删除该服务器吗？{vbCrLf}文件夹：{Folder}{vbCrLf}{vbCrLf}世界存档等全部内容都会被移入系统回收站。", "删除服务器", "删除", "取消", IsWarn:=True) <> 1 Then Return
            FileUtils.Delete(Folder, True)
            Hint("已删除服务器，可在回收站中找回。", HintType.Green)
            Rebind()
        Catch ex As Exception
            Logger.Error(ex, "删除服务器失败", LogBehavior.Alert)
        End Try
    End Sub

    ''' <summary>
    ''' 联机直通：确保陶瓦联机已启动，并让「联机」页立即以房主身份扫描本地服务器。
    ''' </summary>
    Private Sub BtnLink_Click(sender As Object, e As EventArgs)
        Try
            Dim NeedStart = Current Is Nothing
            If NeedStart Then
                If MyMsgBox("联机直通需要先启动服务器。是否现在启动？", "联机直通", "启动并继续", "取消") <> 1 Then Return
            End If
            RunInThread(
            Sub()
                Try
                    If NeedStart Then
                        Dim Server = StartServer(Folder, Instance)
                        If Server Is Nothing Then Return '用户在 EULA 弹窗中取消
                        RunInUi(
                        Sub()
                            Detach(Current)
                            Current = Server
                            Attach(Server)
                            UpdateStatus()
                        End Sub)
                    End If
                    If Not ModTerracotta.IsInstalled() Then
                        RunInUi(Sub() FrmMain.PageChange(FormMain.PageType.Link, FormMain.PageSubType.LinkMain))
                        Return
                    End If
                    ModTerracotta.EnsureStarted()
                    PageLinkMain.PendingHost = True
                    RunInUi(Sub() FrmMain.PageChange(FormMain.PageType.Link, FormMain.PageSubType.LinkMain))
                Catch ex As Exception
                    Logger.Error(ex, "联机直通失败", LogBehavior.Alert)
                End Try
            End Sub)
        Catch ex As Exception
            Logger.Error(ex, "联机直通失败", LogBehavior.Alert)
        End Try
    End Sub

    Private Sub BtnSend_Click(sender As Object, e As EventArgs)
        Try
            Dim Text = TxtCmd.Text.Trim
            If Text = "" Then Return
            If Current Is Nothing Then
                Hint("服务器未在运行。", HintType.Red)
                Return
            End If
            ModServer.SendCommand(Current, Text)
            TxtCmd.Clear()
        Catch ex As Exception
            Logger.Error(ex, "发送指令失败", LogBehavior.Alert)
        End Try
    End Sub

#End Region

End Class
