Public Class PageInstanceFile

    'PCL-QW新增：文件与文件夹快捷入口页面

    Private Sub PageInstanceFile_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        RefreshList()
    End Sub
    Private Sub BtnRefresh_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnRefresh.Click
        RefreshList()
        Hint("已刷新！", HintType.Green, False)
    End Sub

    Private Sub RefreshList()
        Try
            PanList.Children.Clear()
            Dim Instance = PageInstanceLeft.Instance
            If Instance Is Nothing Then Return
            Dim Base As String = Instance.PathIndie
            '文件夹快捷方式
            AddShortcut("游戏文件夹", Base)
            AddShortcut("Mod 文件夹", Base & "mods\")
            AddShortcut("存档文件夹", Base & "saves\")
            AddShortcut("资源包文件夹", Base & "resourcepacks\")
            AddShortcut("光影包文件夹", Base & "shaderpacks\")
            AddShortcut("配置文件夹", Base & "config\")
            AddShortcut("截图文件夹", Base & "screenshots\")
            AddShortcut("游戏日志文件夹", Base & "logs\")
            AddShortcut("崩溃报告文件夹", Base & "crash-reports\")
            '文件快捷方式
            AddShortcut("游戏设置 options.txt", Base & "options.txt", IsFile:=True)
            AddShortcut("服务器列表 servers.dat", Base & "servers.dat", IsFile:=True)
            '版本数据
            AddShortcut("版本文件夹", Instance.PathVersion)
            AddShortcut("版本数据（PCL 设置等）", Instance.PathVersion & "PCL\")
        Catch ex As Exception
            Logger.Error(ex, "加载文件列表失败")
        End Try
    End Sub

    Private Sub AddShortcut(Name As String, Path As String, Optional IsFile As Boolean = False)
        Dim Item As New MyListItem With {
            .Title = Name,
            .Info = Path,
            .Height = 40,
            .Type = MyListItem.CheckType.Clickable,
            .LogoScale = 0.95,
            .MinPaddingRight = 10,
            .Logo = Logo.IconButtonOpen
        }
        AddHandler Item.Click,
        Sub()
            Try
                If IsFile Then
                    If FileUtils.Exists(Path) Then
                        OpenExplorer(Path)
                    Else
                        DirectoryUtils.Create(PathUtils.RemoveLastPart(Path) & "\")
                        OpenExplorer(PathUtils.RemoveLastPart(Path) & "\")
                        Hint("该文件尚不存在，已打开所在文件夹。", Log:=False)
                    End If
                Else
                    DirectoryUtils.Create(Path)
                    OpenExplorer(Path)
                End If
            Catch ex As Exception
                Logger.Error(ex, "打开文件夹失败", LogBehavior.Alert)
            End Try
        End Sub
        PanList.Children.Add(Item)
    End Sub

End Class
