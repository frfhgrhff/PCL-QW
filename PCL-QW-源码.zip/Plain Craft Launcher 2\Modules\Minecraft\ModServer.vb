Imports System.IO
Imports System.Text.RegularExpressions
Imports Newtonsoft.Json.Linq

''' <summary>
''' PCL-QW新增：本地 Minecraft 服务器（服务端）的下载、初始化与运行管理。
''' 服务器固定创建在实例自己的文件夹内：versions\&lt;实例名&gt;\server\
''' </summary>
Public Module ModServer

    ''' <summary>
    ''' 服务端种类。
    ''' </summary>
    Public Enum ServerLoaderKind
        Vanilla = 0
        Fabric = 1
        Forge = 2
        NeoForge = 3
    End Enum

    Public Class ServerInstallRequest
        Public Instance As McInstance
        Public VanillaVersion As String
        Public Loader As ServerLoaderKind = ServerLoaderKind.Vanilla
        ''' <summary>
        ''' 是否在下载完成后自动接受 EULA。为 False 时会弹窗询问用户。
        ''' </summary>
        Public AcceptEula As Boolean = False
    End Class

    Public Class ServerInfo
        Public Name As String
        Public Folder As String
        Public JarName As String
        Public Version As String
        Public Loader As ServerLoaderKind
        Public LastWrite As Date
        Public ReadOnly Property Running As Boolean
            Get
                Return GetRunning(Folder) IsNot Nothing
            End Get
        End Property
    End Class

    Private Const EulaUrl As String = "https://account.mojang.com/documents/minecraft_eula"

#Region "路径"

    ''' <summary>
    ''' 实例对应的服务器文件夹，以 \ 结尾。
    ''' </summary>
    Public Function ServerFolder(Instance As McInstance) As String
        Return Instance.PathVersion & "server\"
    End Function
    Public Function ServerFolder(InstanceName As String) As String
        Return McFolderSelected & "versions\" & InstanceName & "\server\"
    End Function

    ''' <summary>
    ''' 该文件夹内是否已经存在服务端。
    ''' </summary>
    Public Function HasServer(Folder As String) As Boolean
        Return HasServerLauncher(Folder)
    End Function

    ''' <summary>
    ''' 找出文件夹内的服务端启动目标。
    ''' 原版与 Fabric 是直接下载到的 jar；Forge / NeoForge 的安装器会生成 run.bat，
    ''' 服务端 jar 藏在 libraries 里，不能直接当顶层 jar 用。
    ''' </summary>
    Public Function FindServerJar(Folder As String) As String
        Try
            Dim DirInfo As New DirectoryInfo(Folder)
            If Not DirInfo.Exists Then Return Nothing
            Dim Candidates = DirInfo.EnumerateFiles("*.jar").
                Where(Function(f) Not f.Name.ToLowerInvariant().Contains("installer") AndAlso Not f.Name.ToLowerInvariant().Contains("launch4j")).
                OrderByDescending(Function(f) f.Length).ToList()
            If Candidates.Any Then
                '优先名字里带 server 的
                Dim Preferred = Candidates.FirstOrDefault(Function(f) f.Name.ToLowerInvariant().Contains("server"))
                Return If(Preferred, Candidates.First).FullName
            End If
            'Forge / NeoForge：安装器会把服务端 jar 放进 libraries
            Dim Nested = DirInfo.EnumerateFiles("*server*.jar", SearchOption.AllDirectories).
                Where(Function(f) f.Length > 1024 * 1024).
                OrderByDescending(Function(f) f.Length).FirstOrDefault()
            If Nested IsNot Nothing Then Return Nested.FullName
        Catch ex As Exception
            Logger.Warn(ex, "查找服务端文件失败")
        End Try
        Return Nothing
    End Function

    ''' <summary>
    ''' 该文件夹是否已经是一个可用的服务器（jar 或安装器生成的 run.bat）。
    ''' </summary>
    Public Function HasServerLauncher(Folder As String) As Boolean
        Return FindServerJar(Folder) IsNot Nothing OrElse FileUtils.Exists(Folder & "run.bat")
    End Function

    ''' <summary>
    ''' 列出所有实例中已创建的服务器。
    ''' </summary>
    Public Function EnumerateServers() As List(Of ServerInfo)
        Dim Result As New List(Of ServerInfo)
        Try
            For Each Card In McInstanceList
                For Each Instance In Card.Value
                    Dim Folder = ServerFolder(Instance)
                    If Not HasServer(Folder) Then Continue For
                    Dim Jar = FindServerJar(Folder)
                    Dim Info As New ServerInfo With {
                        .Name = Instance.Name,
                        .Folder = Folder,
                        .JarName = If(Jar IsNot Nothing, Path.GetFileName(Jar), "run.bat"),
                        .LastWrite = Directory.GetLastWriteTime(Folder)
                    }
                    Dim Meta = ReadMeta(Folder)
                    Info.Version = If(Meta.Version, Instance.Version.VanillaName)
                    Info.Loader = Meta.Loader
                    Result.Add(Info)
                Next
            Next
        Catch ex As Exception
            Logger.Warn(ex, "枚举服务器列表失败")
        End Try
        Return Result
    End Function

    ''' <summary>
    ''' 记录在 pcl-server.json 中的服务器元信息。
    ''' </summary>
    Private Function ReadMeta(Folder As String) As (Version As String, Loader As ServerLoaderKind, JavaMajor As Integer)
        Try
            Dim MetaPath = Folder & "pcl-server.json"
            If Not FileUtils.Exists(MetaPath) Then Return (Nothing, ServerLoaderKind.Vanilla, 0)
            Dim Json = CType(FileUtils.ReadAsJson(MetaPath), JObject)
            Dim VersionText = Json("version")?.ToString
            Dim Major = Val(Json("javaMajor")?.ToString)
            Dim Kind As ServerLoaderKind = ServerLoaderKind.Vanilla
            Select Case Json("loader")?.ToString
                Case "Fabric" : Kind = ServerLoaderKind.Fabric
                Case "Forge" : Kind = ServerLoaderKind.Forge
                Case "NeoForge" : Kind = ServerLoaderKind.NeoForge
            End Select
            Return (VersionText, Kind, Major)
        Catch ex As Exception
            Logger.Warn(ex, "读取服务器信息失败")
            Return (Nothing, ServerLoaderKind.Vanilla, 0)
        End Try
    End Function

    Private Sub WriteMeta(Folder As String, Version As String, Loader As ServerLoaderKind, JavaMajor As Integer)
        Try
            Dim Json As New JObject From {
                {"version", Version},
                {"loader", Loader.ToString()},
                {"javaMajor", JavaMajor},
                {"created", Date.Now.ToString("yyyy-MM-dd HH:mm:ss")}
            }
            System.IO.File.WriteAllText(Folder & "pcl-server.json", Json.ToString(Formatting.Indented), New UTF8Encoding(False))
        Catch ex As Exception
            Logger.Warn(ex, "写入服务器信息失败")
        End Try
    End Sub

    Private ReadOnly JavaMajorCache As New Dictionary(Of String, Integer)(StringComparer.OrdinalIgnoreCase)
    ''' <summary>
    ''' 取得某个原版版本所需的 Java 主版本号（例如 1.20.5 需要 21，26.x 需要 25）。取不到时返回 0。
    ''' </summary>
    Public Function ResolveJavaMajor(VanillaVersion As String) As Integer
        If String.IsNullOrEmpty(VanillaVersion) Then Return 0
        If JavaMajorCache.ContainsKey(VanillaVersion) Then Return JavaMajorCache(VanillaVersion)
        Dim Major As Integer = 0
        Try
            Dim JsonAddress = DlClientListGet(VanillaVersion)
            If JsonAddress IsNot Nothing Then
                Dim Json = CType(NetRequestByClientRetry(DlSourceLauncherOrMetaGet(JsonAddress).First, Encoding:=Encoding.UTF8, RequireJson:=True).DeserializeJson(), JObject)
                Major = Val(Json("javaVersion")?("majorVersion")?.ToString)
            End If
        Catch ex As Exception
            Logger.Warn(ex, $"获取 {VanillaVersion} 的 Java 需求失败")
        End Try
        JavaMajorCache(VanillaVersion) = Major
        Return Major
    End Function

#End Region

#Region "安装"

    ''' <summary>
    ''' 生成安装服务端所需的加载器列表。
    ''' </summary>
    Public Function ServerInstallLoaders(Request As ServerInstallRequest) As List(Of LoaderBase)
        Dim DownloadFiles As New List(Of NetFile)
        Dim ResolvedVersion As String = Nothing
        Dim ResolvedLoader As ServerLoaderKind = Request.Loader
        Dim Installers As New List(Of String)

        Dim LoaderPrepare As New LoaderTask(Of Integer, Integer)("准备服务器文件夹",
        Sub(Task As LoaderTask(Of Integer, Integer))
            DirectoryUtils.Create(ServerFolder(Request.Instance))
            Task.Output = 1
        End Sub) With {.ProgressWeight = 1}

        Dim LoaderGetVersion As New LoaderTask(Of Integer, List(Of NetFile))("获取服务端下载地址",
        Sub(Task As LoaderTask(Of Integer, List(Of NetFile)))
            Select Case Request.Loader
                Case ServerLoaderKind.Fabric
                    Dim LoaderVersion = ResolveFabricServerLoader(Request.VanillaVersion)
                    ResolvedLoader = ServerLoaderKind.Fabric
                    ResolvedVersion = Request.VanillaVersion & " Fabric " & LoaderVersion
                    DownloadFiles.Add(New NetFile(
                        {FabricServerJarUrl(Request.VanillaVersion, LoaderVersion)},
                        ServerFolder(Request.Instance) & $"fabric-server-{Request.VanillaVersion}-{LoaderVersion}.jar",
                        New FileChecker With {.MinSize = 1024 * 512}))
                Case ServerLoaderKind.Forge
                    Dim ForgeVersion = ResolveLatestForge(Request.VanillaVersion)
                    ResolvedLoader = ServerLoaderKind.Forge
                    ResolvedVersion = Request.VanillaVersion & " Forge " & ForgeVersion
                    Installers.Add($"https://maven.minecraftforge.net/net/minecraftforge/forge/{Request.VanillaVersion}-{ForgeVersion}/forge-{Request.VanillaVersion}-{ForgeVersion}-installer.jar")
                Case ServerLoaderKind.NeoForge
                    Dim NeoVersion = ResolveLatestNeoForge(Request.VanillaVersion)
                    ResolvedLoader = ServerLoaderKind.NeoForge
                    ResolvedVersion = Request.VanillaVersion & " NeoForge " & NeoVersion
                    Installers.Add($"https://maven.neoforged.net/releases/net/neoforged/neoforge/{NeoVersion}/neoforge-{NeoVersion}-installer.jar")
                Case Else
                    Dim JsonAddress = DlClientListGet(Request.VanillaVersion)
                    If JsonAddress Is Nothing Then Throw New Exception($"没有找到版本 {Request.VanillaVersion} 的信息。")
                    Dim Json = CType(NetRequestByClientRetry(DlSourceLauncherOrMetaGet(JsonAddress).First, Encoding:=Encoding.UTF8, RequireJson:=True).DeserializeJson(), JObject)
                    Dim Server = Json("downloads")?("server")
                    If Server Is Nothing Then Throw New Exception($"版本 {Request.VanillaVersion} 没有可用的服务端下载信息。")
                    ResolvedVersion = Request.VanillaVersion
                    Dim ServerUrl = Server("url").ToString
                    DownloadFiles.Add(New NetFile(
                        DlSourceLauncherOrMetaGet(ServerUrl),
                        ServerFolder(Request.Instance) & $"{Request.VanillaVersion}-server.jar",
                        New FileChecker With {.Hash = If(Server("sha1")?.ToString, ""), .MinSize = 1024 * 512}))
            End Select
            Task.Output = DownloadFiles
        End Sub) With {.ProgressWeight = 6}

        Dim LoaderDownload As New LoaderDownload("下载服务端", New List(Of NetFile)) With {.ProgressWeight = 55}

        Dim LoaderInstaller As New LoaderTask(Of Integer, Integer)("安装加载器服务端",
        Sub(Task As LoaderTask(Of Integer, Integer))
            For Each Url In Installers
                If Task.IsCanceled Then Throw New OperationCanceledException
                RunLoaderInstaller(Url, ServerFolder(Request.Instance), Request.Instance, Task)
            Next
            Task.Output = 1
        End Sub) With {.ProgressWeight = 30}

        Dim LoaderInit As New LoaderTask(Of Integer, Integer)("初始化服务器",
        Sub(Task As LoaderTask(Of Integer, Integer))
            Dim Folder = ServerFolder(Request.Instance)
            If Not Request.AcceptEula Then
                Dim Agree = MyMsgBox($"服务器需要同意 Minecraft 最终用户协议才能启动。{vbCrLf}{vbCrLf}协议地址：{EulaUrl}{vbCrLf}{vbCrLf}是否确认已阅读并同意该协议？", "服务器最终用户协议", "同意并继续", "不同意")
                If Agree <> 1 Then Throw New OperationCanceledException
            End If
            WriteIfMissing(Folder & "eula.txt", "eula=true" & vbCrLf)
            WriteIfMissing(Folder & "server.properties", DefaultServerProperties())
            '生成便捷脚本
            Dim Jar = FindServerJar(Folder)
            If Jar Is Nothing AndAlso Not FileUtils.Exists(Folder & "run.bat") Then
                Throw New Exception($"服务端安装完成，但没有找到可运行的服务端文件或 run.bat。{vbCrLf}请检查上方「安装加载器服务端」步骤是否真的成功。")
            End If
            If Jar IsNot Nothing Then
                WriteIfMissing(Folder & "start.bat",
                    $"@echo off{vbCrLf}java {Settings.Get(Of String)("ServerJavaArg")} -jar ""{Path.GetFileName(Jar)}"" nogui{vbCrLf}pause{vbCrLf}")
            End If
            WriteMeta(Folder, ResolvedVersion, ResolvedLoader, ResolveJavaMajor(Request.VanillaVersion))
            Task.Output = 1
        End Sub) With {.ProgressWeight = 8}

        Return New List(Of LoaderBase) From {LoaderPrepare, LoaderGetVersion, LoaderDownload, LoaderInstaller, LoaderInit}
    End Function

    ''' <summary>
    ''' 运行 Forge / NeoForge 安装器，让它把服务端文件写入目标目录。
    ''' </summary>
    Private Sub RunLoaderInstaller(Url As String, Folder As String, Instance As McInstance, Task As LoaderTask(Of Integer, Integer))
        Dim InstallerPath = Folder & Path.GetFileName(New Uri(Url).LocalPath)
        If Not FileUtils.Exists(InstallerPath) Then
            DirectoryUtils.Create(Folder)
            NetDownloadByClient(Url, InstallerPath)
        End If
        Task.Progress = 0.6
        Dim J = SelectOrDownloadJava(Instance, True)
        If J Is Nothing Then Throw New Exception("没有找到可用的 Java，无法安装服务端加载器。")
        Logger.Info($"运行服务端安装器：{InstallerPath}")
        Dim Info As New ProcessStartInfo With {
            .FileName = J.JavaExePath,
            .Arguments = $"-jar ""{Path.GetFileName(InstallerPath)}"" --installServer",
            .WorkingDirectory = Folder,
            .UseShellExecute = False,
            .CreateNoWindow = True,
            .RedirectStandardOutput = True,
            .RedirectStandardError = True,
            .StandardOutputEncoding = Encoding.UTF8,
            .StandardErrorEncoding = Encoding.UTF8
        }
        Dim P = StartProcess(Info)
        AddHandler P.OutputDataReceived, Sub(s, e) If e.Data IsNot Nothing Then Logger.Info(e.Data)
        AddHandler P.ErrorDataReceived, Sub(s, e) If e.Data IsNot Nothing Then Logger.Warn(e.Data)
        P.BeginOutputReadLine()
        P.BeginErrorReadLine()
        Dim Wait As Integer = 0
        Do While Not P.WaitForExit(500)
            Wait += 1
            If Wait > 240 Then Throw New Exception("服务端加载器安装超时。")
            If Task.IsCanceled Then
                Try
                    P.Kill()
                Catch
                End Try
                Throw New OperationCanceledException
            End If
        Loop
        If Not HasServer(Folder) Then Throw New Exception($"加载器安装器未生成可运行的服务端（返回码 {P.ExitCode}）。{vbCrLf}可以改用「原版」服务端，或稍后手动安装该加载器。")
        FileUtils.Delete(InstallerPath, False)
    End Sub

    Private Function FabricServerJarUrl(MinecraftVersion As String, LoaderVersion As String) As String
        Dim Installer = "1.0.1"
        Try
            Dim Json = NetRequestByClientRetry("https://meta.fabricmc.net/v2/versions/installer", Encoding:=Encoding.UTF8, RequireJson:=True).DeserializeJson()
            If Json IsNot Nothing AndAlso Json.Count > 0 AndAlso Json(0)("stable").ToObject(Of Boolean) Then Installer = Json(0)("version").ToString
        Catch ex As Exception
            Logger.Warn(ex, "获取 Fabric 安装器版本失败，使用内置版本")
        End Try
        Return $"https://meta.fabricmc.net/v2/versions/loader/{MinecraftVersion}/{LoaderVersion}/{Installer}/server/jar"
    End Function

    Private Function ResolveFabricServerLoader(MinecraftVersion As String) As String
        Dim Result = NetRequestByClientRetry($"https://meta.fabricmc.net/v2/versions/loader/{MinecraftVersion}", Encoding:=Encoding.UTF8, RequireJson:=True).DeserializeJson()
        If Result Is Nothing OrElse Not Result.Any Then Throw New Exception($"没有找到适用于 {MinecraftVersion} 的 Fabric 服务端。")
        Return Result.First("loader")("version").ToString
    End Function

    Public Function ResolveLatestForge(MinecraftVersion As String) As String
        Dim Result = DlModRequest("https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json")
        Dim Promos = Result("promos")
        If Promos Is Nothing Then Throw New Exception("无法获取 Forge 版本列表。")
        Dim Version As String = Nothing
        If Promos($"{MinecraftVersion}-recommended") IsNot Nothing Then Version = Promos($"{MinecraftVersion}-recommended").ToString
        If Version Is Nothing AndAlso Promos($"{MinecraftVersion}-latest") IsNot Nothing Then Version = Promos($"{MinecraftVersion}-latest").ToString
        If Version Is Nothing Then Throw New Exception($"没有找到适用于 {MinecraftVersion} 的 Forge 版本。")
        Return Version
    End Function

    Public Function ResolveLatestNeoForge(MinecraftVersion As String) As String
        Dim Result = DlModRequest("https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge")
        Dim AllVersions = Result("versions")
        If AllVersions Is Nothing Then Throw New Exception("无法获取 NeoForge 版本列表。")
        Dim Prefix As String
        Dim Segments = MinecraftVersion.Split("."c)
        If MinecraftVersion = "1.20.1" Then
            Prefix = "47."
        ElseIf Segments.Length = 3 Then
            Prefix = Segments(1) & "." & Segments(2) & "."
        ElseIf Segments.Length = 2 Then
            Prefix = Segments(1) & ".0."
        Else
            Throw New Exception($"无法确定 NeoForge 的版本编号规则：{MinecraftVersion}")
        End If
        Dim Matching = AllVersions.Select(Function(v) v.ToString).Where(Function(v) v.StartsWithF(Prefix) AndAlso v.Count(Function(c) c = "."c) = 2).ToList()
        If Not Matching.Any Then Throw New Exception($"没有找到适用于 {MinecraftVersion} 的 NeoForge 版本。")
        Return Matching.Last
    End Function

    Private Sub WriteIfMissing(Path As String, Content As String)
        If FileUtils.Exists(Path) Then Return
        System.IO.File.WriteAllText(Path, Content, New UTF8Encoding(False))
    End Sub

    Private Function DefaultServerProperties() As String
        Return String.Join(vbCrLf, {
            "motd=PCL-QW 服务器",
            "server-port=25565",
            "online-mode=true",
            "gamemode=survival",
            "difficulty=easy",
            "max-players=20",
            "view-distance=10",
            "simulation-distance=10",
            "pvp=true",
            "level-name=world",
            "allow-nether=true",
            "enable-command-block=false",
            ""})
    End Function

    ''' <summary>
    ''' 读取 server.properties（按 key=value 解析，忽略注释）。
    ''' </summary>
    Public Function ReadProperties(Path As String) As Dictionary(Of String, String)
        Dim Result As New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)
        Try
            If Not FileUtils.Exists(Path) Then Return Result
            For Each Line In FileUtils.ReadAsString(Path).Split({vbCr, vbLf}, StringSplitOptions.RemoveEmptyEntries)
                Dim Text = Line.Trim
                If Text = "" OrElse Text.StartsWith("#"c) Then Continue For
                Dim Pos = Text.IndexOf("="c)
                If Pos <= 0 Then Continue For
                Result(Text.Substring(0, Pos).Trim) = Text.Substring(Pos + 1).Trim
            Next
        Catch ex As Exception
            Logger.Warn(ex, "读取 server.properties 失败")
        End Try
        Return Result
    End Function

    ''' <summary>
    ''' 修改 server.properties 中的若干项，其余内容原样保留。
    ''' </summary>
    Public Sub WriteProperties(Path As String, Values As Dictionary(Of String, String))
        Try
            Dim Lines = New List(Of String)
            If FileUtils.Exists(Path) Then Lines.AddRange(FileUtils.ReadAsString(Path).Split({vbLf}, StringSplitOptions.None))
            Dim Remaining = New Dictionary(Of String, String)(Values, StringComparer.OrdinalIgnoreCase)
            For i = 0 To Lines.Count - 1
                Dim Text = Lines(i).Trim
                If Text = "" OrElse Text.StartsWith("#"c) Then Continue For
                Dim Pos = Text.IndexOf("="c)
                If Pos <= 0 Then Continue For
                Dim Key = Text.Substring(0, Pos).Trim
                If Remaining.ContainsKey(Key) Then
                    Lines(i) = $"{Key}={Remaining(Key)}"
                    Remaining.Remove(Key)
                End If
            Next
            For Each Item In Remaining
                Lines.Add($"{Item.Key}={Item.Value}")
            Next
            System.IO.File.WriteAllText(Path, String.Join(vbCrLf, Lines), New UTF8Encoding(False))
        Catch ex As Exception
            Logger.Error(ex, "写入 server.properties 失败", LogBehavior.Alert)
        End Try
    End Sub

    ''' <summary>
    ''' 取得 server.properties 中某一项的值。
    ''' </summary>
    Private Function PropValue(Properties As Dictionary(Of String, String), Key As String, Fallback As String) As String
        Dim Value As String = Nothing
        If Properties.TryGetValue(Key, Value) AndAlso Not String.IsNullOrWhiteSpace(Value) Then Return Value
        Return Fallback
    End Function

    ''' <summary>
    ''' 取得服务器配置的端口号。
    ''' </summary>
    Public Function GetServerPort(Folder As String) As Integer
        Dim Value = PropValue(ReadProperties(Folder & "server.properties"), "server-port", "25565")
        Dim Port As Integer
        If Not Integer.TryParse(Value, Port) OrElse Port < 1 OrElse Port > 65535 Then Return 25565
        Return Port
    End Function

#End Region

#Region "运行"

    Public Class RunningServer
        Public Folder As String
        Public JarPath As String
        Public Process As Process
        Public Stdin As StreamWriter
        Public Lines As New List(Of String)
        Public StartedAt As Date
        ''' <summary>
        ''' 收到新的一行输出。可能在后台线程触发。
        ''' </summary>
        Public Event OutputLine(Line As String)
        Public Event Exited()

        Public Sub Append(Line As String)
            SyncLock Lines
                Lines.Add(Line)
                If Lines.Count > 2000 Then Lines.RemoveRange(0, Lines.Count - 2000)
            End SyncLock
            '同时写入启动器日志，否则服务器一闪而过的报错无法排查
            Logger.Info($"[Server] {Line}")
            RaiseEvent OutputLine(Line)
        End Sub
        ''' <summary>
        ''' 由外部通知进程已退出。
        ''' </summary>
        Public Sub NotifyExited()
            RaiseEvent Exited()
        End Sub
    End Class

    Private ReadOnly RunningList As New List(Of RunningServer)
    Private ReadOnly RunningLock As New Object

    Public Function GetRunning(Folder As String) As RunningServer
        SyncLock RunningLock
            Return RunningList.FirstOrDefault(Function(s) s.Folder.TrimEnd("\"c) = Folder.TrimEnd("\"c) AndAlso s.Process IsNot Nothing AndAlso Not s.Process.HasExited)
        End SyncLock
    End Function

    Public Function RunningServers() As List(Of RunningServer)
        SyncLock RunningLock
            Return RunningList.ToList()
        End SyncLock
    End Function

    ''' <summary>
    ''' 启动服务器。返回运行中的服务器对象。
    ''' </summary>
    Public Function StartServer(Folder As String, Optional Instance As McInstance = Nothing) As RunningServer
        Dim Existing = GetRunning(Folder)
        If Existing IsNot Nothing Then Return Existing
        Dim Jar = FindServerJar(Folder)
        Dim UseRunBat = Jar Is Nothing AndAlso FileUtils.Exists(Folder & "run.bat")
        If Jar Is Nothing AndAlso Not UseRunBat Then Throw New Exception($"该文件夹内没有找到可运行的服务端：{Folder}")
        If Not FileUtils.Exists(Folder & "eula.txt") Then
            If MyMsgBox($"该服务器还没有同意 Minecraft 最终用户协议。{vbCrLf}{vbCrLf}协议地址：{EulaUrl}{vbCrLf}{vbCrLf}是否同意并继续启动？", "服务器最终用户协议", "同意并启动", "取消") <> 1 Then Return Nothing
            System.IO.File.WriteAllText(Folder & "eula.txt", "eula=true" & vbCrLf, New UTF8Encoding(False))
        ElseIf Not PropValue(ReadProperties(Folder & "eula.txt"), "eula", "").Equals("true", StringComparison.OrdinalIgnoreCase) Then
            If MyMsgBox($"eula.txt 中 eula 不为 true，服务器会直接退出。{vbCrLf}{vbCrLf}协议地址：{EulaUrl}{vbCrLf}{vbCrLf}是否同意并继续启动？", "服务器最终用户协议", "同意并启动", "取消") <> 1 Then Return Nothing
            System.IO.File.WriteAllText(Folder & "eula.txt", "eula=true" & vbCrLf, New UTF8Encoding(False))
        End If
        'Java 需求要按服务端自身的版本判断：实例可能是 1.21（Java 21），而服务端选了 26.x（Java 25）
        Dim Meta = ReadMeta(Folder)
        Dim Major = Meta.JavaMajor
        If Major <= 0 AndAlso Meta.Version IsNot Nothing Then Major = ResolveJavaMajor(Meta.Version.Split({" "c}, StringSplitOptions.RemoveEmptyEntries).First)
        Dim J As Java = Nothing
        If Major >= 8 Then J = SelectOrDownloadJava(ValueRange(Of Version).AtLeast(New Version(Major, 0)), True)
        If J Is Nothing AndAlso Instance IsNot Nothing Then J = SelectOrDownloadJava(Instance, True)
        If J Is Nothing Then
            Throw New Exception(If(Major >= 8,
                $"没有找到 Java {Major} 或更高版本的 Java，无法启动该服务端。{vbCrLf}请在「设置 → 启动 → Java」中安装或导入对应版本。",
                "没有找到可用的 Java，无法启动服务器。"))
        End If
        'run.bat 由安装器生成，内部自己调 java，因此把 Java 目录加进 PATH 让它找得到
        Dim Info As New ProcessStartInfo With {
            .WorkingDirectory = Folder,
            .UseShellExecute = False,
            .CreateNoWindow = True,
            .RedirectStandardInput = True,
            .RedirectStandardOutput = True,
            .RedirectStandardError = True,
            .StandardOutputEncoding = If(String.IsNullOrEmpty(J.FileEncodingName), Encoding.UTF8, Encoding.GetEncoding(J.FileEncodingName)),
            .StandardErrorEncoding = If(String.IsNullOrEmpty(J.NativeEncodingName), Encoding.UTF8, Encoding.GetEncoding(J.NativeEncodingName))
        }
        If UseRunBat Then
            Info.FileName = "cmd.exe"
            Info.Arguments = "/d /c run.bat"
            Info.EnvironmentVariables("PATH") = J.Folder & ";" & Environment.GetEnvironmentVariable("PATH")
            Info.EnvironmentVariables("JAVA_HOME") = Directory.GetParent(J.Folder).FullName
            Logger.Info($"以 run.bat 启动服务器：{Folder}")
        Else
            Info.FileName = J.JavaExePath
            Info.Arguments = $"{Settings.Get(Of String)("ServerJavaArg")} -jar ""{Path.GetFileName(Jar)}"" nogui"
        End If
        Dim Server As New RunningServer With {.Folder = Folder, .JarPath = If(Jar, Folder & "run.bat"), .StartedAt = Date.Now}
        Server.Process = StartProcess(Info)
        AddHandler Server.Process.OutputDataReceived, Sub(s, e) If e.Data IsNot Nothing Then Server.Append(e.Data)
        AddHandler Server.Process.ErrorDataReceived, Sub(s, e) If e.Data IsNot Nothing Then Server.Append(e.Data)
        Server.Stdin = Server.Process.StandardInput
        Server.Process.BeginOutputReadLine()
        Server.Process.BeginErrorReadLine()
        Server.Process.EnableRaisingEvents = True
        AddHandler Server.Process.Exited,
        Sub()
            Logger.Info($"服务器已退出：{Folder}")
            SyncLock RunningLock
                RunningList.Remove(Server)
            End SyncLock
            Server.NotifyExited()
        End Sub
        SyncLock RunningLock
            RunningList.Add(Server)
        End SyncLock
        Logger.Info($"启动服务器：{Info.FileName} {Info.Arguments}（{Folder}）")
        Return Server
    End Function

    ''' <summary>
    ''' 向服务器发送一条控制台指令。
    ''' </summary>
    Public Sub SendCommand(Server As RunningServer, Command As String)
        Try
            If Server Is Nothing OrElse Server.Stdin Is Nothing Then Throw New Exception("服务器未在运行。")
            Server.Stdin.WriteLine(Command)
            Server.Stdin.Flush()
            Server.Append($"> {Command}")
        Catch ex As Exception
            Logger.Error(ex, "向服务器发送指令失败", LogBehavior.Alert)
        End Try
    End Sub

    ''' <summary>
    ''' 停止服务器。优先使用 stop 指令，超时后强制结束。
    ''' </summary>
    Public Sub StopServer(Server As RunningServer, Optional Force As Boolean = False)
        Try
            If Server Is Nothing OrElse Server.Process Is Nothing OrElse Server.Process.HasExited Then Return
            If Not Force Then
                Try
                    Server.Stdin.WriteLine("stop")
                    Server.Stdin.Flush()
                Catch ex As Exception
                    Logger.Warn(ex, "向服务器发送 stop 指令失败")
                End Try
                If Not Server.Process.WaitForExit(15000) Then
                    If MyMsgBox("服务器没有在 15 秒内退出，是否强制结束？", "停止服务器", "强制结束", "继续等待", IsWarn:=True) = 2 Then Return
                End If
            End If
            If Not Server.Process.HasExited Then Server.Process.Kill()
        Catch ex As Exception
            Logger.Error(ex, "停止服务器失败", LogBehavior.Alert)
        End Try
    End Sub

    ''' <summary>
    ''' 不再询问，直接结束所有正在运行的服务器。
    ''' </summary>
    Public Sub StopAllServers()
        For Each Server In RunningServers()
            Try
                StopServer(Server, True)
            Catch ex As Exception
                Logger.Warn(ex, "结束服务器失败")
            End Try
        Next
    End Sub

    ''' <summary>
    ''' 程序退出前调用。返回 True 表示仍有服务器在运行且用户选择了取消退出。
    ''' </summary>
    Public Function ConfirmExit() As Boolean
        Dim List = RunningServers().Where(Function(s) s.Process IsNot Nothing AndAlso Not s.Process.HasExited).ToList()
        If Not List.Any Then Return False
        If MyMsgBox($"仍有 {List.Count} 个服务器正在运行，关闭启动器会一并停止它们。", "退出启动器", "仍然退出", "取消", IsWarn:=True) = 2 Then Return True
        For Each Server In List
            StopServer(Server, True)
        Next
        Return False
    End Function

#End Region

End Module
