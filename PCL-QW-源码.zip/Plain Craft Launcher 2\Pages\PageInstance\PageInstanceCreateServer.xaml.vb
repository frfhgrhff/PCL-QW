Public Class PageInstanceCreateServer

    'PCL-QW新增：在当前实例内创建并运行本地服务器

    Private Sub PageInstanceCreateServer_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        RefreshContent()
    End Sub

    Private Sub RefreshContent()
        Try
            PanContent.Children.Clear()
            Dim Instance = PageInstanceLeft.Instance
            If Instance Is Nothing Then
                LabPath.Text = "尚未选择实例。"
                Return
            End If
            Dim Folder = ModServer.ServerFolder(Instance)
            LabPath.Text = "服务器文件夹：" & Folder
            If HasServer(Folder) Then
                Dim Console As New ServerConsoleUI(Folder, Instance)
                AddHandler Console.StatusChanged,
                Sub()
                    '服务器被外部停止后，若已不存在服务端文件则回到创建界面
                    If Not HasServer(Folder) Then RefreshContent()
                End Sub
                PanContent.Children.Add(Console)
            Else
                Dim Create As New ServerCreateUI(Instance)
                AddHandler Create.Installed, AddressOf RefreshContent
                PanContent.Children.Add(Create)
            End If
        Catch ex As Exception
            Logger.Error(ex, "加载服务器页面失败", LogBehavior.Alert)
        End Try
    End Sub

End Class
