Imports Newtonsoft.Json.Linq

Public Class PageInstanceUpgrade

    'PCL-QW新增：全自动版本升级。
    '流程：选择目标版本 → 解析加载器 → 安装新版本 → 迁移游戏数据 → 模组按目标版本重下 → 生成报告。

#Region "页面初始化"

    Private IsInited As Boolean = False
    Private TargetVersions As New List(Of String)

    Private Sub PageInstanceUpgrade_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        Dim Instance = PageInstanceLeft.Instance
        If Instance Is Nothing Then
            LabSource.Text = "未选择实例"
            BtnStart.IsEnabled = False
            Return
        End If
        LabSource.Text = $"{Instance.Name}（{Instance.Version.VanillaName}）"
        If IsInited Then Return
        IsInited = True
        CheckWorlds.Checked = True
        CheckResourcePacks.Checked = True
        CheckShaders.Checked = True
        CheckOtherData.Checked = True
        CheckMods.Checked = True
        LoadVersions()
    End Sub

    '获取可选的正式版列表
    Private Sub LoadVersions()
        RunInThread(
        Sub()
            Try
                RunInUi(Sub() LabLoaderInfo.Text = "正在获取版本列表……")
                If DlClientListMojangLoader.State <> LoadState.Finished Then
                    DlClientListMojangLoader.Start(1)
                    Dim Timeout As Integer = 0
                    Do Until DlClientListMojangLoader.State <> LoadState.Loading
                        Thread.Sleep(100)
                        Timeout += 100
                        If Timeout > 30000 Then Throw New Exception("获取版本列表超时，请检查网络后重试。")
                    Loop
                End If
                If DlClientListMojangLoader.State <> LoadState.Finished Then Throw New Exception("无法获取版本列表，请检查网络后重试。")
                Dim VersionsJson = DlClientListMojangLoader.Output.Value("versions")
                If VersionsJson Is Nothing Then Throw New Exception("版本列表数据异常。")
                Dim Releases As New List(Of String)
                For Each VersionJson In VersionsJson
                    If VersionJson("type") IsNot Nothing AndAlso VersionJson("type").ToString = "release" Then Releases.Add(VersionJson("id").ToString)
                Next
                If Not Releases.Any Then Throw New Exception("没有找到可用的正式版。")
                TargetVersions = Releases
                RunInUi(
                Sub()
                    ComboTarget.Items.Clear()
                    For Each Ver In TargetVersions
                        ComboTarget.Items.Add(New MyComboBoxItem With {.Content = Ver})
                    Next
                    ComboTarget.SelectedIndex = 0
                    LabLoaderInfo.Text = $"已获取 {TargetVersions.Count} 个正式版（最新：{TargetVersions.First}），可直接选择或下拉查看更多。"
                    UpdateDefaultName()
                End Sub)
            Catch ex As Exception
                Logger.Warn(ex, "获取版本列表失败")
                RunInUi(Sub() LabLoaderInfo.Text = ex.Message)
            End Try
        End Sub)
    End Sub

    Private Sub ComboTarget_SelectionChanged(sender As Object, e As SelectionChangedEventArgs) Handles ComboTarget.SelectionChanged
        UpdateDefaultName()
    End Sub
    Private Sub ComboLoader_SelectionChanged(sender As Object, e As SelectionChangedEventArgs) Handles ComboLoader.SelectionChanged
        UpdateDefaultName()
    End Sub
    Private Sub UpdateDefaultName()
        Try
            Dim Instance = PageInstanceLeft.Instance
            If Instance Is Nothing OrElse ComboTarget.SelectedItem Is Nothing Then Return
            Dim Target = CType(ComboTarget.SelectedItem, MyComboBoxItem).Content.ToString
            TextName.Text = $"{Instance.Name}-{Target}"
        Catch ex As Exception
            Logger.Warn(ex, "更新新实例名失败")
        End Try
    End Sub

#End Region

#Region "升级流程"

    '升级上下文
    Private Shared UpgradeSource As McInstance = Nothing
    Private Shared UpgradeTargetName As String = Nothing
    Private Shared UpgradeTargetVanilla As String = Nothing
    Private Shared UpgradeLoaderDesc As String = "原版"
    Private Shared UpgradeSkippedMods As New List(Of String)
    Private Shared UpgradeDownloadedMods As Integer = 0
    Private Shared UpgradeIsSharedFolder As Boolean = False
    '迁移选项必须在 UI 线程读取后传给后台线程（WPF 控件不可跨线程访问）
    Private Shared UpgradeWorlds As Boolean = True
    Private Shared UpgradeResourcePacks As Boolean = True
    Private Shared UpgradeShaders As Boolean = True
    Private Shared UpgradeOtherData As Boolean = True
    Private Shared UpgradeMods As Boolean = True

    Private Sub BtnStart_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnStart.Click
        Try
            Dim Instance = PageInstanceLeft.Instance
            If Instance Is Nothing Then Return
            If ComboTarget.SelectedItem Is Nothing Then
                Hint("请先等待版本列表加载完成！", HintType.Red)
                Return
            End If
            If McLaunchLoader.State = LoadState.Loading Then
                Hint("已有游戏正在启动中，请等待结束后再试！", HintType.Red)
                Return
            End If
            Dim TargetVanilla As String = CType(ComboTarget.SelectedItem, MyComboBoxItem).Content.ToString
            Dim NewName As String = TextName.Text.Trim
            If String.IsNullOrEmpty(NewName) Then
                Hint("请填写新实例名！", HintType.Red)
                Return
            End If
            If DirectoryUtils.Exists(McFolderSelected & "versions\" & NewName & "\") Then
                Hint($"已存在名为 {NewName} 的版本，请换一个名字！", HintType.Red)
                Return
            End If
            '解析加载器
            Dim LoaderText As String
            Try
                LoaderText = ResolveLoaderVersion(Instance, TargetVanilla, ComboLoader.SelectedIndex = 0)
            Catch ex As Exception
                MyMsgBox(ex.Message, "无法自动选择加载器", IsWarn:=True)
                Return
            End Try
            '确认
            Dim ModCountText As String = If(CheckMods.Checked, "模组会尝试按目标版本自动重新下载；", "")
            Dim LoaderWarnText As String = If(LoaderText = "原版" AndAlso ComboLoader.SelectedIndex = 0,
                $"{vbCrLf}{vbCrLf}注意：未能识别源实例的 Mod 加载器，将只安装原版。", "")
            If MyMsgBox($"即将开始版本升级：{vbCrLf}源实例：{Instance.Name}{vbCrLf}目标版本：{TargetVanilla}（{LoaderText}）{vbCrLf}新实例名：{NewName}{vbCrLf}{vbCrLf}这会安装一个新的游戏版本，并在安装完成后迁移所选数据；{ModCountText}过程可能需要较长时间，且不会修改源实例。{LoaderWarnText}{vbCrLf}是否继续？", "版本升级确认", "开始升级", "取消") <> 1 Then Return
            RunUpgrade(Instance, TargetVanilla, NewName, LoaderText)
        Catch ex As Exception
            Logger.Error(ex, "开始版本升级失败", LogBehavior.Alert)
        End Try
    End Sub

    '解析与原实例一致的加载器版本
    Private Function ResolveLoaderVersion(Instance As McInstance, TargetVanilla As String, UseLoader As Boolean) As String
        If Not UseLoader Then Return "原版"
        Dim Kind As String = DetectLoaderKind(Instance)
        Select Case Kind
            Case "Fabric"
                Dim Result = DlModRequest($"https://meta.fabricmc.net/v2/versions/loader/{TargetVanilla}")
                If Result IsNot Nothing AndAlso Result.Count > 0 Then
                    Return "Fabric " & Result.First("loader")("version").ToString
                End If
                Throw New Exception($"没有找到适用于 {TargetVanilla} 的 Fabric 加载器版本。")
            Case "NeoForge"
                Dim Result = DlModRequest("https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge")
                Dim AllVersions = Result("versions")
                If AllVersions Is Nothing Then Throw New Exception("无法获取 NeoForge 版本列表。")
                Dim Prefix As String
                Dim Segments = TargetVanilla.Split("."c)
                If TargetVanilla = "1.20.1" Then
                    Prefix = "47." '1.20.1 使用旧版编号方案
                ElseIf Segments.Length = 3 Then
                    Prefix = Segments(1) & "." & Segments(2) & "."
                ElseIf Segments.Length = 2 Then
                    Prefix = Segments(1) & ".0."
                Else
                    Throw New Exception($"无法确定 NeoForge 的版本编号规则：{TargetVanilla}")
                End If
                Dim Matching = AllVersions.Select(Function(v) v.ToString).Where(Function(v) v.StartsWithF(Prefix) AndAlso v.Count(Function(c) c = "."c) = 2).ToList()
                If Not Matching.Any Then Throw New Exception($"没有找到适用于 {TargetVanilla} 的 NeoForge 版本。")
                Return "NeoForge " & Matching.Last
            Case "Forge"
                Dim Result = DlModRequest("https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json")
                Dim Promos = Result("promos")
                Dim Version As String = Nothing
                If Promos IsNot Nothing Then
                    If Promos($"{TargetVanilla}-recommended") IsNot Nothing Then Version = Promos($"{TargetVanilla}-recommended").ToString
                    If Version Is Nothing AndAlso Promos($"{TargetVanilla}-latest") IsNot Nothing Then Version = Promos($"{TargetVanilla}-latest").ToString
                End If
                If Version Is Nothing Then Throw New Exception($"没有找到适用于 {TargetVanilla} 的 Forge 版本。")
                Return "Forge " & Version
            Case "LiteLoader", "OptiFine"
                Throw New Exception($"暂不支持自动解析 {Kind} 加载器。" & vbCrLf & "请在上方「加载器」中选择「原版」，或稍后在下载页手动安装相应加载器。")
            Case Else
                Return "原版"
        End Select
    End Function

    '识别源实例使用的 Mod 加载器：先看已解析的版本信息，再回退到版本 JSON（含 inheritsFrom 链）特征
    Private Shared Function DetectLoaderKind(Instance As McInstance) As String
        If Instance.Version.HasFabric Then Return "Fabric"
        If Instance.Version.HasNeoForge Then Return "NeoForge"
        If Instance.Version.HasForge Then Return "Forge"
        If Instance.Version.HasLiteLoader Then Return "LiteLoader"
        If Instance.Version.HasOptiFine Then Return "OptiFine"
        '回退：逐级读取版本 JSON
        Try
            Dim JsonText As String = ""
            Dim Name As String = Instance.Name
            For Depth As Integer = 1 To 5
                Dim Path As String = McFolderSelected & "versions\" & Name & "\" & Name & ".json"
                If Not FileUtils.Exists(Path) Then Exit For
                JsonText &= FileUtils.ReadAsString(Path)
                Dim InheritName As String = Nothing
                Try
                    Dim InheritToken = Newtonsoft.Json.Linq.JObject.Parse(FileUtils.ReadAsString(Path))("inheritsFrom")
                    If InheritToken IsNot Nothing Then InheritName = InheritToken.ToString
                Catch ex As Exception
                    Logger.Warn(ex, "解析 inheritsFrom 失败")
                End Try
                If InheritName Is Nothing OrElse InheritName = Name Then Exit For
                Name = InheritName
            Next
            If JsonText.ContainsIgnoreCase("net.fabricmc:fabric-loader") OrElse JsonText.ContainsIgnoreCase("org.quiltmc:quilt-loader") Then Return "Fabric"
            If JsonText.ContainsIgnoreCase("net.neoforged") Then Return "NeoForge"
            If JsonText.ContainsIgnoreCase("minecraftforge") OrElse JsonText.ContainsIgnoreCase("net.minecraftforge") Then Return "Forge"
        Catch ex As Exception
            Logger.Warn(ex, "识别 Mod 加载器失败")
        End Try
        Return ""
    End Function

    '执行升级
    Private Sub RunUpgrade(Instance As McInstance, TargetVanilla As String, NewName As String, LoaderText As String)
        '构建安装请求
        Dim Request As New McInstallRequest With {
            .NewInstanceName = NewName,
            .VersionFolder = McFolderSelected & "versions\" & NewName & "\",
            .MinecraftName = TargetVanilla
        }
        If LoaderText.StartsWithF("Fabric ") Then Request.FabricVersion = LoaderText.AfterFirst(" ")
        If LoaderText.StartsWithF("Forge ") Then Request.ForgeVersion = TargetVanilla & "-" & LoaderText.AfterFirst(" ")
        If LoaderText.StartsWithF("NeoForge ") Then Request.NeoForgeVersion = LoaderText.AfterFirst(" ")
        '安装加载器列表（含 Java 检查等）
        Dim InstallLoaders = McInstallLoader(Request)
        If InstallLoaders Is Nothing Then Return '失败原因已由安装引擎提示
        '记录上下文
        UpgradeSource = Instance
        UpgradeTargetName = NewName
        UpgradeTargetVanilla = TargetVanilla
        UpgradeLoaderDesc = LoaderText
        UpgradeSkippedMods = New List(Of String)
        UpgradeDownloadedMods = 0
        UpgradeIsSharedFolder = False
        'UI 复选框状态必须在 UI 线程读取，再交给后台线程使用
        UpgradeWorlds = CheckWorlds.Checked
        UpgradeResourcePacks = CheckResourcePacks.Checked
        UpgradeShaders = CheckShaders.Checked
        UpgradeOtherData = CheckOtherData.Checked
        UpgradeMods = CheckMods.Checked
        '组合：安装 + 数据迁移 + 模组重下
        Dim AllLoaders As New List(Of LoaderBase)(InstallLoaders)
        AllLoaders.Add(New LoaderTask(Of Integer, Integer)("迁移游戏数据", AddressOf MigrateDataRun) With {.ProgressWeight = 10})
        If UpgradeMods Then
            AllLoaders.Add(New LoaderTask(Of Integer, Integer)("重新下载模组", AddressOf MigrateModsRun) With {.ProgressWeight = 40})
        End If
        Dim Loader As New LoaderCombo(Of String)(NewName & " 版本升级", AllLoaders)
        Loader.OnStateChanged = Sub() UpgradeStateChanged(Loader)
        Loader.Start(Request.VersionFolder)
        LoaderTaskbarAdd(Loader)
        FrmMain.BtnExtraDownload.ShowRefresh()
        FrmMain.BtnExtraDownload.Ribble()
        Hint("已开始版本升级，可在任务栏中查看进度。")
    End Sub

    '数据迁移
    Private Sub MigrateDataRun(Loader As LoaderTask(Of Integer, Integer))
        Try
            Dim Src = UpgradeSource
            Dim NewInst As New McInstance(McFolderSelected & "versions\" & UpgradeTargetName & "\")
            Dim SrcPath As String = Src.PathIndie
            Dim DstPath As String = NewInst.PathIndie
            If SrcPath = DstPath Then
                UpgradeIsSharedFolder = True
                Logger.Info("源实例与新实例共用游戏文件夹，跳过数据复制")
                Return
            End If
            Dim Folders As New List(Of String)
            If UpgradeWorlds Then Folders.Add("saves")
            If UpgradeResourcePacks Then Folders.Add("resourcepacks")
            If UpgradeShaders Then Folders.Add("shaderpacks")
            Dim Total As Integer = Folders.Count + If(UpgradeOtherData, 1, 0)
            Dim Done As Integer = 0
            For Each FolderName In Folders
                If Loader.IsCanceled Then Return
                Loader.Progress = Done / Math.Max(Total, 1)
                CopyFolderWithMerge(SrcPath & FolderName & "\", DstPath & FolderName & "\")
                Done += 1
            Next
            If UpgradeOtherData Then
                If Loader.IsCanceled Then Return
                Loader.Progress = Done / Math.Max(Total, 1)
                'options.txt / servers.dat（不覆盖已有文件）
                For Each FileName In {"options.txt", "servers.dat"}
                    Try
                        Dim SrcFile As String = SrcPath & FileName
                        Dim DstFile As String = DstPath & FileName
                        If FileUtils.Exists(SrcFile) AndAlso Not FileUtils.Exists(DstFile) Then FileUtils.Copy(SrcFile, DstFile)
                    Catch ex As Exception
                        Logger.Warn(ex, $"迁移文件失败：{FileName}")
                    End Try
                Next
                '版本独立设置（使用设置系统逐项迁移 Source=Instance 的设置）
                For Each Entry As Settings.Setting In Settings.Entries.Values
                    If Entry.Source <> Settings.Sources.Instance Then Continue For
                    Try
                        Dim Value = Settings.Get(Entry.Key, Instance:=Src)
                        Settings.Set(Entry.Key, Value, Instance:=NewInst)
                    Catch ex As Exception
                        Logger.Warn(ex, $"迁移版本独立设置失败：{Entry.Key}")
                    End Try
                Next
                Done += 1
            End If
            Loader.Progress = 1
        Catch ex As Exception
            Logger.Error(ex, "迁移游戏数据失败")
            Throw
        End Try
    End Sub

    '递归复制文件夹（不覆盖已存在的文件）
    Private Shared Sub CopyFolderWithMerge(Source As String, Target As String)
        Dim SrcInfo As New System.IO.DirectoryInfo(Source)
        If Not SrcInfo.Exists Then Return
        Dim DstInfo As New System.IO.DirectoryInfo(Target)
        If Not DstInfo.Exists Then DstInfo.Create()
        For Each FileItem As System.IO.FileInfo In SrcInfo.EnumerateFiles()
            Dim TargetFile As String = Target & FileItem.Name
            If FileUtils.Exists(TargetFile) Then Continue For
            FileUtils.Copy(FileItem.FullName, TargetFile)
        Next
        For Each DirItem As System.IO.DirectoryInfo In SrcInfo.EnumerateDirectories()
            CopyFolderWithMerge(DirItem.FullName & "\", Target & DirItem.Name & "\")
        Next
    End Sub

    '模组按目标版本重新下载
    Private Sub MigrateModsRun(Loader As LoaderTask(Of Integer, Integer))
        Try
            Dim Src = UpgradeSource
            Dim NewInst As New McInstance(McFolderSelected & "versions\" & UpgradeTargetName & "\")
            If Src.PathIndie = NewInst.PathIndie Then
                UpgradeSkippedMods.Add("两个实例共用游戏文件夹，模组无法并存；建议为新实例开启版本隔离后手动迁移模组")
                Return
            End If
            Dim SrcMods As String = Src.PathIndie & "mods\"
            Dim SrcModsInfo As New System.IO.DirectoryInfo(SrcMods)
            If Not SrcModsInfo.Exists Then Return
            Dim Mods As New List(Of LocalResourceFile)
            For Each FileItem As System.IO.FileInfo In SrcModsInfo.EnumerateFiles()
                Dim Ext = PathUtils.GetExtension(FileItem.Name)
                If Ext <> "jar" AndAlso Ext <> "litemod" Then Continue For
                Mods.Add(New LocalResourceFile(FileItem.FullName))
            Next
            If Not Mods.Any Then Return
            '等待可能正在进行的其他本地 Mod 加载完成
            Do While LocalResourceOnlineLoader.State = LoadState.Loading
                Thread.Sleep(100)
                If Loader.IsCanceled Then Return
            Loop
            '构造目标版本与加载器标记
            Dim TargetVersion As New McVersion With {.VanillaName = UpgradeTargetVanilla}
            If UpgradeLoaderDesc.StartsWithF("Fabric") Then TargetVersion.Fabric = UpgradeLoaderDesc.AfterFirst(" ")
            If UpgradeLoaderDesc.StartsWithF("Forge") Then TargetVersion.Forge = UpgradeLoaderDesc.AfterFirst(" ")
            If UpgradeLoaderDesc.StartsWithF("NeoForge") Then TargetVersion.NeoForge = UpgradeLoaderDesc.AfterFirst(" ")
            '联网识别每个模组，并解析目标版本下适配的文件
            Dim Cache As New JObject
            LocalResourceOnlineLoader.Start((Mods, Cache, TargetVersion), IsForceRestart:=True)
            Do Until LocalResourceOnlineLoader.State <> LoadState.Loading
                If Loader.IsCanceled Then Return
                Thread.Sleep(100)
            Loop
            '下载适配文件
            Dim DstMods As String = NewInst.PathIndie & "mods\"
            DirectoryUtils.Create(DstMods)
            Dim Total As Integer = Mods.Count, Done As Integer = 0
            For Each Entry In Mods
                If Loader.IsCanceled Then Return
                Done += 1
                Loader.Progress = Done / Total
                If Entry.UpdateFile Is Nothing OrElse Not Entry.UpdateFile.DownloadAvailable Then
                    Dim Why = If(Entry.Project Is Nothing, "未识别来源（可能是手动安装或非 Modrinth/CurseForge 资源）", "没有适配目标版本的文件")
                    UpgradeSkippedMods.Add($"{Entry.Display} —— {Why}")
                    Continue For
                End If
                Dim DstFile As String = DstMods & Entry.UpdateFile.FileName
                Try
                    DownloadModFile(Entry.UpdateFile, DstFile)
                    UpgradeDownloadedMods += 1
                Catch ex As Exception
                    Logger.Warn(ex, $"下载模组失败：{Entry.UpdateFile.FileName}")
                    UpgradeSkippedMods.Add($"{Entry.Display} —— 下载失败：{ex.Message}")
                End Try
            Next
        Catch ex As Exception
            Logger.Error(ex, "模组迁移失败")
            UpgradeSkippedMods.Add($"（模组迁移过程出错：{ex.Message}）")
        End Try
    End Sub

    '逐个下载源尝试下载模组文件
    Private Shared Sub DownloadModFile(File As ResourceVersion, DstPath As String)
        Dim Errors As New List(Of String)
        For Each Url In File.DownloadUrls
            Try
                NetDownloadByClient(Url, DstPath)
                If FileUtils.Exists(DstPath) Then Return
            Catch ex As Exception
                Errors.Add(ex.Message)
            End Try
        Next
        Throw New Exception(If(Errors.Any, Errors.Last, "没有可用的下载源"))
    End Sub

    '升级结束处理
    Private Sub UpgradeStateChanged(Loader As LoaderCombo(Of String))
        Select Case Loader.State
            Case LoadState.Finished
                RunInUi(
                Sub()
                    Try
                        '写迁移报告
                        Dim ReportPath As String = McFolderSelected & "versions\" & UpgradeTargetName & "\升级迁移报告.txt"
                        Dim Lines As New List(Of String) From {
                            "PCL-QW · 版本升级报告",
                            $"时间：{Date.Now:yyyy-MM-dd HH:mm:ss}",
                            $"源实例：{UpgradeSource?.Name}",
                            $"新实例：{UpgradeTargetName}（{UpgradeTargetVanilla}，{UpgradeLoaderDesc}）",
                            $"已重新下载模组：{UpgradeDownloadedMods} 个"
                        }
                        If UpgradeIsSharedFolder Then Lines.Add("注意：两个实例共用游戏文件夹，世界与资源等本就共用，未进行复制。")
                        If UpgradeSkippedMods.Any Then
                            Lines.Add("")
                            Lines.Add("以下内容未能自动迁移，请手动处理：")
                            Lines.AddRange(UpgradeSkippedMods.Select(Function(s) "· " & s))
                        End If
                        System.IO.File.WriteAllText(ReportPath, Lines.Join(vbCrLf), New System.Text.UTF8Encoding(False))
                        Dim Msg As String = $"版本升级完成！{vbCrLf}新实例：{UpgradeTargetName}（{UpgradeTargetVanilla}，{UpgradeLoaderDesc}）{vbCrLf}已重新下载模组：{UpgradeDownloadedMods} 个"
                        If UpgradeSkippedMods.Any Then Msg &= $"{vbCrLf}有 {UpgradeSkippedMods.Count} 项未能自动处理，详见「升级迁移报告.txt」。"
                        MyMsgBox(Msg, "版本升级完成", "打开新实例文件夹", "确定", Button1Action:=Sub() OpenExplorer(McFolderSelected & "versions\" & UpgradeTargetName & "\"))
                        '切换到新实例
                        Dim NewInst As New McInstance(McFolderSelected & "versions\" & UpgradeTargetName & "\")
                        NewInst.Load()
                        PageInstanceLeft.Instance = NewInst
                        If FrmInstanceLeft IsNot Nothing Then FrmInstanceLeft.ItemOverall.Checked = True
                        McInstanceListForceRefresh = True
                        FrmMain.BtnExtraDownload.ShowRefresh()
                    Catch ex As Exception
                        Logger.Error(ex, "版本升级完成处理失败", LogBehavior.Alert)
                    End Try
                End Sub)
            Case LoadState.Failed
                RunInUi(Sub() MyMsgBox("版本升级失败：" & If(Loader.Error Is Nothing, "未知错误", Loader.Error.GetDisplay(False)), "升级失败", IsWarn:=True))
            Case LoadState.Canceled
                RunInUi(Sub() Hint("版本升级已中止，已安装的部分内容会保留。", HintType.Blue))
        End Select
    End Sub

#End Region

End Class
