Imports Newtonsoft.Json.Linq

''' <summary>
''' PCL-QW新增：服务器创建表单控件（供顶部「服务器」页与实例页「创建服务器」共用）。
''' 创建成功后通过 Installed 事件通知宿主页面。
''' </summary>
Public Class ServerCreateUI
    Inherits StackPanel

    Private ComboVersion As MyComboBox
    Private ComboLoader As MyComboBox
    Private BtnCreate As MyButton
    Private LabInfo As TextBlock
    Private ReadOnly TargetInstance As McInstance
    Private TargetVersions As List(Of String)
    Private IsWorking As Boolean = False

    Public Event Installed()

    Public Sub New(Instance As McInstance)
        TargetInstance = Instance
        BuildUi()
        LoadVersions()
    End Sub

    Private Sub BuildUi()
        ComboVersion = New MyComboBox With {.Margin = New Thickness(0, 0, 0, 10), .IsEditable = True}
        ComboLoader = New MyComboBox With {.Margin = New Thickness(0, 0, 0, 10)}
        ComboLoader.Items.Add(New MyComboBoxItem With {.Content = "原版（Vanilla）", .Tag = ServerLoaderKind.Vanilla})
        ComboLoader.Items.Add(New MyComboBoxItem With {.Content = "Fabric", .Tag = ServerLoaderKind.Fabric})
        ComboLoader.Items.Add(New MyComboBoxItem With {.Content = "Forge", .Tag = ServerLoaderKind.Forge})
        ComboLoader.Items.Add(New MyComboBoxItem With {.Content = "NeoForge", .Tag = ServerLoaderKind.NeoForge})
        CType(ComboLoader.Items(0), MyComboBoxItem).IsSelected = True

        BtnCreate = New MyButton With {.Text = "下载并创建服务器", .MinWidth = 160, .Height = 35, .Padding = New Thickness(13, 0, 13, 0), .Margin = New Thickness(0, 4, 0, 0)}
        LabInfo = New TextBlock With {
            .TextWrapping = TextWrapping.Wrap,
            .FontSize = 12,
            .Opacity = 0.8,
            .Margin = New Thickness(0, 10, 0, 0),
            .Text = "服务端会创建在该实例的文件夹内（versions\" & TargetInstance.Name & "\server\），删除实例时会一并处理。"
        }
        AddRow("游戏版本", ComboVersion)
        AddRow("服务端类型", ComboLoader)
        Children.Add(BtnCreate)
        Children.Add(LabInfo)

        AddHandler BtnCreate.Click, AddressOf BtnCreate_Click
    End Sub

    Private Sub AddRow(Title As String, Control As FrameworkElement)
        Dim Panel As New Grid
        Panel.ColumnDefinitions.Add(New ColumnDefinition With {.Width = New GridLength(90)})
        Panel.ColumnDefinitions.Add(New ColumnDefinition With {.Width = New GridLength(1, GridUnitType.Star)})
        Dim Lab As New TextBlock With {.Text = Title, .VerticalAlignment = VerticalAlignment.Center, .Margin = New Thickness(0, 0, 10, 10)}
        CType(Control, FrameworkElement).Margin = New Thickness(0, 0, 0, 10)
        Grid.SetColumn(Lab, 0)
        Grid.SetColumn(Control, 1)
        Panel.Children.Add(Lab)
        Panel.Children.Add(Control)
        Children.Add(Panel)
    End Sub

    ''' <summary>
    ''' 后台获取可选的正式版列表。
    ''' </summary>
    Private Sub LoadVersions()
        RunInThread(
        Sub()
            Try
                If DlClientListMojangLoader.State <> LoadState.Finished Then DlClientListMojangLoader.Start(1)
                Dim Wait As Integer = 0
                Do While DlClientListMojangLoader.State = LoadState.Loading AndAlso Wait < 300
                    Thread.Sleep(100)
                    Wait += 1
                Loop
                If DlClientListMojangLoader.State <> LoadState.Finished Then Throw New Exception("无法获取游戏版本列表。")
                Dim Releases As New List(Of String)
                For Each Item In DlClientListMojangLoader.Output.Value("versions")
                    If Item("type")?.ToString = "release" Then Releases.Add(Item("id").ToString)
                Next
                If Not Releases.Any Then Throw New Exception("没有找到可用的正式版。")
                TargetVersions = Releases
                RunInUi(
                Sub()
                    ComboVersion.Items.Clear()
                    For Each Ver In Releases
                        ComboVersion.Items.Add(New MyComboBoxItem With {.Content = Ver})
                    Next
                    ComboVersion.SelectedIndex = 0
                End Sub)
            Catch ex As Exception
                Logger.Warn(ex, "获取服务器版本列表失败")
                RunInUi(Sub() LabInfo.Text = "获取游戏版本列表失败：" & ex.Message & vbCrLf & "可以直接在下拉框中手动输入版本号。")
            End Try
        End Sub)
    End Sub

    Private Sub BtnCreate_Click(sender As Object, e As RoutedEventArgs)
        Try
            If IsWorking Then Return
            Dim VersionText = ComboVersion.Text.Trim
            If VersionText = "" Then
                Hint("请填写或选择游戏版本。", HintType.Red)
                Return
            End If
            Dim LoaderKind As ServerLoaderKind = ServerLoaderKind.Vanilla
            If ComboLoader.SelectedItem IsNot Nothing Then LoaderKind = CType(CType(ComboLoader.SelectedItem, MyComboBoxItem).Tag, ServerLoaderKind)
            If MyMsgBox($"即将为该实例下载并创建 {VersionText}（{CType(ComboLoader.SelectedItem, MyComboBoxItem).Content}）服务端。{vbCrLf}{vbCrLf}下载完成后即可在启动器内直接启动并查看日志。是否继续？", "创建服务器", "开始创建", "取消") <> 1 Then Return
            'EULA 由创建流程内单独确认，这里不代替用户同意
            Dim Request As New ServerInstallRequest With {
                .Instance = TargetInstance,
                .VanillaVersion = VersionText,
                .Loader = LoaderKind,
                .AcceptEula = False
            }
            IsWorking = True
            BtnCreate.IsEnabled = False
            LabInfo.Text = "正在准备……"
            Dim Loader As New LoaderCombo(Of Integer)("创建服务器 " & TargetInstance.Name, ServerInstallLoaders(Request))
            AddHandler Loader.OnStateChangedUi,
            Sub(L As LoaderBase, NewState As LoadState, OldState As LoadState)
                Select Case NewState
                    Case LoadState.Loading
                        LabInfo.Text = $"正在{L.Name}……（{L.Progress * 100:0}%）"
                    Case LoadState.Finished
                        IsWorking = False
                        BtnCreate.IsEnabled = True
                        LabInfo.Text = "服务端已创建完成。"
                        Hint("服务器创建完成！", HintType.Green)
                        RaiseEvent Installed()
                    Case LoadState.Failed
                        IsWorking = False
                        BtnCreate.IsEnabled = True
                        LabInfo.Text = "创建失败："& If(L.Error Is Nothing, "未知错误", L.Error.GetDisplay(False))
                        Logger.Error(L.Error, "创建服务器失败", LogBehavior.Alert)
                    Case LoadState.Canceled
                        IsWorking = False
                        BtnCreate.IsEnabled = True
                        LabInfo.Text = "已取消创建。"
                End Select
            End Sub
            Loader.Start(1)
        Catch ex As Exception
            IsWorking = False
            BtnCreate.IsEnabled = True
            Logger.Error(ex, "创建服务器失败", LogBehavior.Alert)
        End Try
    End Sub

End Class
