Imports System.IO
Imports System.IO.Compression
Imports System.Net.Http
Imports Newtonsoft.Json.Linq

''' <summary>
''' PCL-QW新增：陶瓦联机（Terracotta）后端。
''' 陶瓦联机是基于 EasyTier 的第三方开源联机工具（作者 Burning_TNT，AGPL-3.0 or later，含打包/进程间通信例外条款），
''' 本模块只以“未经修改的可执行程序 + 本机 HTTP 接口”的方式调用它，不链接、不修改其任何代码。
''' 接口约定：以 "terracotta.exe --hmcl &lt;端口信息文件&gt;" 启动后，程序会把 {"port":N} 写入该文件，
''' 随后本机 http://127.0.0.1:N 提供 /state、/state/ide、/state/scanning、/state/guesting、/log 等接口。
''' </summary>
Public Module ModTerracotta

    ''' <summary>
    ''' 随本版本一起适配并测试过的陶瓦版本号。
    ''' </summary>
    Public Const TerracottaVersion As String = "0.4.2"
    ''' <summary>
    ''' 陶瓦联机项目主页，用于界面署名与手动下载。
    ''' </summary>
    Public Const TerracottaProjectUrl As String = "https://github.com/burningtnt/Terracotta"
    Public Const TerracottaAuthor As String = "Burning_TNT 与 Terracotta 贡献者"

    Private Const PackageNameFormat As String = "terracotta-{0}-windows-x86_64-pkg.tar.gz"
    Private Const NodeListUrl As String = "https://terracotta.glavo.site/nodes"
    ''' <summary>
    ''' 官方节点列表获取失败时使用的备用节点。
    ''' </summary>
    Private ReadOnly FallbackNodes As String() = {"https://etnode.zkitefly.eu.org/node1", "https://etnode.zkitefly.eu.org/node2"}

    Public Enum LinkPhase
        ''' <summary>尚未安装陶瓦联机。</summary>
        NotInstalled
        ''' <summary>正在启动陶瓦联机进程。</summary>
        Launching
        ''' <summary>已就绪，未加入任何房间。</summary>
        Waiting
        ''' <summary>房主：正在扫描本地的 Minecraft 服务器。</summary>
        HostScanning
        ''' <summary>房主：正在建立网络。</summary>
        HostStarting
        ''' <summary>房主：房间已就绪。</summary>
        HostReady
        ''' <summary>访客：正在连接房主。</summary>
        GuestConnecting
        ''' <summary>访客：正在建立网络。</summary>
        GuestStarting
        ''' <summary>访客：已连接，可以进入游戏。</summary>
        GuestReady
        ''' <summary>本次联机出现错误。</summary>
        Errored
    End Enum

    ''' <summary>
    ''' 一次状态查询的结果。
    ''' </summary>
    Public Structure LinkStatus
        Public Phase As LinkPhase
        Public Index As Integer
        Public RoomCode As String
        Public Address As String
        Public ErrorText As String
    End Structure

#Region "路径与安装状态"

    ''' <summary>
    ''' 陶瓦联机的存放目录，以 \ 结尾。
    ''' </summary>
    Public ReadOnly Property TerracottaFolder As String
        Get
            Return Paths.AppDataThenName & "Terracotta\"
        End Get
    End Property

    ''' <summary>
    ''' 查找已存在的陶瓦可执行文件；找不到则返回 Nothing。
    ''' 兼容自动安装（陶瓦联机.exe）与用户手动放入的官方发行文件。
    ''' </summary>
    Public Function FindExecutable() As String
        Try
            Dim Preferred = TerracottaFolder & "陶瓦联机.exe"
            If FileUtils.Exists(Preferred) Then Return Preferred
            If FileUtils.Exists(TerracottaFolder & "terracotta.exe") Then Return TerracottaFolder & "terracotta.exe"
            Dim DirInfo As New DirectoryInfo(TerracottaFolder)
            If Not DirInfo.Exists Then Return Nothing
            For Each File In DirInfo.EnumerateFiles("*.exe")
                Dim Name = File.Name.ToLowerInvariant()
                If Name.Contains("terracotta") AndAlso Not Name.Contains("uninstall") Then Return File.FullName
            Next
        Catch ex As Exception
            Logger.Warn(ex, "查找陶瓦联机程序失败")
        End Try
        Return Nothing
    End Function

    ''' <summary>
    ''' 是否已经安装（无论是自动下载还是用户手动放入）。
    ''' </summary>
    Public Function IsInstalled() As Boolean
        Return FindExecutable() IsNot Nothing
    End Function

    Private Function PackageUrl(Version As String, Index As Integer) As String
        Dim FileName = String.Format(PackageNameFormat, Version)
        Select Case Index
            Case 0
                Return $"https://gh-proxy.com/https://github.com/burningtnt/Terracotta/releases/download/v{Version}/{FileName}"
            Case 1
                Return $"https://github.com/burningtnt/Terracotta/releases/download/v{Version}/{FileName}"
            Case Else
                Return $"https://gitee.com/burningtnt/Terracotta/releases/download/v{Version}/{FileName}"
        End Select
    End Function

    ''' <summary>
    ''' 生成陶瓦联机的下载任务列表（多个镜像源）。
    ''' </summary>
    Public Function PrepareDownloadFiles() As List(Of NetFile)
        Dim FileName = String.Format(PackageNameFormat, TerracottaVersion)
        Return New List(Of NetFile) From {
            New NetFile(
                {PackageUrl(TerracottaVersion, 0), PackageUrl(TerracottaVersion, 1), PackageUrl(TerracottaVersion, 2)},
                TerracottaFolder & FileName,
                New FileChecker With {.MinSize = 1024 * 1024 * 2})
        }
    End Function

    ''' <summary>
    ''' 将已下载的 tar.gz 包解压到陶瓦目录，并把主程序重命名为 陶瓦联机.exe。
    ''' </summary>
    Public Sub InstallDownloadedPackage()
        Dim DirInfo As New DirectoryInfo(TerracottaFolder)
        Dim Packages = DirInfo.Exists AndAlso DirInfo.EnumerateFiles("*.tar.gz").Any()
        If Not Packages Then
            If IsInstalled() Then Return
            Throw New Exception("没有找到陶瓦联机的下载文件，请重试或手动下载后放入：" & vbCrLf & TerracottaFolder)
        End If
        For Each Package In DirInfo.EnumerateFiles("*.tar.gz")
            ExtractTarGz(Package.FullName, TerracottaFolder)
            FileUtils.Delete(Package.FullName, False)
        Next
        Dim Exe = FindExecutable()
        If Exe Is Nothing Then Throw New Exception("陶瓦联机安装包内容异常，解压后未找到可执行文件。")
        If Exe.EndsWith("陶瓦联机.exe", True, Nothing) Then Return
        Dim Target = TerracottaFolder & "陶瓦联机.exe"
        If FileUtils.Exists(Target) Then FileUtils.Delete(Target, False)
        FileUtils.Move(Exe, Target)
        Settings.Set("LinkTerracottaVersion", TerracottaVersion)
        Logger.Info($"陶瓦联机已安装：{Target}")
    End Sub

    ''' <summary>
    ''' 解压 .tar.gz（先 GZip 解流，再按 512 字节的 ustar 块取出普通文件）。
    ''' </summary>
    Public Sub ExtractTarGz(ArchivePath As String, TargetFolder As String)
        DirectoryUtils.Create(TargetFolder)
        Using Fs As New FileStream(ArchivePath, FileMode.Open, FileAccess.Read, FileShare.Read)
            Using Gz As New GZipStream(Fs, CompressionMode.Decompress)
                Dim Header(511) As Byte
                Dim LongName As String = Nothing
                Do
                    If Not ReadFull(Gz, Header, 0, 512) Then Exit Do
                    If IsEmptyBlock(Header) Then Continue Do '两个空块代表归档结束
                    Dim Name As String
                    If LongName IsNot Nothing Then
                        Name = LongName
                        LongName = Nothing
                    Else
                        Name = ReadTagString(Header, 0, 100)
                    End If
                    Dim Prefix = ReadTagString(Header, 345, 155)
                    If Prefix <> "" Then Name = Prefix & "/" & Name
                    Dim TypeFlag = Chr(Header(156))
                    Dim Size As Long = ReadOctal(Header, 124, 12)
                    If Name = "" Then
                        SkipBytes(Gz, Size)
                        Continue Do
                    End If
                    Select Case TypeFlag
                        Case "L"c 'GNU 长文件名，下一条才是真实文件
                            Dim Buffer(CInt(Math.Max(Size, 1)) - 1) As Byte
                            ReadFull(Gz, Buffer, 0, Buffer.Length)
                            LongName = Encoding.UTF8.GetString(Buffer).TrimEnd(vbNullChar, " "c, vbCr, vbLf)
                        Case "x"c, "g"c, "A"c, "K"c 'pax 扩展头，直接跳过
                            SkipBytes(Gz, Size)
                        Case "0"c, "7"c '普通文件
                            Dim Target = Path.Combine(TargetFolder, Name.Replace("/"c, IO.Path.DirectorySeparatorChar))
                            If Not Path.GetFullPath(Target).StartsWith(Path.GetFullPath(TargetFolder), StringComparison.OrdinalIgnoreCase) Then
                                Throw New Exception($"压缩包中存在越界路径，已拒绝解压：{Name}") '防 ZipSlip
                            End If
                            DirectoryUtils.Create(Path.GetDirectoryName(Target) & "\")
                            Using Out As New FileStream(Target, FileMode.Create, FileAccess.Write)
                                CopyBytes(Gz, Out, Size)
                            End Using
                        Case Else '目录、符号链接等一律跳过
                            SkipBytes(Gz, Size)
                    End Select
                    '每个文件的内容都会补齐到 512 的整数倍
                    SkipBytes(Gz, (512 - (Size Mod 512)) Mod 512)
                Loop
            End Using
        End Using
    End Sub

    Private Function ReadFull(Stream As Stream, Buffer() As Byte, Offset As Integer, Count As Integer) As Boolean
        Dim Done As Integer = 0
        Do While Done < Count
            Dim Read = Stream.Read(Buffer, Offset + Done, Count - Done)
            If Read <= 0 Then Return Done > 0
            Done += Read
        Loop
        Return True
    End Function
    Private Function IsEmptyBlock(Block() As Byte) As Boolean
        For Each Value In Block
            If Value <> 0 Then Return False
        Next
        Return True
    End Function
    Private Function ReadTagString(Block() As Byte, Offset As Integer, Count As Integer) As String
        Dim Result As New StringBuilder
        For i As Integer = Offset To Offset + Count - 1
            If Block(i) = 0 Then Exit For
            Result.Append(Chr(Block(i)))
        Next
        Return Result.ToString.Trim
    End Function
    Private Function ReadOctal(Block() As Byte, Offset As Integer, Count As Integer) As Long
        Dim Text = ReadTagString(Block, Offset, Count).Trim(" "c, Chr(0))
        If Text = "" Then Return 0
        Dim Result As Long = 0
        For Each c In Text
            If c < "0"c OrElse c > "7"c Then Exit For
            Result = Result * 8 + (AscW(c) - AscW("0"c))
        Next
        Return Result
    End Function
    Private Sub SkipBytes(Stream As Stream, Count As Long)
        If Count <= 0 Then Return
        Dim Buffer(8191) As Byte
        Dim Left = Count
        Do While Left > 0
            Dim Read = Stream.Read(Buffer, 0, CInt(Math.Min(Left, Buffer.Length)))
            If Read <= 0 Then Exit Sub
            Left -= Read
        Loop
    End Sub
    Private Sub CopyBytes(Source As Stream, Target As Stream, Count As Long)
        If Count <= 0 Then Return
        Dim Buffer(8191) As Byte
        Dim Left = Count
        Do While Left > 0
            Dim Read = Source.Read(Buffer, 0, CInt(Math.Min(Left, Buffer.Length)))
            If Read <= 0 Then Exit Sub
            Target.Write(Buffer, 0, Read)
            Left -= Read
        Loop
    End Sub

#End Region

#Region "进程"

    Private ProcessCore As Process
    Private ProcessPort As Integer = 0
    Private ProcessPortFile As String = Nothing
    Private ReadOnly ProcessLock As New Object

    ''' <summary>
    ''' 陶瓦联机的本机接口是否可用。
    ''' 注意：陶瓦写完端口信息后会以返回码 0 正常退出、把服务 detach 到后台，
    ''' 因此不能以我们启动的那个父进程是否存活来判断。
    ''' </summary>
    Public Function IsRunning() As Boolean
        If ProcessPort <= 0 Then Return False
        Try
            Return HttpGet("/state") IsNot Nothing
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public ReadOnly Property HttpPort As Integer
        Get
            Return ProcessPort
        End Get
    End Property

    ''' <summary>
    ''' 启动陶瓦联机并等待其回传本机接口端口。已在运行则直接返回。
    ''' </summary>
    Public Sub EnsureStarted(Optional CancelCheck As Func(Of Boolean) = Nothing)
        SyncLock ProcessLock
            If ProcessPort > 0 AndAlso IsRunning() Then Return
            If ProcessCore IsNot Nothing AndAlso Not ProcessCore.HasExited Then
                Throw New Exception("陶瓦联机正在启动中，请稍候再试。")
            End If
            Dim Exe = FindExecutable()
            If Exe Is Nothing Then Throw New Exception("尚未安装陶瓦联机。")
            '陶瓦联机同一时间只能运行一个实例（它使用全局锁文件）。
            '若用户自己开着陶瓦窗口，本次启动会移交给那个窗口，端口信息永远不会写出，因此先结束残留进程。
            KillStrayProcesses(Nothing)
            ProcessPort = 0
            ProcessPortFile = PathTemp & $"terracotta-http-{GetUuid()}.json"
            FileUtils.Delete(ProcessPortFile, False)
            Dim Info As New ProcessStartInfo With {
                .FileName = Exe,
                .Arguments = $"--hmcl ""{ProcessPortFile}""",
                .WorkingDirectory = TerracottaFolder,
                .UseShellExecute = False,
                .CreateNoWindow = True,
                .RedirectStandardOutput = True,
                .RedirectStandardError = True,
                .StandardOutputEncoding = Encoding.UTF8,
                .StandardErrorEncoding = Encoding.UTF8
            }
            Logger.Info($"正在启动陶瓦联机：{Info.FileName}")
            ProcessCore = StartProcess(Info)
            AddHandler ProcessCore.OutputDataReceived, Sub(sender, e) ProcessLogLine(e.Data)
            AddHandler ProcessCore.ErrorDataReceived, Sub(sender, e) ProcessLogLine(e.Data)
            ProcessCore.BeginOutputReadLine()
            ProcessCore.BeginErrorReadLine()
        End SyncLock
        '等待端口信息文件出现
        Dim Wait As Integer = 0
        Do While Wait < 600 '最多 60 秒
            '必须先读端口文件：陶瓦写完端口之后就可能正常退出，先判断退出会把成功当成失败
            If FileUtils.Exists(ProcessPortFile) Then
                Try
                    Dim Port = CType(JObject.Parse(FileUtils.ReadAsString(ProcessPortFile))("port"), Integer)
                    If Port > 0 Then
                        SyncLock ProcessLock
                            ProcessPort = Port
                        End SyncLock
                        Logger.Info($"陶瓦联机已就绪，本机接口端口 {Port}")
                        Return
                    End If
                Catch ex As Exception
                    Logger.Warn(ex, "解析陶瓦端口信息失败，继续等待")
                End Try
            End If
            If CancelCheck IsNot Nothing AndAlso CancelCheck() Then Throw New OperationCanceledException
            If ProcessCore IsNot Nothing AndAlso ProcessCore.HasExited Then
                '父进程已退出但还没拿到端口：宽限 3 秒等文件落盘，之后才判定失败
                If Wait > 30 Then
                    Throw New Exception($"陶瓦联机已退出（返回码 {ProcessCore.ExitCode}），且没有写出端口信息。{vbCrLf}近期日志：{vbCrLf}{LogTail()}")
                End If
            End If
            Thread.Sleep(100)
            Wait += 1
        Loop
        Throw New Exception($"等待陶瓦联机启动超时，请检查网络与杀毒软件设置后重试。{vbCrLf}近期日志：{vbCrLf}{LogTail()}")
    End Sub

    Private TerracottaLogHistory As New Queue(Of String)
    Private Sub ProcessLogLine(Line As String)
        Try
            If Line Is Nothing Then Return
            Logger.Info(Line)
            SyncLock TerracottaLogHistory
                TerracottaLogHistory.Enqueue(Line)
                Do While TerracottaLogHistory.Count > 200
                    TerracottaLogHistory.Dequeue()
                Loop
            End SyncLock
        Catch ex As Exception
            '日志仅用于诊断，忽略异常
        End Try
    End Sub
    Private Function LogTail() As String
        SyncLock TerracottaLogHistory
            Return String.Join(vbCrLf, TerracottaLogHistory.Skip(Math.Max(0, TerracottaLogHistory.Count - 10)))
        End SyncLock
    End Function

    ''' <summary>
    ''' 结束残留的陶瓦 / EasyTier 进程。KeepId 指定的进程不会被结束。
    ''' </summary>
    Private Sub KillStrayProcesses(KeepId As Integer?)
        For Each Item In Process.GetProcesses()
            Try
                Dim Name = Item.ProcessName.ToLowerInvariant()
                If Not Name.Contains("terracotta") AndAlso Not Name.Contains("easytier") Then Continue For
                If KeepId.HasValue AndAlso Item.Id = KeepId.Value Then Continue For
                Logger.Info($"结束残留的联机进程：{Item.ProcessName} (PID {Item.Id})")
                Item.Kill()
                Item.WaitForExit(2000)
            Catch exx As Exception
                Logger.Warn(exx, "结束残留的联机进程失败")
            End Try
        Next
    End Sub

    ''' <summary>
    ''' 结束陶瓦联机进程（含其内嵌的 EasyTier）。
    ''' </summary>
    Public Sub StopProcess()
        Try
            Dim OwnId As Integer? = Nothing
            SyncLock ProcessLock
                If ProcessCore IsNot Nothing AndAlso Not ProcessCore.HasExited Then
                    Logger.Info($"停止陶瓦联机，PID：{ProcessCore.Id}")
                    Try
                        ProcessCore.Kill()
                        ProcessCore.WaitForExit(3000)
                    Catch exx As Exception
                        Logger.Warn(exx, "停止陶瓦联机失败")
                    End Try
                End If
                OwnId = If(ProcessCore?.Id, Nothing)
                ProcessCore = Nothing
                ProcessPort = 0
            End SyncLock
            KillStrayProcesses(OwnId)
            If ProcessPortFile IsNot Nothing Then FileUtils.Delete(ProcessPortFile, False)
        Catch ex As Exception
            Logger.Warn(ex, "停止陶瓦联机时出错")
        End Try
    End Sub

#End Region

#Region "HTTP 接口"

    Private ReadOnly LinkClient As New HttpClient With {.Timeout = TimeSpan.FromSeconds(15)}

    Private Function HttpGet(Path As String) As String
        If ProcessPort <= 0 Then Throw New Exception("陶瓦联机尚未就绪。")
        Try
            Dim Task = LinkClient.GetStringAsync($"http://127.0.0.1:{ProcessPort}{Path}")
            If Not Task.Wait(12000) Then Throw New TimeoutException("陶瓦联机接口无响应")
            Return Task.Result
        Catch ex As Exception
            ex.ThrowIfCanceled()
            Throw New Exception($"访问陶瓦联机接口失败：{ex.Message}", ex)
        End Try
    End Function

    ''' <summary>
    ''' 回到空闲状态（离开房间 / 关闭房间）。
    ''' </summary>
    Public Sub SetIdle()
        Try
            HttpGet("/state/ide")
        Catch ex As Exception
            Logger.Warn(ex, "通知陶瓦联机回到空闲状态失败")
        End Try
    End Sub

    ''' <summary>
    ''' 作为房主创建房间。陶瓦会先扫描本地的 Minecraft 服务器，找到后才会给出房间码。
    ''' </summary>
    Public Sub StartHost(PlayerName As String)
        HttpGet("/state/scanning?" & NodeQuery(PlayerName, Nothing))
    End Sub

    ''' <summary>
    ''' 作为访客加入房间。
    ''' </summary>
    Public Sub JoinRoom(RoomCode As String, PlayerName As String)
        HttpGet("/state/guesting?" & NodeQuery(PlayerName, RoomCode))
    End Sub

    Private Function NodeQuery(PlayerName As String, RoomCode As String) As String
        Dim Query As New List(Of String)
        If RoomCode IsNot Nothing Then Query.Add("room=" & Uri.EscapeDataString(RoomCode))
        Query.Add("player=" & Uri.EscapeDataString(If(String.IsNullOrEmpty(PlayerName), "Player", PlayerName)))
        For Each Node In GetPublicNodes()
            Query.Add("public_nodes=" & Uri.EscapeDataString(Node))
        Next
        Return String.Join("&", Query)
    End Function

    Private CachedNodes As List(Of String) = Nothing
    Private CachedNodesTime As Date = Date.MinValue
    ''' <summary>
    ''' 公共节点列表。优先使用设置中的自定义节点，其次是在线节点表（缓存 10 分钟），最后回退到内置节点。
    ''' </summary>
    Public Function GetPublicNodes() As List(Of String)
        Try
            Dim Custom = Settings.Get(Of String)("LinkCustomPeer")
            If Not String.IsNullOrWhiteSpace(Custom) Then
                Return Custom.Split({","c, "，"c, vbCr, vbLf, " "c}, StringSplitOptions.RemoveEmptyEntries).ToList()
            End If
        Catch ex As Exception
            Logger.Warn(ex, "读取自定义节点失败")
        End Try
        If CachedNodes IsNot Nothing AndAlso (Date.Now - CachedNodesTime) < TimeSpan.FromMinutes(10) Then Return CachedNodes
        Try
            Dim Json = NetRequestByClientRetry(NodeListUrl, Encoding:=Encoding.UTF8, RequireJson:=True).DeserializeJson()
            Dim Result As New List(Of String)
            For Each Item In CType(Json, JArray)
                Dim Url = Item("url")?.ToString
                If Not String.IsNullOrWhiteSpace(Url) Then Result.Add(Url.ToString)
            Next
            If Result.Any Then
                CachedNodes = Result
                CachedNodesTime = Date.Now
                Return Result
            End If
        Catch ex As Exception
            Logger.Warn(ex, "获取陶瓦公共节点列表失败，使用内置节点")
        End Try
        CachedNodes = FallbackNodes.ToList()
        CachedNodesTime = Date.MinValue '回退结果不长期缓存
        Return CachedNodes
    End Function

    ''' <summary>
    ''' 获取当前联机状态。进程未运行或接口无响应时返回 Nothing。
    ''' </summary>
    Public Function QueryStatus() As LinkStatus?
        If ProcessPort <= 0 Then Return Nothing
        Dim Result As New LinkStatus
        Try
            Dim Json = CType(HttpGet("/state").DeserializeJson(), JObject)
            Result.Index = Val(Json("index")?.ToString)
            Select Case Json("state")?.ToString
                Case "waiting" : Result.Phase = LinkPhase.Waiting
                Case "host-scanning" : Result.Phase = LinkPhase.HostScanning
                Case "host-starting" : Result.Phase = LinkPhase.HostStarting
                Case "host-ok"
                    Result.Phase = LinkPhase.HostReady
                    Result.RoomCode = Json("room")?.ToString
                Case "guest-connecting" : Result.Phase = LinkPhase.GuestConnecting
                Case "guest-starting" : Result.Phase = LinkPhase.GuestStarting
                Case "guest-ok"
                    Result.Phase = LinkPhase.GuestReady
                    Result.Address = Json("url")?.ToString
                Case "exception"
                    Result.Phase = LinkPhase.Errored
                    Result.ErrorText = DescribeException(Val(Json("type")?.ToString))
                Case Else
                    Result.Phase = LinkPhase.Waiting
            End Select
            Return Result
        Catch ex As Exception
            Logger.Warn(ex, "获取陶瓦联机状态失败")
            Return Nothing
        End Try
    End Function

    Private Function DescribeException(Index As Integer) As String
        Select Case Index
            Case 0 : Return "无法连接到房主（Ping 失败）。"
            Case 1 : Return "与房主的连接被拒绝，房主可能已经关闭了房间。"
            Case 2 : Return "访客端的联机组件意外退出。"
            Case 3 : Return "房主端的联机组件意外退出。"
            Case 4 : Return "无法连接到本地的 Minecraft 服务器，请确认服务器已经启动。"
            Case 5 : Return "联机服务返回了无法识别的内容。"
            Case Else : Return $"联机过程出现错误（类型 {Index}）。"
        End Select
    End Function

    ''' <summary>
    ''' 导出陶瓦联机的运行日志，用于排查问题。
    ''' </summary>
    Public Function GetLogs() As String
        Try
            Return HttpGet("/log?fetch=true")
        Catch ex As Exception
            Logger.Warn(ex, "获取陶瓦联机日志失败")
            Return LogTail()
        End Try
    End Function

#End Region

End Module
