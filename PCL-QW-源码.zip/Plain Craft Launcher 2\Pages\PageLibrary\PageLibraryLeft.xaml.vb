Public Class PageLibraryLeft

    'PCL-QW新增：实例库左侧入口为固定项，无需子页面切换逻辑

    Private Sub PageLibraryLeft_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        If ItemFolder.Logo = "" Then ItemFolder.Logo = Logo.IconButtonOpen
    End Sub

    '打开游戏文件夹
    Private Sub ItemFolder_Click(sender As Object, e As MouseButtonEventArgs) Handles ItemFolder.Click
        Try
            OpenExplorer(McFolderSelected)
        Catch ex As Exception
            Logger.Error(ex, "打开游戏文件夹失败", LogBehavior.Alert)
        End Try
    End Sub

    '刷新实例列表
    Private Sub ItemAll_Click(sender As Object, e As MouseButtonEventArgs) Handles ItemAll.Click
        LoaderFolderRun(McInstanceListLoader, McFolderSelected, LoaderFolderRunType.ForceRun, MaxDepth:=1, ExtraPath:="versions\")
        Hint("正在刷新实例列表……", Log:=False)
    End Sub

End Class
