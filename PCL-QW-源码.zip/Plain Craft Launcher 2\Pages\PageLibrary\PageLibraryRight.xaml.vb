Public Class PageLibraryRight

    'PCL-QW新增：实例库主页。列出全部实例，可启动、打开文件夹或进入实例管理。

    Private Sub PageLibraryRight_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        LoaderFolderRun(McInstanceListLoader, McFolderSelected, LoaderFolderRunType.RunOnUpdated, MaxDepth:=1, ExtraPath:="versions\")
        PanBack.ScrollToHome()
    End Sub
    Private Sub LoaderInit() Handles Me.Initialized
        PageLoaderInit(Load, PanLoad, PanAllBack, Nothing, McInstanceListLoader, AddressOf McInstanceListUI, AutoRun:=False)
    End Sub
    Private Sub Load_Click(sender As Object, e As MouseButtonEventArgs) Handles Load.Click
        If McInstanceListLoader.State = LoadState.Failed Then
            LoaderFolderRun(McInstanceListLoader, McFolderSelected, LoaderFolderRunType.ForceRun, MaxDepth:=1, ExtraPath:="versions\")
        End If
    End Sub

    '列表 UI 化
    Private Sub McInstanceListUI(Loader As LoaderTask(Of String, Integer))
        Try
            PanList.Children.Clear()
            '收集全部实例（不含被隐藏的版本）
            Dim AllInstances As New List(Of McInstance)
            For Each Card In McInstanceList
                If Card.Key = McInstanceCardType.Hidden Then Continue For
                For Each Instance In Card.Value
                    If Not AllInstances.Contains(Instance) Then AllInstances.Add(Instance)
                Next
            Next
            AllInstances = AllInstances.OrderBy(Function(i) i.Name).ToList()
            If Not AllInstances.Any() Then
                CardAll.Visibility = Visibility.Collapsed
                CardEmpty.Visibility = Visibility.Visible
                Return
            End If
            CardAll.Visibility = Visibility.Visible
            CardEmpty.Visibility = Visibility.Collapsed
            For Each Instance In AllInstances
                PanList.Children.Add(GetInstanceItem(Instance))
            Next
        Catch ex As Exception
            Logger.Error(ex, "实例库列表加载失败")
        End Try
    End Sub

    '构建单个实例条目
    Private Function GetInstanceItem(Instance As McInstance) As MyListItem
        Dim Info As String = Instance.Version.VanillaName
        If Instance.Version.HasForge Then Info &= " Forge " & Instance.Version.Forge
        If Instance.Version.HasNeoForge Then Info &= " NeoForge " & Instance.Version.NeoForge
        If Instance.Version.HasFabric Then Info &= " Fabric " & Instance.Version.Fabric
        If Instance.Version.HasLiteLoader Then Info &= " LiteLoader"
        If Instance.Version.HasOptiFine Then Info &= " OptiFine " & Instance.Version.OptiFine
        Dim Item As New MyListItem With {
            .Title = Instance.Name,
            .Info = Info,
            .Height = 42,
            .Type = MyListItem.CheckType.Clickable,
            .LogoScale = 0.95,
            .MinPaddingRight = 10
        }
        If Not String.IsNullOrEmpty(Instance.Logo) Then Item.Logo = Instance.Logo
        '单击条目进入实例管理
        AddHandler Item.Click, Sub() OpenInstance(Instance)
        '按钮：启动 / 打开文件夹 / 进入管理
        Dim BtnLaunch As New MyIconButton With {.LogoScale = 0.95, .Logo = "M288 160 L800 512 L288 864 Z", .ToolTip = "启动游戏"}
        Dim BtnFolder As New MyIconButton With {.LogoScale = 0.95, .Logo = Logo.IconButtonOpen, .ToolTip = "打开游戏文件夹"}
        Dim BtnEnter As New MyIconButton With {.LogoScale = 0.95, .Logo = Logo.IconButtonSetup, .ToolTip = "进入实例管理"}
        AddHandler BtnLaunch.Click, Sub() McLaunchStart(New McLaunchOptions With {.Instance = Instance})
        AddHandler BtnFolder.Click, Sub() PageInstanceOverall.OpenInstanceFolder(Instance)
        AddHandler BtnEnter.Click, Sub() OpenInstance(Instance)
        Dim IsPinned As Boolean = ModRecent.IsPinned(ModRecent.RecentKind.Instance, Instance.Name)
        Dim BtnPin As New MyIconButton With {
            .LogoScale = 0.95,
            .Logo = If(IsPinned, Logo.IconButtonLikeFill, Logo.IconButtonLikeLine),
            .ToolTip = If(IsPinned, "取消固定到首页", "固定到首页")}
        AddHandler BtnPin.Click, Sub() ToggleInstancePin(Instance.Name)
        Item.Buttons = {BtnLaunch, BtnFolder, BtnEnter, BtnPin}
        Return Item
    End Function

    '固定 / 取消固定该实例
    Private Sub ToggleInstancePin(Name As String)
        ModRecent.TogglePin(ModRecent.RecentKind.Instance, Name)
        McInstanceListUI(McInstanceListLoader)
    End Sub

    '进入实例管理页面
    Private Sub OpenInstance(Instance As McInstance)
        PageInstanceLeft.Instance = Instance
        FrmMain.PageChange(FormMain.PageType.InstanceSetup, FormMain.PageSubType.InstanceOverall)
    End Sub

End Class
