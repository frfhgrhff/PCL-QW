Public Class PageInstanceLog

    'PCL-QW新增：日志与崩溃报告页面

    Private Sub PageInstanceLog_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        RefreshList()
    End Sub
    Private Sub BtnRefresh_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnRefresh.Click
        RefreshList()
        Hint("已刷新！", HintType.Green, False)
    End Sub

    Private Sub RefreshList()
        Try
            PanList.Children.Clear()
            Dim Instance = PageInstanceLeft.Instance
            If Instance Is Nothing Then Return
            'PCL 运行日志
            For i = 1 To 5
                AddLogItem($"PCL 运行日志 Log{i}.txt", Paths.Base & "PCL\Log" & i & ".txt")
            Next
            '游戏最新日志
            AddLogItem("游戏最新日志 latest.log", Instance.PathIndie & "logs\latest.log")
            '崩溃报告（最多 20 个，按时间倒序）
            Dim CrashFolder As String = Instance.PathIndie & "crash-reports\"
            Dim CrashInfo As New System.IO.DirectoryInfo(CrashFolder)
            If CrashInfo.Exists Then
                For Each FileItem As System.IO.FileInfo In CrashInfo.EnumerateFiles("*.txt").OrderByDescending(Function(f) f.LastWriteTime).Take(20)
                    AddLogItem("崩溃报告 " & FileItem.Name, FileItem.FullName)
                Next
                For Each FileItem As System.IO.FileInfo In CrashInfo.EnumerateFiles("*.log").OrderByDescending(Function(f) f.LastWriteTime).Take(20)
                    AddLogItem("崩溃报告 " & FileItem.Name, FileItem.FullName)
                Next
            End If
            LabEmpty.Visibility = If(PanList.Children.Count > 0, Visibility.Collapsed, Visibility.Visible)
        Catch ex As Exception
            Logger.Error(ex, "加载日志列表失败")
        End Try
    End Sub

    Private Sub AddLogItem(Title As String, FilePath As String)
        Try
            If Not FileUtils.Exists(FilePath) Then Return
            Dim Info As String = ""
            Try
                Dim FileInfo = FileUtils.GetInfo(FilePath)
                Info = $"{FileInfo.Length / 1024:0.0} KB · {FileInfo.LastWriteTime:MM-dd HH:mm}"
            Catch ex As Exception
                Logger.Warn(ex, $"读取日志信息失败：{FilePath}")
            End Try
            Dim Item As New MyListItem With {
                .Title = Title,
                .Info = Info,
                .Height = 42,
                .Type = MyListItem.CheckType.Clickable,
                .LogoScale = 0.95,
                .MinPaddingRight = 10,
                .Logo = Logo.IconButtonList
            }
            AddHandler Item.Click, Sub() StartProcess(FilePath)
            Dim BtnOpen As New MyIconButton With {.LogoScale = 0.95, .Logo = Logo.IconButtonOpen, .ToolTip = "用系统程序打开"}
            Dim BtnCopy As New MyIconButton With {.LogoScale = 0.95, .Logo = Logo.IconButtonSave, .ToolTip = "复制日志内容到剪贴板"}
            Dim BtnFolder As New MyIconButton With {.LogoScale = 0.95, .Logo = Logo.IconButtonEdit, .ToolTip = "在文件夹中打开"}
            AddHandler BtnOpen.Click, Sub() StartProcess(FilePath)
            AddHandler BtnCopy.Click, Sub() CopyLog(FilePath)
            AddHandler BtnFolder.Click, Sub() OpenExplorer(FilePath)
            Item.Buttons = {BtnOpen, BtnCopy, BtnFolder}
            PanList.Children.Add(Item)
        Catch ex As Exception
            Logger.Warn(ex, $"添加日志条目失败：{FilePath}")
        End Try
    End Sub

    Private Sub CopyLog(FilePath As String)
        Try
            Dim FileInfo = FileUtils.GetInfo(FilePath)
            If FileInfo.Length > 2 * 1024 * 1024 Then
                Hint("日志文件过大（超过 2 MB），请直接使用「用系统程序打开」。", HintType.Red)
                Return
            End If
            Dim Content = FileUtils.TryReadAsString(FilePath)
            If String.IsNullOrEmpty(Content) Then
                Hint("日志内容为空或读取失败。", HintType.Red)
                Return
            End If
            ClipboardSet(Content)
        Catch ex As Exception
            Logger.Error(ex, "复制日志失败", LogBehavior.Alert)
        End Try
    End Sub

End Class
