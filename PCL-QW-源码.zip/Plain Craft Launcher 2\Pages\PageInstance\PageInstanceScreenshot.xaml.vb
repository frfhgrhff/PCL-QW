Imports System.Windows.Media.Imaging

Public Class PageInstanceScreenshot

    'PCL-QW新增：游戏截图快捷查看

    Private IsLoading As Boolean = False
    Private SelectedPath As String = Nothing
    ''' <summary>
    ''' 最多展示的截图数量，避免截图极多时一次性解码过多图片。
    ''' </summary>
    Private Const MaxEntries As Integer = 200

    Private Sub PageInstanceScreenshot_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        RefreshList()
    End Sub

    Private ReadOnly Property TargetFolder As String
        Get
            Dim Instance = PageInstanceLeft.Instance
            Return If(Instance Is Nothing, McFolderSelected, Instance.PathIndie) & "screenshots\"
        End Get
    End Property

#Region "工具栏"

    Private Sub BtnFolder_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnFolder.Click
        Try
            DirectoryUtils.Create(TargetFolder)
            OpenExplorer(TargetFolder)
        Catch ex As Exception
            Logger.Error(ex, "打开截图文件夹失败", LogBehavior.Alert)
        End Try
    End Sub

    Private Sub BtnRefresh_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnRefresh.Click
        RefreshList()
    End Sub

    Private Sub BtnOpenLarge_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnOpenLarge.Click
        If SelectedPath Is Nothing Then Return
        Try
            StartProcess(SelectedPath)
        Catch ex As Exception
            OpenExplorer(SelectedPath)
        End Try
    End Sub

    Private Sub BtnCopyImage_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnCopyImage.Click
        Try
            If SelectedPath Is Nothing Then Return
            Dim Bitmap = LoadBitmap(SelectedPath, 0)
            If Bitmap Is Nothing Then Throw New Exception("无法读取该图片，可能它已被移动或删除。")
            Clipboard.SetImage(Bitmap)
            Hint("已复制图片到剪贴板！", HintType.Green)
        Catch ex As Exception
            Logger.Error(ex, "复制图片失败", LogBehavior.Alert)
        End Try
    End Sub

    Private Sub BtnCopyPath_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnCopyPath.Click
        If SelectedPath Is Nothing Then Return
        ClipboardSet(SelectedPath, False)
        OpenExplorer(SelectedPath)
        Hint("已复制文件位置，并在资源管理器中选中该文件。", HintType.Green)
    End Sub

    Private Sub BtnRename_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnRename.Click
        Try
            If SelectedPath Is Nothing Then Return
            Dim FileName = IO.Path.GetFileName(SelectedPath)
            Dim NewName = MyMsgBoxInput("重命名截图", "建议保留原有扩展名，否则系统可能无法识别。", FileName)
            If NewName Is Nothing Then Return
            NewName = NewName.Trim
            If NewName = "" OrElse NewName = FileName Then Return
            If IO.Path.GetExtension(NewName) = "" Then NewName &= IO.Path.GetExtension(FileName)
            Dim Target = IO.Path.GetDirectoryName(SelectedPath) & "\" & NewName
            If FileUtils.Exists(Target) Then Throw New Exception($"已存在同名文件：{NewName}")
            FileUtils.Move(SelectedPath, Target)
            SelectedPath = Target
            Hint("已重命名截图！", HintType.Green)
            RefreshList()
        Catch ex As Exception
            Logger.Error(ex, "重命名截图失败", LogBehavior.Alert)
        End Try
    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnDelete.Click
        Try
            If SelectedPath Is Nothing Then Return
            Dim FileName = IO.Path.GetFileName(SelectedPath)
            If MyMsgBox($"确定要删除截图 {FileName} 吗？{vbCrLf}它将被移入系统回收站，可在回收站中找回。", "删除截图", "删除", "取消", IsWarn:=True) <> 1 Then Return
            FileUtils.Delete(SelectedPath, True)
            SelectedPath = Nothing
            PanPreview.Visibility = Visibility.Collapsed
            Hint($"已删除截图 {FileName}！", HintType.Green)
            RefreshList()
        Catch ex As Exception
            Logger.Error(ex, "删除截图失败", LogBehavior.Alert)
        End Try
    End Sub

#End Region

#Region "列表加载"

    Private Class Entry
        Public Path As String
        Public Name As String
        Public Time As Date
        Public Size As Long
        Public Width As Integer
        Public Height As Integer
        Public Thumb As BitmapSource
    End Class

    Private Sub RefreshList()
        If IsLoading Then Return
        IsLoading = True
        Dim Folder As String = TargetFolder
        RunInThread(
        Sub()
            Dim Entries As New List(Of Entry)
            Try
                Dim DirInfo As New System.IO.DirectoryInfo(Folder)
                If DirInfo.Exists Then
                    Dim Files = DirInfo.EnumerateFiles().
                        Where(Function(f) {".png", ".jpg", ".jpeg", ".bmp", ".gif"}.Contains(f.Extension.ToLowerInvariant())).
                        OrderByDescending(Function(f) f.LastWriteTime).Take(MaxEntries).ToList()
                    For Each File In Files
                        Dim Item As New Entry With {
                            .Path = File.FullName,
                            .Name = File.Name,
                            .Time = File.LastWriteTime,
                            .Size = File.Length
                        }
                        GetImageSize(Item)
                        Item.Thumb = LoadBitmap(Item.Path, 220)
                        Entries.Add(Item)
                    Next
                End If
            Catch ex As Exception
                Logger.Warn(ex, "加载截图列表失败")
            End Try
            RunInUi(
            Sub()
                Try
                    PanList.Children.Clear()
                    LabEmpty.Visibility = If(Entries.Any(), Visibility.Collapsed, Visibility.Visible)
                    For Each Item In Entries
                        PanList.Children.Add(GetThumbItem(Item))
                    Next
                    If SelectedPath IsNot Nothing AndAlso Not Entries.Any(Function(e) e.Path = SelectedPath) Then
                        SelectedPath = Nothing
                        PanPreview.Visibility = Visibility.Collapsed
                    End If
                Finally
                    IsLoading = False
                End Try
            End Sub)
        End Sub)
    End Sub

    Private Function GetThumbItem(Item As Entry) As Border
        Dim Pic As New Image With {
            .Source = Item.Thumb,
            .Stretch = Stretch.UniformToFill,
            .Width = 196,
            .Height = 110
        }
        Dim Info As String = Item.Name
        If Item.Width > 0 Then Info &= $"　·　{Item.Width} × {Item.Height}"
        Info &= $"　·　{Item.Size / 1024:N0} KB　·　{Item.Time:yyyy-MM-dd HH:mm}"
        Dim Board As New Border With {
            .Child = Pic,
            .Tag = Item.Path,
            .ToolTip = Info,
            .CornerRadius = New CornerRadius(6),
            .Margin = New Thickness(0, 0, 10, 10),
            .BorderThickness = New Thickness(2),
            .Background = New SolidColorBrush(Color.FromArgb(&H11, 0, 0, 0)),
            .BorderBrush = If(Item.Path = SelectedPath, Brushes.DodgerBlue, New SolidColorBrush(Color.FromArgb(&H22, 0, 0, 0))),
            .ClipToBounds = True,
            .Cursor = Cursors.Hand
        }
        AddHandler Board.MouseLeftButtonUp,
        Sub()
            SelectedPath = Item.Path
            For Each LoopItem In PanList.Children
                Dim ChildBoard = TryCast(LoopItem, Border)
                If ChildBoard IsNot Nothing Then ChildBoard.BorderBrush = New SolidColorBrush(Color.FromArgb(&H22, 0, 0, 0))
            Next
            Board.BorderBrush = Brushes.DodgerBlue
            ShowPreview(Item, Info)
        End Sub
        Return Board
    End Function

    Private Sub ShowPreview(Item As Entry, Info As String)
        Try
            PanPreview.Visibility = Visibility.Visible
            ImgPreview.Source = LoadBitmap(Item.Path, 1600)
            LabPreviewInfo.Text = Info
        Catch ex As Exception
            Logger.Warn(ex, "预览截图失败")
            ImgPreview.Source = Nothing
            LabPreviewInfo.Text = Item.Name
        End Try
    End Sub

#End Region

#Region "图片读取"

    ''' <summary>
    ''' 读取图片。DecodeWidth 为 0 时按原始尺寸读取。
    ''' </summary>
    Private Function LoadBitmap(FilePath As String, DecodeWidth As Integer) As BitmapSource
        Try
            Dim Bitmap As New BitmapImage()
            Bitmap.BeginInit()
            Bitmap.CacheOption = BitmapCacheOption.OnLoad
            If DecodeWidth > 0 Then Bitmap.DecodePixelWidth = DecodeWidth
            Bitmap.UriSource = New Uri(FilePath, UriKind.Absolute)
            Bitmap.EndInit()
            Bitmap.Freeze()
            Return Bitmap
        Catch ex As Exception
            Logger.Warn(ex, $"读取图片失败：{FilePath}")
            Return Nothing
        End Try
    End Function

    ''' <summary>
    ''' 获取图片像素尺寸：PNG 直接读文件头，其余格式按 1 像素宽度解码以取得尺寸。
    ''' </summary>
    Private Sub GetImageSize(Item As Entry)
        Try
            If Item.Name.EndsWithF(".png", True) Then
                Using Fs As New System.IO.FileStream(Item.Path, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.ReadWrite Or System.IO.FileShare.Delete)
                    Dim Head(31) As Byte
                    If Fs.Read(Head, 0, 32) = 32 AndAlso Head(0) = &H89 AndAlso Head(1) = &H50 AndAlso Head(2) = &H4E AndAlso Head(3) = &H47 Then
                        Item.Width = Head(16) * &H1000000 + Head(17) * &H10000 + Head(18) * &H100 + Head(19)
                        Item.Height = Head(20) * &H1000000 + Head(21) * &H10000 + Head(22) * &H100 + Head(23)
                    End If
                End Using
            End If
            If Item.Width = 0 Then
                Dim Bitmap = LoadBitmap(Item.Path, 1)
                If Bitmap IsNot Nothing Then
                    Item.Width = Bitmap.PixelWidth
                    Item.Height = Bitmap.PixelHeight
                End If
            End If
        Catch ex As Exception
            Logger.Warn(ex, "读取图片尺寸失败")
        End Try
    End Sub

#End Region

End Class
