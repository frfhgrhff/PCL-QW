Imports System.Collections.ObjectModel
Imports System.Globalization
Imports System.Net.Sockets
Imports System.Reflection
Imports Newtonsoft.Json.Linq
Imports PCL

''' <summary>
''' PCL-QW：联机页面。
''' 后端由官方版的 EasyTier 在线配置改为第三方开源工具「陶瓦联机（Terracotta）」，
''' 因此不再依赖只有官方版才能获取的 ServerConfig。
''' </summary>
Public Class PageLinkMain
    ''' <summary>
    ''' 房间码长度限制，仅用于基本的输入校验；陶瓦会给出真正的合法性判断。
    ''' </summary>
    Private Const RoomCodeMinLength As Integer = 3
    Private Const RoomCodeMaxLength As Integer = 64

    '===============================
    '  状态机与前端页面
    '===============================

#Region "状态管理"

    Public Enum LinkStates
        Waiting
        Loading
        Failed
        Finished
    End Enum
    Public Shared LinkState As LinkStates = LinkStates.Waiting

    ''' <summary>
    ''' 由服务器页面的「联机直通」置位：进入本页后立即以房主身份创建房间。
    ''' </summary>
    Public Shared PendingHost As Boolean = False

    ''' <summary>
    ''' 切换到指定的状态。
    ''' </summary>
    Private Sub ChangeState(NewState As LinkStates)
        If LinkState = NewState Then Return
        Dim OldState = LinkState
        LinkState = NewState
        Logger.Info($"联机状态由 {OldState} 变更为 {NewState}")
        '触发状态切换
        RunInUi(
        Sub()
            Select Case NewState
                Case LinkStates.Waiting
                    SwitchToWaiting(OldState)
                Case LinkStates.Loading
                    SwitchToLoading(OldState)
                Case LinkStates.Failed
                    SwitchToFailed(OldState)
                Case LinkStates.Finished
                    SwitchToFinished(OldState)
            End Select
        End Sub)
    End Sub

    '让加载器的 成功/失败 事件触发状态切换
    Private Sub LoaderInit() Handles Me.Initialized
        PageLoaderInit(Load, PanLoad, PanContent, PanAlways, LinkLoader, AutoRun:=False)
        AddHandler LinkLoader.OnStateChangedUi,
        Sub(Loader As LoaderBase, NewState As LoadState, OldState As LoadState)
            Select Case NewState
                Case LoadState.Finished
                    ChangeState(LinkStates.Finished)
                Case LoadState.Failed
                    ChangeState(LinkStates.Failed)
            End Select
        End Sub
    End Sub

    '页面动画兼容
    Private Sub UpdatePanelVisibility() Handles Me.PageEnter
        FrmLinkMain.PanSelect.Visibility = If(LinkState = LinkStates.Waiting, Visibility.Visible, Visibility.Collapsed)
        FrmLinkMain.PanFinish.Visibility = If(LinkState = LinkStates.Finished, Visibility.Visible, Visibility.Collapsed)
    End Sub

#End Region

#Region "初始页面 (Waiting)"

    '由任意状态切换到 Waiting
    Private Sub SwitchToWaiting(OldState As LinkStates)
        '加载器与进程状态
        LinkLoader.Cancel()
        SyncLock LinkLoader.LockState
            LinkLoader.State = LoadState.Waiting
        End SyncLock
        Try
            ModTerracotta.SetIdle()
        Catch ex As Exception
            Logger.Warn(ex, "回到空闲联机状态失败")
        End Try
        '页面切换
        If OldState <> LinkStates.Finished Then
            UpdatePanelVisibility()
        End If
        PageOnContentExit()
    End Sub

    '创建房间
    Private Sub Create_MouseLeftButtonUp() Handles PanSelectCreate.MouseLeftButtonUp
        IsServerSide = True
        PlayerName = AskPlayerName()
        Logger.Info($"尝试创建联机房间，玩家名 {PlayerName}")
        ChangeState(LinkStates.Loading)
    End Sub

    '加入房间
    Private Shared LastCode As String = Nothing
    ''' <summary>
    ''' 输入房间码，切换到联机页并立即加入房间。
    ''' </summary>
    Public Shared Sub Join() Handles PanSelectJoin.MouseLeftButtonUp
        Dim Code As String = MyMsgBoxInput("输入房间码", "输入房主发给你的房间码。",
            HintText:=If(String.IsNullOrEmpty(LastCode), "", "使用上一次的房间码"))
        If Not String.IsNullOrEmpty(LastCode) AndAlso Code IsNot Nothing AndAlso Code = "" Then Code = LastCode
        If Code Is Nothing Then Return
        Join(Code)
    End Sub
    Public Sub JoinInternal(Code As String)
        Dim Invalid = ValidateCodeFormat(Code)
        If Invalid IsNot Nothing Then
            Hint(Invalid, HintType.Red)
            Return
        End If
        IsServerSide = False
        RoomCode = Code.Trim
        PlayerName = AskPlayerName()
        Logger.Info($"尝试加入联机房间 {RoomCode}，玩家名 {PlayerName}")
        LastCode = Code
        ChangeState(LinkStates.Loading)
    End Sub
    ''' <summary>
    ''' 校验房间码格式，合法时返回 Nothing。
    ''' </summary>
    Public Shared Function ValidateCodeFormat(Code As String) As String
        If Code Is Nothing Then Return "房间码为空！"
        Code = Code.Trim
        If Code.Length < RoomCodeMinLength OrElse Code.Length > RoomCodeMaxLength Then Return $"房间码长度应在 {RoomCodeMinLength} 到 {RoomCodeMaxLength} 个字符之间！"
        For Each c In Code
            If Not Char.IsLetterOrDigit(c) AndAlso c <> "-"c AndAlso c <> "_"c AndAlso c <> ":"c AndAlso c <> "."c Then Return "房间码有误，请向房主确认！"
        Next
        Return Nothing
    End Function

    ''' <summary>
    ''' 询问并记住联机使用的玩家名。
    ''' </summary>
    Private Function AskPlayerName() As String
        Dim Last = Settings.Get(Of String)("LinkPlayerName")
        If String.IsNullOrWhiteSpace(Last) Then Last = Environment.UserName
        Dim Input = MyMsgBoxInput("你的游戏昵称", "该昵称会显示给房间内的其他玩家。", Last,
            ValidateRules:=New Collection(Of Validate) From {New ValidateLength(RoomCodeMinLength, 16)}, HintText:="仅支持中英文与数字")
        If Input Is Nothing Then Return Last
        Input = Input.Trim
        If Input = "" Then Return Last
        Settings.Set("LinkPlayerName", Input)
        Return Input
    End Function

    '自动加入
    ''' <summary>
    ''' 切换到联机页并立即加入指定房间。
    ''' </summary>
    Public Shared Sub Join(Code As String)
        If LinkState <> LinkStates.Waiting Then
            Hint("你已经在联机房间中了！", HintType.Red)
        ElseIf FrmMain.PageCurrent = FormMain.PageType.Link Then
            FrmLinkMain.JoinInternal(Code)
        Else
            AutoJoinCode = Code
            FrmMain.PageChange(FormMain.PageType.Link, FormMain.PageSubType.LinkMain)
        End If
    End Sub
    '在进入页面时自动尝试加入房间 / 创建房间
    Private Shared AutoJoinCode As String = Nothing
    Private Sub PanSelectJoin_Loaded() Handles Me.Loaded, Me.PageEnter
        If LinkState <> LinkStates.Waiting Then Return
        If AutoJoinCode IsNot Nothing Then
            Dim Code = AutoJoinCode
            AutoJoinCode = Nothing
            JoinInternal(Code)
        ElseIf PendingHost Then
            PendingHost = False
            Create_MouseLeftButtonUp()
        End If
    End Sub

#End Region

#Region "加载页面 (Loading | Failed)"

    '由 Waiting 或 Failed 状态切换到 Loading
    Private Sub SwitchToLoading(OldState As LinkStates)
        FailReason = "准备初始化"
        LinkLoader.Start(IsForceRestart:=True)
        UpdateProgressBar(0)
        LabLoadTitle.Text = If(IsServerSide, "创建房间中", "加入房间中")
        UpdateLoadingPage("正在准备陶瓦联机……", "准备陶瓦联机")
    End Sub

    '由 Loading 状态切换到 Failed
    Private Sub SwitchToFailed(OldState As LinkStates)
        LinkLoader.Cancel()
        UpdateProgressBar(1)
        LabLoadTitle.Text = FailReason
        Dim Brief As String = LinkLoader.Error.GetDisplay(False)
        Dim InnerEx As Exception = LinkLoader.Error
        If InnerEx.Message.StartsWithF("$") Then Brief = InnerEx.Message
        Do Until InnerEx.InnerException Is Nothing
            InnerEx = InnerEx.InnerException
            If InnerEx.Message.StartsWithF("$") Then Brief = InnerEx.Message
        Loop
        LabLoadDesc.Text = If(Brief.StartsWithF("$"), Brief.TrimStart("$"), LinkLoader.Error.GetDisplay(True))
        If LabLoadDesc.Text.Contains("陶瓦") OrElse LabLoadDesc.Text.Contains("Terracotta") Then
            LabLoadDesc.Text &= vbCrLf & $"网络实在不通时，可自行下载后放入 {ModTerracotta.TerracottaFolder}" & vbCrLf &
                $"（文件名 terracotta-{ModTerracotta.TerracottaVersion}-windows_x86_64-pkg.tar.gz，或直接放入解压得到的 陶瓦联机.exe）"
        End If
        Logger.Warn(LinkLoader.Error, LabLoadTitle.Text)
    End Sub

    Private Sub UpdateLoadingPage(Title As String, FailBrief As String)
        If FailReason = FailBrief & "失败" Then Return
        FailReason = FailBrief & "失败"
        Logger.Info($"开始步骤：{Title}")
        RunInUiWait(
        Sub()
            If FrmLinkMain Is Nothing OrElse Not FrmLinkMain.LabLoadDesc.IsLoaded Then Return
            FrmLinkMain.LabLoadDesc.Text = Title
        End Sub)
    End Sub
    Private FailReason As String = "准备初始化"

    '取消加载
    Private Sub BtnLoadCancel_Click() Handles BtnLoadCancel.Click
        ChangeState(LinkStates.Waiting)
    End Sub

    '点击重试
    Private Sub CardLoad_MouseLeftButtonUp() Handles CardLoad.MouseLeftButtonUp
        ChangeState(LinkStates.Loading)
    End Sub

    '进度条
    Private Sub UpdateProgressBar(Optional Value As Double = -1)
        If Value = -1 Then Value = LinkLoader.Progress
        Dim DisplayingProgress As Double = ColumnProgressA.Width.Value
        If Math.Round(Value - DisplayingProgress, 3) = 0 Then Return
        If DisplayingProgress <= Value Then
            Dim NewProgress As Double = If(Value = 1, 1, DisplayingProgress +
                (Value - DisplayingProgress) ^ 2 * 0.5)
            AniStart({
                AaGridLengthWidth(ColumnProgressA, NewProgress - ColumnProgressA.Width.Value, 200),
                AaGridLengthWidth(ColumnProgressB, (1 - NewProgress) - ColumnProgressB.Width.Value, 200)
            }, "Link Progress")
        Else
            ColumnProgressA.Width = New GridLength(Value, GridUnitType.Star)
            ColumnProgressB.Width = New GridLength(1 - Value, GridUnitType.Star)
            AniStop("Link Progress")
        End If
    End Sub
    Private Sub CardLoad_SizeChanged() Handles CardLoad.SizeChanged
        RectProgressClip.Rect = New Rect(0, 0, CardLoad.ActualWidth, 12)
    End Sub

#End Region

#Region "完成页面 (Finished)"

    '由 Loading 状态切换到 Finished
    Private Sub SwitchToFinished(OldState As LinkStates)
        UpdatePanelVisibility()
        'UI 更新
        If IsServerSide Then
            LabFinishTitle.Text = "已创建房间"
            LabFinishDesc.Text = $"把房间码发给朋友，让大家加入房间吧！{vbCrLf}房间码：{RoomCode}"
            BtnFinishExit.Text = "关闭房间"
            BtnFinishCopy.Visibility = Visibility.Visible
            Copy() '立即复制房间码
            BtnFinishPort.Visibility = Visibility.Collapsed
            LabFinishPort.Visibility = Visibility.Collapsed
            BtnFinishIp.Visibility = Visibility.Collapsed
            LabFinishIp.Visibility = Visibility.Collapsed
            LineFinishPort.Visibility = Visibility.Collapsed
        Else
            LabFinishTitle.Text = "已加入房间"
            LabFinishDesc.Text = $"在多人游戏页面的最下方就能找到联机房间！{vbCrLf}也可以直接添加服务器：{ServerAddress}"
            BtnFinishExit.Text = "离开"
            BtnFinishCopy.Visibility = Visibility.Collapsed
            BtnFinishPort.Visibility = Visibility.Collapsed
            LabFinishPort.Visibility = Visibility.Collapsed
            LineFinishPort.Visibility = Visibility.Collapsed
            LabFinishIp.Text = ServerAddress
            BtnFinishIp.Visibility = Visibility.Visible
            LabFinishIp.Visibility = Visibility.Visible
        End If
        HintFinish.Visibility = Visibility.Collapsed
        '陶瓦联机不向启动器提供延迟与人数信息
        BtnFinishPing.Visibility = Visibility.Collapsed
        BtnFinishPlayer.Visibility = Visibility.Collapsed
        LineFinishPing.Visibility = Visibility.Collapsed
    End Sub

    '第三方署名（陶瓦联机的 AGPL 例外条款要求在界面明显处标注版权信息）
    Private Sub BtnTerracottaCredit_Click() Handles BtnTerracottaCredit.Click
        OpenWebsite(ModTerracotta.TerracottaProjectUrl)
    End Sub

    '复制房间码
    Private Sub Copy() Handles BtnFinishCopy.Click
        Dim CodeText As String = $"在 PCL-QW中输入房间码【{RoomCode}】，即可加入联机房间！"
        ClipboardSet(CodeText, False)
        Settings.Set("LinkLastAutoJoinInviteCode", CodeText)
        Hint("已复制房间码！", HintType.Green)
    End Sub

    '复制 IP
    Private Sub BtnFinishIp_MouseLeftButtonUp(sender As Object, e As MouseButtonEventArgs) Handles BtnFinishIp.MouseLeftButtonUp
        ClipboardSet(ServerAddress, False)
        Hint("已复制服务器地址！", HintType.Green)
    End Sub

#End Region

    '===============================
    '  后端（陶瓦联机）
    '===============================

    ''' <summary>
    ''' 当前是房主还是访客。
    ''' </summary>
    Private IsServerSide As Boolean = False
    ''' <summary>
    ''' 房间码（房主创建后由陶瓦给出，或访客输入的房间码）。
    ''' </summary>
    Private RoomCode As String = Nothing
    ''' <summary>
    ''' 访客连接到的服务器地址。
    ''' </summary>
    Private ServerAddress As String = Nothing
    Private PlayerName As String = Nothing

    Private WithEvents LinkLoader As New LoaderCombo(Of Integer)("联机", {
        New LoaderTask(Of Integer, Integer)("准备陶瓦联机", AddressOf TerracottaPrepare) With {.ProgressWeight = 12},
        New LoaderTask(Of Integer, List(Of NetFile))("获取下载地址", AddressOf TerracottaDownload) With {.ProgressWeight = 1},
        New LoaderDownload("下载陶瓦联机", New List(Of NetFile)) With {.ProgressWeight = 40},
        New LoaderTask(Of Integer, Integer)("启动陶瓦联机", AddressOf TerracottaLaunch) With {.ProgressWeight = 10},
        New LoaderTask(Of Integer, Integer)("建立联机房间", AddressOf TerracottaConnect) With {.ProgressWeight = 37}
    })

    '1. 检查是否已安装
    Private NeedDownload As Boolean = False
    Private Sub TerracottaPrepare(Task As LoaderTask(Of Integer, Integer))
        UpdateLoadingPage("正在检查陶瓦联机是否已安装……", "检查陶瓦联机")
        NeedDownload = Not ModTerracotta.IsInstalled()
        If NeedDownload Then
            Logger.Info("陶瓦联机尚未安装，将下载并解压到 " & ModTerracotta.TerracottaFolder)
        End If
        Task.Output = 1
    End Sub

    '2. 生成下载列表
    Private Sub TerracottaDownload(Task As LoaderTask(Of Integer, List(Of NetFile)))
        Task.Output = If(NeedDownload, ModTerracotta.PrepareDownloadFiles(), New List(Of NetFile))
    End Sub

    '3. 解压并启动
    Private Sub TerracottaLaunch(Task As LoaderTask(Of Integer, Integer))
        If NeedDownload Then
            UpdateLoadingPage("正在解压陶瓦联机……", "解压陶瓦联机")
            ModTerracotta.InstallDownloadedPackage()
        End If
        UpdateLoadingPage("正在启动陶瓦联机……", "启动陶瓦联机")
        ModTerracotta.EnsureStarted(Function() Task.IsCanceled)
        Task.Output = 1
    End Sub

    '4. 创建或加入房间
    Private Sub TerracottaConnect(Task As LoaderTask(Of Integer, Integer))
        If IsServerSide Then
            UpdateLoadingPage("正在扫描本地的 Minecraft 服务器……", "扫描本地服务器")
            ModTerracotta.StartHost(PlayerName)
        Else
            UpdateLoadingPage("正在连接房主……", "连接房主")
            ModTerracotta.JoinRoom(RoomCode, PlayerName)
        End If
        '轮询状态直到就绪
        Dim Wait As Integer = 0
        Dim LastPhase As ModTerracotta.LinkPhase? = Nothing
        Do While Not Task.IsCanceled
            Thread.Sleep(500)
            Wait += 1
            Dim Status = ModTerracotta.QueryStatus()
            If Status Is Nothing Then
                If Wait > 60 Then Throw New Exception("$与陶瓦联机的连接中断了，请重新尝试。")
                Continue Do
            End If
            If Status.Value.Phase <> LastPhase Then
                LastPhase = Status.Value.Phase
                Select Case Status.Value.Phase
                    Case ModTerracotta.LinkPhase.HostScanning
                        UpdateLoadingPage("正在等待本地的 Minecraft 服务器……" & vbCrLf &
                            "请在游戏中对局域网开放世界，或先启动服务器。", "等待本地服务器")
                    Case ModTerracotta.LinkPhase.HostStarting
                        UpdateLoadingPage("已找到本地服务器，正在建立联机网络……", "建立联机网络")
                    Case ModTerracotta.LinkPhase.GuestConnecting
                        UpdateLoadingPage("正在连接到房主……", "连接房主")
                    Case ModTerracotta.LinkPhase.GuestStarting
                        UpdateLoadingPage("正在建立联机网络……", "建立联机网络")
                End Select
            End If
            Select Case Status.Value.Phase
                Case ModTerracotta.LinkPhase.HostReady
                    RoomCode = Status.Value.RoomCode
                    Logger.Info($"房间已创建，房间码 {RoomCode}")
                    Task.Output = 1
                    Return
                Case ModTerracotta.LinkPhase.GuestReady
                    ServerAddress = Status.Value.Address
                    Logger.Info($"已加入房间，地址 {ServerAddress}")
                    Task.Output = 1
                    Return
                Case ModTerracotta.LinkPhase.Errored
                    Throw New Exception("$" & If(Status.Value.ErrorText, "联机失败。"))
            End Select
            If Wait > 600 Then Throw New Exception($"联机建立超时（5 分钟）。{vbCrLf}请检查网络环境后重试。")
        Loop
        Throw New OperationCanceledException
    End Sub

#Region "运行状态监视"

    '每秒检查一次，处理房间中断等情况
    Private Sub StartMonitorThread() Handles Me.Loaded
        Static IsMonitorStarted As Boolean = False
        If IsMonitorStarted Then Return
        IsMonitorStarted = True
        RunInNewThread(
        Sub()
            Do While True
                Try
                    Thread.Sleep(1000)
                    If LinkState = LinkStates.Loading Then RunInUi(AddressOf UpdateProgressBar)
                    If LinkState <> LinkStates.Finished Then Continue Do
                    Dim Status = ModTerracotta.QueryStatus()
                    If Status Is Nothing Then
                        Panic("与陶瓦联机的连接中断", "请重新创建或加入房间。")
                        Continue Do
                    End If
                    Select Case Status.Value.Phase
                        Case ModTerracotta.LinkPhase.Waiting
                            If IsServerSide Then
                                Panic("房间已关闭", "陶瓦联机已回到空闲状态。")
                            Else
                                Panic("房主已离开房间", "联机结束。")
                            End If
                        Case ModTerracotta.LinkPhase.Errored
                            Panic("联机出错", If(Status.Value.ErrorText, "未知错误"))
                        Case ModTerracotta.LinkPhase.HostReady
                            If Not String.IsNullOrEmpty(Status.Value.RoomCode) Then RoomCode = Status.Value.RoomCode
                        Case ModTerracotta.LinkPhase.GuestReady
                            If Not String.IsNullOrEmpty(Status.Value.Address) Then ServerAddress = Status.Value.Address
                    End Select
                Catch ex As Exception
                    Logger.Error(ex, "联机状态监视出错")
                    Thread.Sleep(5000)
                End Try
            Loop
        End Sub, "Link Monitor")
    End Sub

    ''' <summary>
    ''' 出现意外错误，给出错误信息并结束联机。
    ''' </summary>
    Private Sub Panic(Brief As String, Detail As String)
        If LinkState = LinkStates.Loading Then
            FailReason = Brief
            LinkLoader.Failed(New Exception(Detail))
        Else
            MyMsgBox(Detail, "联机出错：" & Brief, IsWarn:=True)
            ChangeState(LinkStates.Waiting)
        End If
    End Sub

#End Region

    ''' <summary>
    ''' 退出联机。返回 True 表示用户在警告中选择了取消。
    ''' </summary>
    Public Function TryExit(Silent As Boolean, Closing As Boolean) As Boolean
        If LinkState = LinkStates.Waiting OrElse LinkState = LinkStates.Failed Then Return False
        If Not Silent Then
            If IsServerSide AndAlso Not Closing Then
                If MyMsgBox($"你确定要关闭联机房间吗？{vbCrLf}所有玩家都需要重新输入房间码才可加入游戏！", "退出联机", "确定", "取消", IsWarn:=True) = 2 Then Return True
            ElseIf Closing Then
                If MyMsgBox(If(IsServerSide, "你确定要关闭联机房间吗？", "你确定要离开联机房间吗？"), "退出联机", "确定", "取消") = 2 Then Return True
            End If
        End If
        ChangeState(LinkStates.Waiting)
        If Closing Then ModTerracotta.StopProcess()
        Return False
    End Function

End Class
