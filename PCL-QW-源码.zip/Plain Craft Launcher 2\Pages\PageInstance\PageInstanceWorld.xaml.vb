Public Class PageInstanceWorld

    'PCL-QW新增：世界（存档）管理页面（后台线程加载，不阻塞界面）

    Private IsLoading As Boolean = False

    Private Sub PageInstanceWorld_Loaded(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        RefreshList()
    End Sub

    Private Sub BtnFolder_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnFolder.Click
        Try
            DirectoryUtils.Create(SaveFolder)
            OpenExplorer(SaveFolder)
        Catch ex As Exception
            Logger.Error(ex, "打开存档文件夹失败", LogBehavior.Alert)
        End Try
    End Sub

    Private Sub BtnRefresh_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnRefresh.Click
        RefreshList()
    End Sub

    Private ReadOnly Property SaveFolder As String
        Get
            Dim Instance = PageInstanceLeft.Instance
            Return If(Instance Is Nothing, McFolderSelected, Instance.PathIndie) & "saves\"
        End Get
    End Property

    Private Sub RefreshList()
        If IsLoading Then Return
        IsLoading = True
        Dim Instance = PageInstanceLeft.Instance
        Dim Folder As String = SaveFolder
        RunInThread(
        Sub()
            Try
                Dim Entries As New List(Of (Path As String, FolderName As String, Title As String, Extra As String, Time As Date))
                If Instance IsNot Nothing Then
                    Dim DirInfo As New System.IO.DirectoryInfo(Folder)
                    If DirInfo.Exists Then
                        For Each DirItem As System.IO.DirectoryInfo In DirInfo.EnumerateDirectories()
                            Dim Title As String = DirItem.Name
                            Dim Extra As String = ""
                            Try
                                Dim RawRoot = NbtUtils.ReadFile(DirItem.FullName & "\level.dat")
                                Dim RawData = NbtUtils.GetChild(RawRoot, "Data")
                                Dim NameTag = NbtUtils.GetChild(RawData, "LevelName")
                                If NameTag IsNot Nothing AndAlso Not String.IsNullOrEmpty(NameTag.Value?.ToString) Then Title = NameTag.Value.ToString
                                Dim VerTag = NbtUtils.GetChild(NbtUtils.GetChild(RawData, "Version"), "Name")
                                If VerTag IsNot Nothing AndAlso Not String.IsNullOrEmpty(VerTag.Value?.ToString) Then Extra = " · " & VerTag.Value.ToString
                            Catch ex As Exception
                                Logger.Warn(ex, $"读取世界名称失败：{DirItem.FullName}")
                            End Try
                            Entries.Add((DirItem.FullName, DirItem.Name, Title, Extra, DirItem.LastWriteTime))
                        Next
                    End If
                End If
                Entries = Entries.OrderByDescending(Function(w) w.Time).ToList()
                RunInUi(
                Sub()
                    Try
                        PanList.Children.Clear()
                        LabEmpty.Visibility = If(Entries.Any(), Visibility.Collapsed, Visibility.Visible)
                        For Each Entry In Entries
                            PanList.Children.Add(GetWorldItem(Entry.Path, Entry.FolderName, Entry.Title, Entry.Extra, Entry.Time))
                        Next
                    Catch ex As Exception
                        Logger.Error(ex, "显示世界列表失败")
                    Finally
                        IsLoading = False
                    End Try
                End Sub)
            Catch ex As Exception
                Logger.Error(ex, "加载世界列表失败")
                IsLoading = False
            End Try
        End Sub)
    End Sub

    Private Function GetWorldItem(WorldPath As String, FolderName As String, Title As String, Extra As String, Time As Date) As MyListItem
        Dim Item As New MyListItem With {
            .Title = Title,
            .Info = $"文件夹：{FolderName} · 最后修改：{Time:yyyy-MM-dd HH:mm}{Extra}",
            .Height = 42,
            .Type = MyListItem.CheckType.Clickable,
            .LogoScale = 0.95,
            .MinPaddingRight = 10
        }
        Dim IconPath As String = WorldPath & "\icon.png"
        If FileUtils.Exists(IconPath) Then Item.Logo = IconPath
        '单击打开文件夹
        AddHandler Item.Click, Sub() OpenExplorer(WorldPath)
        '按钮：进入世界 / 世界设置 / 打开文件夹 / 删除
        Dim BtnEnter As New MyIconButton With {.LogoScale = 0.95, .Logo = "M288 160 L800 512 L288 864 Z", .ToolTip = "直接进入这个世界"}
        Dim BtnSettings As New MyIconButton With {.LogoScale = 0.95, .Logo = Logo.IconButtonSetup, .ToolTip = "世界设置（模式 / 难度 / 作弊 / 名称 / 种子）"}
        Dim BtnFolder As New MyIconButton With {.LogoScale = 0.95, .Logo = Logo.IconButtonOpen, .ToolTip = "打开世界文件夹"}
        Dim BtnDelete As New MyIconButton With {.LogoScale = 1, .Logo = Logo.IconButtonDelete, .ToolTip = "删除世界（可在回收站找回）"}
        AddHandler BtnEnter.Click, Sub() EnterWorld(FolderName)
        AddHandler BtnSettings.Click, Sub() OpenWorldSettings(WorldPath)
        AddHandler BtnFolder.Click, Sub() OpenExplorer(WorldPath)
        AddHandler BtnDelete.Click, Sub() DeleteWorld(WorldPath, Title)
        Dim PinKey As String = If(PageInstanceLeft.Instance Is Nothing, "", PageInstanceLeft.Instance.Name & "\" & FolderName)
        Dim IsPinned As Boolean = PinKey <> "" AndAlso ModRecent.IsPinned(ModRecent.RecentKind.World, PinKey)
        Dim BtnPin As New MyIconButton With {
            .LogoScale = 0.95,
            .Logo = If(IsPinned, Logo.IconButtonLikeFill, Logo.IconButtonLikeLine),
            .ToolTip = If(IsPinned, "取消固定到首页", "固定到首页")}
        AddHandler BtnPin.Click, Sub()
                                     If PinKey = "" Then Return
                                     ModRecent.TogglePin(ModRecent.RecentKind.World, PinKey)
                                     RefreshList()
                                 End Sub
        Item.Buttons = {BtnEnter, BtnSettings, BtnFolder, BtnPin, BtnDelete}
        Return Item
    End Function

    Private Sub EnterWorld(FolderName As String)
        Dim Instance = PageInstanceLeft.Instance
        If Instance Is Nothing Then Return
        If Instance.ReleaseTime <= New Date(2023, 4, 4) Then
            Hint("当前游戏版本不支持直接进入世界（需要 1.20 或更高版本），请进入游戏后在「单人游戏」中选择。", HintType.Red)
            Return
        End If
        McLaunchStart(New McLaunchOptions With {.Instance = Instance, .WorldName = FolderName})
    End Sub

    '进入世界设置页（PCL-QW新增）
    Private Sub OpenWorldSettings(WorldPath As String)
        PageInstanceWorldSettings.EditingWorldPath = WorldPath
        FrmInstanceLeft.PageChange(FormMain.PageSubType.InstanceWorldSettings)
    End Sub

    Private Sub DeleteWorld(WorldPath As String, Title As String)
        If MyMsgBox($"确定要删除世界 {Title} 吗？{vbCrLf}世界将被移入系统回收站，可在回收站中找回。", "删除世界", "删除", "取消", IsWarn:=True) <> 1 Then Return
        Try
            FileUtils.Delete(WorldPath, True)
            Hint($"已删除世界 {Title}！", HintType.Green)
            RefreshList()
        Catch ex As Exception
            Logger.Error(ex, "删除世界失败", LogBehavior.Alert)
        End Try
    End Sub

End Class
